<?php
/**
 * Plugin Name: Woo Instagram Follower
 * Description: WooCommerce package pricing (service types + quantity repeaters) with an Elementor “CT- follower” widget.
 * Version: 1.2.3
 * Author: CT
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Text Domain: woo-instagram-follower
 *
 * @package WIFL
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WIFL_VERSION', '1.2.3' );
define( 'WIFL_FILE', __FILE__ );
define( 'WIFL_PATH', plugin_dir_path( __FILE__ ) );
define( 'WIFL_URL', plugin_dir_url( __FILE__ ) );

require_once WIFL_PATH . 'includes/class-helpers.php';
require_once WIFL_PATH . 'includes/class-product-meta.php';
require_once WIFL_PATH . 'includes/class-cart.php';
require_once WIFL_PATH . 'includes/class-ajax.php';
require_once WIFL_PATH . 'includes/class-frontend.php';
require_once WIFL_PATH . 'includes/class-float-cart.php';
require_once WIFL_PATH . 'includes/class-float-settings.php';
require_once WIFL_PATH . 'includes/class-plugin.php';

\WIFL\Plugin::instance();
