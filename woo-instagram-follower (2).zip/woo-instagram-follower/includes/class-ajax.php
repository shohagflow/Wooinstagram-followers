<?php
/**
 * AJAX add to cart with custom package price.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ajax {

	/**
	 * @var Ajax|null
	 */
	private static $instance = null;

	/**
	 * @return Ajax
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_wifl_add_to_cart', array( $this, 'add_to_cart' ) );
		add_action( 'wp_ajax_nopriv_wifl_add_to_cart', array( $this, 'add_to_cart' ) );
	}

	public function add_to_cart() {
		check_ajax_referer( 'wifl_add_to_cart', 'nonce' );

		$product_id    = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$service_index = isset( $_POST['service'] ) ? absint( $_POST['service'] ) : 0;
		$package_index = isset( $_POST['package'] ) ? absint( $_POST['package'] ) : 0;

		if ( ! $product_id ) {
			wp_send_json_error(
				array( 'message' => esc_html__( 'Invalid product.', 'woo-instagram-follower' ) ),
				400
			);
		}

		$services = Helpers::get_services( $product_id );
		if ( empty( $services ) ) {
			wp_send_json_error(
				array( 'message' => esc_html__( 'Invalid product.', 'woo-instagram-follower' ) ),
				400
			);
		}

		if ( empty( $services[ $service_index ]['packages'][ $package_index ] ) ) {
			wp_send_json_error(
				array( 'message' => esc_html__( 'Invalid package.', 'woo-instagram-follower' ) ),
				400
			);
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			wp_send_json_error(
				array( 'message' => esc_html__( 'Product not found.', 'woo-instagram-follower' ) ),
				404
			);
		}

		$service = $services[ $service_index ];
		$package = $service['packages'][ $package_index ];

		$this->ensure_cart();

		$cart_item_data = array(
			'wifl' => array(
				'service'       => $product->get_name(),
				'qty'           => $package['qty'],
				'price'         => (float) $package['sale_price'],
				'regular'       => (float) $package['regular_price'],
				'service_index' => $service_index,
				'package_index' => $package_index,
				'uniq'          => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'wifl', true ),
			),
		);

		$cart_item_key = WC()->cart->add_to_cart( $product_id, 1, 0, array(), $cart_item_data );

		if ( ! $cart_item_key ) {
			$notices = wc_get_notices( 'error' );
			wc_clear_notices();
			$message = esc_html__( 'Could not add to cart.', 'woo-instagram-follower' );
			if ( ! empty( $notices[0]['notice'] ) ) {
				$message = wp_strip_all_tags( $notices[0]['notice'] );
			}
			wp_send_json_error( array( 'message' => $message ), 400 );
		}

		WC()->cart->calculate_totals();

		wp_send_json_success( $this->cart_response() );
	}

	/**
	 * Mini-cart / header cart fragments so the count updates instantly.
	 *
	 * @return array
	 */
	private function cart_response() {
		$mini_cart = '';
		if ( function_exists( 'woocommerce_mini_cart' ) ) {
			ob_start();
			woocommerce_mini_cart();
			$mini_cart = ob_get_clean();
		}

		$fragments = array(
			'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
		);

		return array(
			'cart_url'  => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
			'count'     => WC()->cart ? WC()->cart->get_cart_contents_count() : 0,
			'fragments' => apply_filters( 'woocommerce_add_to_cart_fragments', $fragments ),
			'cart_hash' => WC()->cart ? WC()->cart->get_cart_hash() : '',
		);
	}

	private function ensure_cart() {
		if ( function_exists( 'wc_load_cart' ) && ( is_null( WC()->cart ) || ! WC()->cart ) ) {
			wc_load_cart();
		}
	}
}
