<?php
/**
 * Frontend markup for the CT- follower widget.
 *
 * @package WIFL
 */

namespace WIFL;

use Elementor\Icons_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Frontend {

	/**
	 * @param int   $product_id Product ID.
	 * @param array $settings   Widget settings.
	 * @param array $services   Service payload.
	 */
	public static function render( $product_id, $settings, $services ) {
		$button_text  = ! empty( $settings['button_text'] ) ? $settings['button_text'] : __( 'Add to Cart', 'woo-instagram-follower' );
		$savings_text = isset( $settings['savings_text'] ) ? $settings['savings_text'] : __( "You're saving", 'woo-instagram-follower' );
		$show_regular = ! isset( $settings['show_regular_price'] ) || 'yes' === $settings['show_regular_price'];
		$show_savings = ! isset( $settings['show_savings'] ) || 'yes' === $settings['show_savings'];
		$show_services = ! isset( $settings['show_services'] ) || 'yes' === $settings['show_services'];
		$show_features = ! isset( $settings['show_features'] ) || 'yes' === $settings['show_features'];
		$show_packages = ! isset( $settings['show_packages'] ) || 'yes' === $settings['show_packages'];
		$show_price    = ! isset( $settings['show_price'] ) || 'yes' === $settings['show_price'];
		$show_cart     = ! isset( $settings['show_cart'] ) || 'yes' === $settings['show_cart'];
		$icon_position = ! empty( $settings['button_icon_position'] ) ? $settings['button_icon_position'] : 'left';
		$has_icon      = ! empty( $settings['button_icon']['value'] );

		$classes = array( 'wifl' );
		if ( ! $show_services ) {
			$classes[] = 'wifl--hide-services';
		}
		if ( ! $show_features ) {
			$classes[] = 'wifl--hide-features';
		}
		if ( ! $show_packages ) {
			$classes[] = 'wifl--hide-packages';
		}
		if ( ! $show_price ) {
			$classes[] = 'wifl--hide-price';
		}
		if ( ! $show_regular ) {
			$classes[] = 'wifl--hide-regular';
		}
		if ( ! $show_savings ) {
			$classes[] = 'wifl--hide-savings';
		}
		if ( ! $show_cart ) {
			$classes[] = 'wifl--hide-cart';
		}

		$active_service = 0;
		$active_package = 0;
		$first          = isset( $services[0] ) ? $services[0] : null;
		$first_pkg      = ( $first && ! empty( $first['packages'][0] ) ) ? $first['packages'][0] : null;

		$payload = array(
			'productId' => (int) $product_id,
			'services'  => $services,
		);
		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-product="<?php echo esc_attr( (string) (int) $product_id ); ?>">
			<script type="application/json" class="wifl-json"><?php echo wp_json_encode( $payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_UNESCAPED_UNICODE ); ?></script>

			<div class="wifl-services" role="list">
				<?php foreach ( $services as $s_index => $service ) : ?>
					<?php
					$is_premium = ( 'premium' === $service['style'] );
					$is_active  = ( (int) $s_index === $active_service );
					$card_class = 'wifl-service';
					if ( $is_premium ) {
						$card_class .= ' wifl-service--premium';
					}
					if ( $is_active ) {
						$card_class .= ' is-active';
					}
					$features = ! empty( $service['features'] ) && is_array( $service['features'] ) ? $service['features'] : array();
					$card_pid = ! empty( $service['productId'] ) ? (int) $service['productId'] : (int) $product_id;
					?>
					<button
						type="button"
						class="<?php echo esc_attr( $card_class ); ?>"
						data-index="<?php echo esc_attr( (string) $s_index ); ?>"
						data-product="<?php echo esc_attr( (string) $card_pid ); ?>"
						aria-pressed="<?php echo $is_active ? 'true' : 'false'; ?>"
					>
						<div class="wifl-service__head">
							<span class="wifl-service__title"><?php echo esc_html( $service['title'] ); ?></span>
							<span class="wifl-service__icon">
								<?php
								if ( $is_premium ) {
									echo Helpers::icon_crown(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								} else {
									echo Helpers::icon_user(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								}
								?>
							</span>
						</div>
						<?php if ( ! empty( $features ) ) : ?>
							<ul class="wifl-service__features">
								<?php foreach ( $features as $feature ) : ?>
									<li><?php echo esc_html( $feature ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
						<span class="wifl-service__check" aria-hidden="true">
							<?php echo Helpers::icon_check(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</span>
					</button>
				<?php endforeach; ?>
			</div>

			<div class="wifl-packages" role="list">
				<?php
				if ( $first && ! empty( $first['packages'] ) ) {
					foreach ( $first['packages'] as $p_index => $package ) {
						$pkg_active = ( (int) $p_index === $active_package );
						$pkg_class  = 'wifl-pkg' . ( $pkg_active ? ' is-active' : '' );
						?>
						<button
							type="button"
							class="<?php echo esc_attr( $pkg_class ); ?>"
							data-index="<?php echo esc_attr( (string) $p_index ); ?>"
							aria-pressed="<?php echo $pkg_active ? 'true' : 'false'; ?>"
						>
							<span class="wifl-pkg__qty"><?php echo esc_html( $package['qty'] ); ?></span>
							<?php if ( ! empty( $package['discount'] ) ) : ?>
								<span class="wifl-pkg__off"><?php echo esc_html( $package['discount'] ); ?></span>
							<?php endif; ?>
						</button>
						<?php
					}
				}
				?>
			</div>

			<div class="wifl-footer">
				<div class="wifl-price">
					<div class="wifl-price__row">
						<span class="wifl-price__sale">
							<?php echo $first_pkg ? Helpers::kses_price( $first_pkg['saleHtml'] ) : ''; ?>
						</span>
						<?php if ( $show_regular ) : ?>
							<span class="wifl-price__regular" <?php echo ( $first_pkg && $first_pkg['regularHtml'] ) ? '' : 'hidden'; ?>>
								<?php echo $first_pkg ? Helpers::kses_price( $first_pkg['regularHtml'] ) : ''; ?>
							</span>
						<?php endif; ?>
					</div>
					<?php if ( $show_savings ) : ?>
						<div class="wifl-savings" <?php echo ( $first_pkg && $first_pkg['saveHtml'] ) ? '' : 'hidden'; ?>>
							<span class="wifl-savings__label"><?php echo esc_html( $savings_text ); ?></span>
							<span class="wifl-savings__tag">
								<?php echo Helpers::icon_tag(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span class="wifl-savings__amount"><?php echo $first_pkg ? Helpers::kses_price( $first_pkg['saveHtml'] ) : ''; ?></span>
							</span>
						</div>
					<?php endif; ?>
				</div>
				<button type="button" class="wifl-cart<?php echo 'right' === $icon_position ? ' wifl-cart--icon-right' : ''; ?>" <?php disabled( ! $product_id ); ?>>
					<?php if ( $has_icon && class_exists( '\Elementor\Icons_Manager' ) ) : ?>
						<span class="wifl-cart__icon">
							<?php Icons_Manager::render_icon( $settings['button_icon'], array( 'aria-hidden' => 'true' ) ); ?>
						</span>
					<?php endif; ?>
					<span class="wifl-cart__text"><?php echo esc_html( $button_text ); ?></span>
				</button>
			</div>
			<div class="wifl-message" hidden></div>
		</div>
		<?php
	}
}
