<?php
/**
 * Products submenu: customize the floating View cart button.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Float_Settings {

	const OPTION = 'wifl_float_settings';

	/**
	 * @var Float_Settings|null
	 */
	private static $instance = null;

	/**
	 * @return Float_Settings
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'     => 'yes',
			'button_text' => 'View cart',
			'dock_bg'     => '#111111',
			'text_color'  => '#ffffff',
			'badge_bg'    => '#e11d48',
			'view_bg'     => '#2a2a2a',
			'accent'      => '#ff5c3a',
			'radius'      => '999',
			'font_size'   => '15',
			'offset_right'=> '22',
			'offset_bottom'=> '22',
			'show_hover'  => 'yes',
		);
	}

	/**
	 * @return array
	 */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	public function menu() {
		add_submenu_page(
			'edit.php?post_type=product',
			esc_html__( 'Floating cart', 'woo-instagram-follower' ),
			esc_html__( 'Floating cart', 'woo-instagram-follower' ),
			'manage_woocommerce',
			'wifl-floating-cart',
			array( $this, 'render_page' )
		);
	}

	public function assets( $hook ) {
		if ( 'product_page_wifl-floating-cart' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_style(
			'wifl-admin',
			WIFL_URL . 'assets/css/admin.css',
			array(),
			WIFL_VERSION
		);
		wp_enqueue_script(
			'wifl-float-admin',
			WIFL_URL . 'assets/js/float-admin.js',
			array( 'jquery', 'wp-color-picker' ),
			WIFL_VERSION,
			true
		);
	}

	public function save() {
		if ( ! isset( $_POST['wifl_float_save'] ) ) {
			return;
		}
		if ( ! isset( $_POST['wifl_float_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_float_nonce'] ) ), 'wifl_float_save' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$raw = isset( $_POST['wifl_float'] ) && is_array( $_POST['wifl_float'] ) ? wp_unslash( $_POST['wifl_float'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		$settings = array(
			'enabled'       => ! empty( $raw['enabled'] ) ? 'yes' : 'no',
			'button_text'   => isset( $raw['button_text'] ) ? sanitize_text_field( $raw['button_text'] ) : 'View cart',
			'dock_bg'       => $this->hex( isset( $raw['dock_bg'] ) ? $raw['dock_bg'] : '#111111' ),
			'text_color'    => $this->hex( isset( $raw['text_color'] ) ? $raw['text_color'] : '#ffffff' ),
			'badge_bg'      => $this->hex( isset( $raw['badge_bg'] ) ? $raw['badge_bg'] : '#e11d48' ),
			'view_bg'       => $this->hex( isset( $raw['view_bg'] ) ? $raw['view_bg'] : '#2a2a2a' ),
			'accent'        => $this->hex( isset( $raw['accent'] ) ? $raw['accent'] : '#ff5c3a' ),
			'radius'        => $this->num( isset( $raw['radius'] ) ? $raw['radius'] : 999, 0, 999 ),
			'font_size'     => $this->num( isset( $raw['font_size'] ) ? $raw['font_size'] : 15, 10, 24 ),
			'offset_right'  => $this->num( isset( $raw['offset_right'] ) ? $raw['offset_right'] : 22, 0, 120 ),
			'offset_bottom' => $this->num( isset( $raw['offset_bottom'] ) ? $raw['offset_bottom'] : 22, 0, 120 ),
			'show_hover'    => ! empty( $raw['show_hover'] ) ? 'yes' : 'no',
		);

		if ( '' === $settings['button_text'] ) {
			$settings['button_text'] = 'View cart';
		}

		update_option( self::OPTION, $settings, false );
		add_settings_error( 'wifl_float', 'saved', esc_html__( 'Floating cart settings saved.', 'woo-instagram-follower' ), 'updated' );
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$s = self::get();
		settings_errors( 'wifl_float' );
		?>
		<div class="wrap wifl-float-admin">
			<h1><?php esc_html_e( 'Floating cart', 'woo-instagram-follower' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Customize the bottom-right View cart button that appears after a product is added to the cart.', 'woo-instagram-follower' ); ?></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'edit.php?post_type=product&page=wifl-floating-cart' ) ); ?>">
				<?php wp_nonce_field( 'wifl_float_save', 'wifl_float_nonce' ); ?>
				<div class="wifl-float-admin__grid">
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Enable', 'woo-instagram-follower' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="wifl_float[enabled]" value="yes" <?php checked( $s['enabled'], 'yes' ); ?> />
									<?php esc_html_e( 'Show the floating View cart button on the site', 'woo-instagram-follower' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-text"><?php esc_html_e( 'Button text', 'woo-instagram-follower' ); ?></label></th>
							<td>
								<input type="text" class="regular-text" id="wifl-float-text" name="wifl_float[button_text]" value="<?php echo esc_attr( $s['button_text'] ); ?>" />
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-dock-bg"><?php esc_html_e( 'Button background', 'woo-instagram-follower' ); ?></label></th>
							<td><input type="text" class="wifl-color" id="wifl-float-dock-bg" name="wifl_float[dock_bg]" value="<?php echo esc_attr( $s['dock_bg'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-text-color"><?php esc_html_e( 'Text color', 'woo-instagram-follower' ); ?></label></th>
							<td><input type="text" class="wifl-color" id="wifl-float-text-color" name="wifl_float[text_color]" value="<?php echo esc_attr( $s['text_color'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-badge"><?php esc_html_e( 'Count badge color', 'woo-instagram-follower' ); ?></label></th>
							<td><input type="text" class="wifl-color" id="wifl-float-badge" name="wifl_float[badge_bg]" value="<?php echo esc_attr( $s['badge_bg'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-view-bg"><?php esc_html_e( 'Hover “View cart” background', 'woo-instagram-follower' ); ?></label></th>
							<td><input type="text" class="wifl-color" id="wifl-float-view-bg" name="wifl_float[view_bg]" value="<?php echo esc_attr( $s['view_bg'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-accent"><?php esc_html_e( 'Checkout button color', 'woo-instagram-follower' ); ?></label></th>
							<td><input type="text" class="wifl-color" id="wifl-float-accent" name="wifl_float[accent]" value="<?php echo esc_attr( $s['accent'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-radius"><?php esc_html_e( 'Border radius (px)', 'woo-instagram-follower' ); ?></label></th>
							<td><input type="number" min="0" max="999" id="wifl-float-radius" name="wifl_float[radius]" value="<?php echo esc_attr( $s['radius'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="wifl-float-size"><?php esc_html_e( 'Font size (px)', 'woo-instagram-follower' ); ?></label></th>
							<td><input type="number" min="10" max="24" id="wifl-float-size" name="wifl_float[font_size]" value="<?php echo esc_attr( $s['font_size'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Position', 'woo-instagram-follower' ); ?></th>
							<td>
								<label><?php esc_html_e( 'Right', 'woo-instagram-follower' ); ?>
									<input type="number" min="0" max="120" name="wifl_float[offset_right]" value="<?php echo esc_attr( $s['offset_right'] ); ?>" class="small-text" /> px
								</label>
								&nbsp;
								<label><?php esc_html_e( 'Bottom', 'woo-instagram-follower' ); ?>
									<input type="number" min="0" max="120" name="wifl_float[offset_bottom]" value="<?php echo esc_attr( $s['offset_bottom'] ); ?>" class="small-text" /> px
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Hover menu', 'woo-instagram-follower' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="wifl_float[show_hover]" value="yes" <?php checked( $s['show_hover'], 'yes' ); ?> />
									<?php esc_html_e( 'Expand with Instagram / TikTok / YouTube icons on hover', 'woo-instagram-follower' ); ?>
								</label>
							</td>
						</tr>
					</table>

					<div class="wifl-float-preview">
						<p><strong><?php esc_html_e( 'Preview', 'woo-instagram-follower' ); ?></strong></p>
						<div class="wifl-float-preview__stage">
							<button type="button" class="wifl-float-preview__btn" id="wifl-float-preview-btn">
								<span class="wifl-float-preview__badge" id="wifl-float-preview-badge">1</span>
								<span id="wifl-float-preview-label"><?php echo esc_html( $s['button_text'] ); ?></span>
							</button>
						</div>
					</div>
				</div>
				<?php submit_button( esc_html__( 'Save changes', 'woo-instagram-follower' ), 'primary', 'wifl_float_save' ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * @param string $value Color.
	 * @return string
	 */
	private function hex( $value ) {
		$color = sanitize_hex_color( $value );
		return $color ? $color : '#111111';
	}

	/**
	 * @param mixed $value Value.
	 * @param int   $min   Min.
	 * @param int   $max   Max.
	 * @return string
	 */
	private function num( $value, $min, $max ) {
		$n = absint( $value );
		if ( $n < $min ) {
			$n = $min;
		}
		if ( $n > $max ) {
			$n = $max;
		}
		return (string) $n;
	}
}
