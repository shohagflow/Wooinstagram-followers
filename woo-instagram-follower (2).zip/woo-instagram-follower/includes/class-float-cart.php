<?php
/**
 * Floating View cart dock + side drawer.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Float_Cart {

	/**
	 * @var Float_Cart|null
	 */
	private static $instance = null;

	/**
	 * @return Float_Cart
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 99 );
		add_action( 'wp_footer', array( $this, 'render' ), 40 );
		add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'fragments' ) );
		add_action( 'wp_ajax_wifl_float_cart', array( $this, 'ajax_cart' ) );
		add_action( 'wp_ajax_nopriv_wifl_float_cart', array( $this, 'ajax_cart' ) );
		add_action( 'wp_ajax_wifl_float_remove', array( $this, 'ajax_remove' ) );
		add_action( 'wp_ajax_nopriv_wifl_float_remove', array( $this, 'ajax_remove' ) );
		add_action( 'wp_ajax_wifl_float_add', array( $this, 'ajax_add' ) );
		add_action( 'wp_ajax_nopriv_wifl_float_add', array( $this, 'ajax_add' ) );
	}

	public function enqueue() {
		if ( is_admin() || ! function_exists( 'WC' ) ) {
			return;
		}

		$settings = Float_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}

		wp_enqueue_style(
			'wifl-float-cart',
			WIFL_URL . 'assets/css/float-cart.css',
			array(),
			WIFL_VERSION
		);

		$css = sprintf(
			'.wifl-float{--wifl-float-bg:%1$s;--wifl-float-text:%2$s;--wifl-float-badge:%3$s;--wifl-float-view-bg:%4$s;--wifl-float-accent:%5$s;--wifl-float-radius:%6$spx;--wifl-float-label-size:%7$spx;right:%8$spx;bottom:%9$spx;}',
			esc_attr( $settings['dock_bg'] ),
			esc_attr( $settings['text_color'] ),
			esc_attr( $settings['badge_bg'] ),
			esc_attr( $settings['view_bg'] ),
			esc_attr( $settings['accent'] ),
			esc_attr( $settings['radius'] ),
			esc_attr( $settings['font_size'] ),
			esc_attr( $settings['offset_right'] ),
			esc_attr( $settings['offset_bottom'] )
		);
		wp_add_inline_style( 'wifl-float-cart', $css );

		wp_enqueue_script(
			'wifl-float-cart',
			WIFL_URL . 'assets/js/float-cart.js',
			array( 'jquery' ),
			WIFL_VERSION,
			true
		);

		wp_localize_script(
			'wifl-float-cart',
			'wiflFloat',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wifl_float_cart' ),
				'checkoutUrl' => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
				'shopUrl'     => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
			)
		);
	}

	/**
	 * @param array $fragments Fragments.
	 * @return array
	 */
	public function fragments( $fragments ) {
		$count = $this->cart_count();
		$fragments['span.wifl-dock__badge'] = $this->badge_html( $count );
		return $fragments;
	}

	public function render() {
		if ( is_admin() || ! function_exists( 'WC' ) ) {
			return;
		}
		$settings = Float_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}
		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
			return;
		}

		$count = $this->cart_count();
		$plats = $this->platforms();
		$label = $settings['button_text'];
		$extra = ( 'yes' !== $settings['show_hover'] ) ? ' wifl-float--simple' : '';
		?>
		<div class="wifl-float<?php echo esc_attr( $extra ); ?>" data-count="<?php echo esc_attr( (string) $count ); ?>"<?php echo $count < 1 ? ' hidden' : ''; ?>>
			<div class="wifl-dock" id="wifl-dock">
				<button type="button" class="wifl-dock__collapsed wifl-js-open-cart" aria-label="<?php echo esc_attr( $label ); ?>">
					<?php echo $this->badge_html( $count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span class="wifl-dock__label"><?php echo esc_html( $label ); ?></span>
				</button>
				<div class="wifl-dock__expanded">
					<div class="wifl-dock__plats">
						<?php foreach ( $plats as $plat ) : ?>
							<a class="wifl-plat<?php echo ! empty( $plat['active'] ) ? ' is-active' : ' is-plus'; ?>" href="<?php echo esc_url( $plat['url'] ); ?>">
								<span class="wifl-plat__icon" aria-hidden="true"><?php echo $plat['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<?php if ( ! empty( $plat['active'] ) ) : ?>
									<span class="wifl-plat__qty"><?php echo esc_html( (string) max( 1, $count ) ); ?></span>
								<?php else : ?>
									<span class="wifl-plat__add">+</span>
								<?php endif; ?>
							</a>
						<?php endforeach; ?>
					</div>
					<button type="button" class="wifl-dock__view wifl-js-open-cart"><?php echo esc_html( $label ); ?></button>
				</div>
			</div>

			<div class="wifl-drawer" id="wifl-drawer" hidden>
				<div class="wifl-drawer__overlay wifl-js-close-cart"></div>
				<aside class="wifl-drawer__panel" role="dialog" aria-modal="true" aria-labelledby="wifl-drawer-title">
					<div class="wifl-drawer__head">
						<button type="button" class="wifl-drawer__back wifl-js-close-cart" aria-label="<?php esc_attr_e( 'Close cart', 'woo-instagram-follower' ); ?>">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>
						</button>
						<h2 id="wifl-drawer-title"><?php esc_html_e( 'Your Cart', 'woo-instagram-follower' ); ?></h2>
						<span class="wifl-drawer__head-spacer"></span>
					</div>
					<div class="wifl-drawer__body" id="wifl-drawer-body"></div>
					<div class="wifl-drawer__foot" id="wifl-drawer-foot"></div>
				</aside>
			</div>
		</div>
		<?php
	}

	public function ajax_cart() {
		check_ajax_referer( 'wifl_float_cart', 'nonce' );
		$this->ensure_cart();
		wp_send_json_success( $this->cart_payload() );
	}

	public function ajax_remove() {
		check_ajax_referer( 'wifl_float_cart', 'nonce' );
		$this->ensure_cart();
		$key = isset( $_POST['key'] ) ? wc_clean( wp_unslash( $_POST['key'] ) ) : '';
		if ( $key && WC()->cart ) {
			WC()->cart->remove_cart_item( $key );
			WC()->cart->calculate_totals();
		}
		wp_send_json_success( $this->cart_payload() );
	}

	public function ajax_add() {
		check_ajax_referer( 'wifl_float_cart', 'nonce' );
		$this->ensure_cart();

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$services   = $product_id ? Helpers::get_services( $product_id ) : array();
		if ( empty( $services[0]['packages'][0] ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid product.', 'woo-instagram-follower' ) ), 400 );
		}

		$product = wc_get_product( $product_id );
		$package = $services[0]['packages'][0];
		if ( ! $product ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Product not found.', 'woo-instagram-follower' ) ), 404 );
		}

		WC()->cart->add_to_cart(
			$product_id,
			1,
			0,
			array(),
			array(
				'wifl' => array(
					'service'       => $product->get_name(),
					'qty'           => $package['qty'],
					'price'         => (float) $package['sale_price'],
					'regular'       => (float) $package['regular_price'],
					'service_index' => 0,
					'package_index' => 0,
					'uniq'          => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'wifl', true ),
				),
			)
		);
		WC()->cart->calculate_totals();
		wp_send_json_success( $this->cart_payload() );
	}

	/**
	 * @return array
	 */
	public function cart_payload() {
		$items         = array();
		$sale_total    = 0;
		$regular_total = 0;
		$in_cart       = array();

		if ( WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $key => $item ) {
				$product = isset( $item['data'] ) ? $item['data'] : null;
				if ( ! $product ) {
					continue;
				}
				$pid     = (int) $item['product_id'];
				$wifl    = ! empty( $item['wifl'] ) && is_array( $item['wifl'] ) ? $item['wifl'] : array();
				$qty     = isset( $item['quantity'] ) ? (int) $item['quantity'] : 1;
				$sale    = isset( $wifl['price'] ) ? (float) $wifl['price'] * $qty : (float) $product->get_price() * $qty;
				$regular = isset( $wifl['regular'] ) ? (float) $wifl['regular'] * $qty : $sale;
				$name    = $product->get_name();
				$pkg     = isset( $wifl['qty'] ) ? $wifl['qty'] : (string) $qty;

				$sale_total      += $sale;
				$regular_total   += $regular;
				$in_cart[ $pid ]  = true;

				$items[] = array(
					'key'         => $key,
					'name'        => $name,
					'package'     => $pkg,
					'platform'    => $this->platform_key( $pid, $name ),
					'thumb'       => get_the_post_thumbnail_url( $pid, 'thumbnail' ),
					'saleHtml'    => Helpers::price_html( $sale ),
					'regularHtml' => $regular > $sale ? Helpers::price_html( $regular ) : '',
				);
			}
		}

		$saved = max( 0, $regular_total - $sale_total );

		return array(
			'count'        => $this->cart_count(),
			'items'        => $items,
			'suggestions'  => $this->suggestions( array_keys( $in_cart ) ),
			'tabs'         => $this->suggestion_tabs(),
			'saleHtml'     => Helpers::price_html( $sale_total ),
			'regularHtml'  => $regular_total > $sale_total ? Helpers::price_html( $regular_total ) : '',
			'savedHtml'    => $saved > 0 ? Helpers::price_html( $saved ) : '',
			'checkoutUrl'  => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
		);
	}

	/**
	 * @param int[] $exclude Product IDs.
	 * @return array
	 */
	private function suggestions( $exclude ) {
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'numberposts'    => 8,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'post__not_in'   => array_map( 'intval', $exclude ),
			)
		);

		$out = array();
		foreach ( (array) $ids as $id ) {
			$services = Helpers::get_services( (int) $id );
			if ( empty( $services ) ) {
				continue;
			}
			$payload = Helpers::services_payload( $services, (int) $id );
			$pkg     = isset( $payload[0]['packages'][0] ) ? $payload[0]['packages'][0] : null;
			$product = wc_get_product( $id );
			if ( ! $product || ! $pkg ) {
				continue;
			}
			$out[] = array(
				'id'          => (int) $id,
				'name'        => $product->get_name(),
				'platform'    => $this->platform_key( (int) $id, $product->get_name() ),
				'thumb'       => get_the_post_thumbnail_url( $id, 'thumbnail' ),
				'saleHtml'    => $pkg['saleHtml'],
				'regularHtml' => $pkg['regularHtml'],
			);
			if ( count( $out ) >= 6 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * @return array
	 */
	private function suggestion_tabs() {
		$tabs = array(
			array(
				'id'    => 'all',
				'label' => __( 'For you', 'woo-instagram-follower' ),
			),
		);
		foreach ( $this->platforms() as $plat ) {
			$tabs[] = array(
				'id'    => $plat['key'],
				'label' => $plat['label'],
			);
		}
		return $tabs;
	}

	/**
	 * @return array
	 */
	private function platforms() {
		$shop = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
		$count = $this->cart_count();
		$active = $count > 0 ? $this->active_platform() : '';

		$list = array(
			array(
				'key'    => 'instagram',
				'label'  => 'Instagram',
				'url'    => $this->platform_url( 'instagram', $shop ),
				'icon'   => $this->icon_instagram(),
				'active' => ( 'instagram' === $active ),
			),
			array(
				'key'    => 'tiktok',
				'label'  => 'TikTok',
				'url'    => $this->platform_url( 'tiktok', $shop ),
				'icon'   => $this->icon_tiktok(),
				'active' => ( 'tiktok' === $active ),
			),
			array(
				'key'    => 'youtube',
				'label'  => 'YouTube',
				'url'    => $this->platform_url( 'youtube', $shop ),
				'icon'   => $this->icon_youtube(),
				'active' => ( 'youtube' === $active ),
			),
		);

		$has_active = false;
		foreach ( $list as $row ) {
			if ( ! empty( $row['active'] ) ) {
				$has_active = true;
				break;
			}
		}
		if ( $count > 0 && ! $has_active ) {
			$list[0]['active'] = true;
		}

		return $list;
	}

	/**
	 * @return string
	 */
	private function active_platform() {
		if ( ! WC()->cart ) {
			return '';
		}
		foreach ( WC()->cart->get_cart() as $item ) {
			$pid  = (int) $item['product_id'];
			$name = isset( $item['data'] ) ? $item['data']->get_name() : '';
			return $this->platform_key( $pid, $name );
		}
		return '';
	}

	/**
	 * @param int    $product_id Product ID.
	 * @param string $name       Name.
	 * @return string
	 */
	private function platform_key( $product_id, $name = '' ) {
		$bits = array( strtolower( (string) $name ) );
		$terms = wp_get_post_terms( (int) $product_id, 'product_cat' );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$bits[] = strtolower( $term->name . ' ' . $term->slug );
			}
		}
		$blob = implode( ' ', $bits );
		if ( false !== strpos( $blob, 'tiktok' ) || false !== strpos( $blob, 'tik-tok' ) ) {
			return 'tiktok';
		}
		if ( false !== strpos( $blob, 'youtube' ) || false !== strpos( $blob, 'you-tube' ) ) {
			return 'youtube';
		}
		return 'instagram';
	}

	/**
	 * @param string $key  Platform key.
	 * @param string $shop Shop URL.
	 * @return string
	 */
	private function platform_url( $key, $shop ) {
		$term = get_term_by( 'slug', $key, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			$link = get_term_link( $term );
			if ( ! is_wp_error( $link ) ) {
				return $link;
			}
		}
		return $shop;
	}

	/**
	 * @return int
	 */
	private function cart_count() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return 0;
		}
		return (int) WC()->cart->get_cart_contents_count();
	}

	/**
	 * @param int $count Count.
	 * @return string
	 */
	private function badge_html( $count ) {
		return '<span class="wifl-dock__badge">' . esc_html( (string) max( 0, (int) $count ) ) . '</span>';
	}

	private function ensure_cart() {
		if ( function_exists( 'wc_load_cart' ) && ( is_null( WC()->cart ) || ! WC()->cart ) ) {
			wc_load_cart();
		}
	}

	private function icon_instagram() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 3h10a4 4 0 014 4v10a4 4 0 01-4 4H7a4 4 0 01-4-4V7a4 4 0 014-4zm5 4.5A4.5 4.5 0 1016.5 12 4.5 4.5 0 0012 7.5zm0 7.4A2.9 2.9 0 1114.9 12 2.9 2.9 0 0112 14.9zM17.4 6.2a1.1 1.1 0 11-1.1 1.1 1.1 1.1 0 011.1-1.1z"/></svg>';
	}

	private function icon_tiktok() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M14.2 3h2.3c.2 2 1.5 3.6 3.5 4v2.4c-1.3 0-2.5-.4-3.5-1.1v6.4A6.7 6.7 0 117.2 8.2v2.5a4.2 4.2 0 104.2 4.2V3z"/></svg>';
	}

	private function icon_youtube() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M23 12.2s0-3.2-.4-4.6c-.2-.9-.9-1.6-1.8-1.8C18.9 5.4 12 5.4 12 5.4s-6.9 0-8.8.4c-.9.2-1.6.9-1.8 1.8C1 9 1 12.2 1 12.2s0 3.2.4 4.6c.2.9.9 1.6 1.8 1.8 1.9.4 8.8.4 8.8.4s6.9 0 8.8-.4c.9-.2 1.6-.9 1.8-1.8.4-1.4.4-4.6.4-4.6zM9.8 15.6V8.8l6.4 3.4-6.4 3.4z"/></svg>';
	}
}
