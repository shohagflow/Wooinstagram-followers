<?php
/**
 * Cart, mini-cart, and order line-item data.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Cart {

	/**
	 * @var Cart|null
	 */
	private static $instance = null;

	/**
	 * @return Cart
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'apply_custom_price' ), 20, 1 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'from_session' ), 10, 2 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'cart_item_data' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'order_line_item' ), 10, 4 );
		add_filter( 'woocommerce_add_to_cart_sold_individually_found_in_cart', array( $this, 'allow_repeat_packages' ), 10, 5 );
	}

	/**
	 * Allow the same product to be added again with a different package.
	 *
	 * @param bool  $found_in_cart Found.
	 * @param int   $product_id    Product ID.
	 * @param int   $variation_id  Variation ID.
	 * @param array $cart_item_data Cart item data.
	 * @param int   $cart_id       Cart id.
	 * @return bool
	 */
	public function allow_repeat_packages( $found_in_cart, $product_id, $variation_id, $cart_item_data, $cart_id ) {
		if ( ! empty( $cart_item_data['wifl'] ) ) {
			return false;
		}
		return $found_in_cart;
	}

	/**
	 * @param \WC_Cart $cart Cart.
	 */
	public function apply_custom_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		if ( ! $cart || ! is_object( $cart ) || ! method_exists( $cart, 'get_cart' ) ) {
			return;
		}

		foreach ( $cart->get_cart() as $item ) {
			if ( empty( $item['wifl']['price'] ) || empty( $item['data'] ) ) {
				continue;
			}
			$item['data']->set_price( (float) $item['wifl']['price'] );
		}
	}

	/**
	 * @param array $item_data Item data.
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	public function cart_item_data( $item_data, $cart_item ) {
		if ( empty( $cart_item['wifl'] ) || ! is_array( $cart_item['wifl'] ) ) {
			return $item_data;
		}

		if ( ! empty( $cart_item['wifl']['service'] ) ) {
			$item_data[] = array(
				'key'   => esc_html__( 'Service', 'woo-instagram-follower' ),
				'value' => wc_clean( $cart_item['wifl']['service'] ),
			);
		}

		if ( ! empty( $cart_item['wifl']['qty'] ) ) {
			$item_data[] = array(
				'key'   => esc_html__( 'Package', 'woo-instagram-follower' ),
				'value' => wc_clean( $cart_item['wifl']['qty'] ),
			);
		}

		return $item_data;
	}

	/**
	 * @param \WC_Order_Item_Product $item          Order item.
	 * @param string                 $cart_item_key Cart key.
	 * @param array                  $values        Cart values.
	 * @param \WC_Order              $order         Order.
	 */
	public function order_line_item( $item, $cart_item_key, $values, $order ) {
		if ( empty( $values['wifl'] ) || ! is_array( $values['wifl'] ) ) {
			return;
		}

		if ( ! empty( $values['wifl']['service'] ) ) {
			$item->add_meta_data( __( 'Service', 'woo-instagram-follower' ), wc_clean( $values['wifl']['service'] ), true );
		}

		if ( ! empty( $values['wifl']['qty'] ) ) {
			$item->add_meta_data( __( 'Package', 'woo-instagram-follower' ), wc_clean( $values['wifl']['qty'] ), true );
		}
	}

	/**
	 * Keep custom package data when the cart is restored.
	 *
	 * @param array $cart_item Cart item.
	 * @param array $values    Session values.
	 * @return array
	 */
	public function from_session( $cart_item, $values ) {
		if ( ! empty( $values['wifl'] ) ) {
			$cart_item['wifl'] = $values['wifl'];
		}
		return $cart_item;
	}
}
