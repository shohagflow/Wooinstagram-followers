<?php
/**
 * Shared helpers.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helpers {

	/**
	 * Demo services matching the design (editor preview + admin seed).
	 *
	 * @return array
	 */
	public static function demo_services() {
		$features = array(
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
		);

		$packages = array(
			array(
				'qty'           => '50',
				'discount'      => '20',
				'regular_price' => '2.49',
			),
			array(
				'qty'           => '100',
				'discount'      => '30',
				'regular_price' => '4.99',
			),
			array(
				'qty'           => '250',
				'discount'      => '52',
				'regular_price' => '12.49',
			),
			array(
				'qty'           => '500',
				'discount'      => '68',
				'regular_price' => '24.99',
			),
			array(
				'qty'           => '1000',
				'discount'      => '70',
				'regular_price' => '49.99',
			),
			array(
				'qty'           => '2500',
				'discount'      => '76',
				'regular_price' => '124.99',
			),
			array(
				'qty'           => '5000',
				'discount'      => '80',
				'regular_price' => '249.99',
			),
			array(
				'qty'           => '20000',
				'discount'      => '88',
				'regular_price' => '999.99',
			),
		);

		$premium_packages = array();
		foreach ( $packages as $package ) {
			$premium                  = $package;
			$premium['regular_price'] = wc_format_decimal( (float) $package['regular_price'] * 1.35 );
			$premium_packages[]       = $premium;
		}

		return array(
			array(
				'title'    => 'High Quality Likes',
				'style'    => 'default',
				'icon'     => '',
				'features' => $features,
				'packages' => $packages,
			),
			array(
				'title'    => 'Premium Likes',
				'style'    => 'premium',
				'icon'     => '',
				'features' => $features,
				'packages' => $premium_packages,
			),
		);
	}

	/**
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function is_enabled( $product_id ) {
		return 'yes' === get_post_meta( (int) $product_id, '_wifl_enabled', true );
	}

	/**
	 * @param int $product_id Product ID.
	 * @return array
	 */
	public static function get_services( $product_id ) {
		$services = get_post_meta( (int) $product_id, '_wifl_services', true );
		if ( ! is_array( $services ) ) {
			return array();
		}

		$clean = array();
		foreach ( $services as $service ) {
			$normalized = self::normalize_service( $service );
			if ( $normalized ) {
				$clean[] = $normalized;
			}
		}

		return $clean;
	}

	/**
	 * @param mixed $service Raw service.
	 * @return array|null
	 */
	public static function normalize_service( $service ) {
		if ( ! is_array( $service ) ) {
			return null;
		}

		$title = isset( $service['title'] ) ? sanitize_text_field( $service['title'] ) : '';

		$style = isset( $service['style'] ) ? sanitize_key( $service['style'] ) : 'default';
		if ( ! in_array( $style, array( 'default', 'premium' ), true ) ) {
			$style = 'default';
		}

		$features = array();
		if ( ! empty( $service['features'] ) && is_array( $service['features'] ) ) {
			foreach ( $service['features'] as $feature ) {
				$feature = sanitize_text_field( $feature );
				if ( '' !== $feature ) {
					$features[] = $feature;
				}
			}
		} elseif ( ! empty( $service['features'] ) && is_string( $service['features'] ) ) {
			$lines = preg_split( '/\r\n|\r|\n/', $service['features'] );
			foreach ( $lines as $line ) {
				$line = sanitize_text_field( $line );
				if ( '' !== $line ) {
					$features[] = $line;
				}
			}
		}

		$packages = array();
		if ( ! empty( $service['packages'] ) && is_array( $service['packages'] ) ) {
			foreach ( $service['packages'] as $package ) {
				$normalized = self::normalize_package( $package );
				if ( $normalized ) {
					$packages[] = $normalized;
				}
			}
		}

		if ( empty( $packages ) && empty( $features ) ) {
			return null;
		}

		return array(
			'title'    => $title,
			'style'    => $style,
			'icon'     => '',
			'features' => $features,
			'packages' => $packages,
		);
	}

	/**
	 * @param mixed $value Raw discount (20, "20", "20% off").
	 * @return float
	 */
	public static function parse_discount_percent( $value ) {
		if ( is_numeric( $value ) ) {
			return max( 0, min( 100, (float) $value ) );
		}

		if ( preg_match( '/([0-9]+(?:\.[0-9]+)?)/', (string) $value, $matches ) ) {
			return max( 0, min( 100, (float) $matches[1] ) );
		}

		return 0;
	}

	/**
	 * @param float $percent Discount percent.
	 * @return string
	 */
	public static function format_discount_percent( $percent ) {
		$percent = (float) $percent;
		if ( $percent <= 0 ) {
			return '';
		}

		return rtrim( rtrim( number_format( $percent, 2, '.', '' ), '0' ), '.' );
	}

	/**
	 * @param float $percent Discount percent.
	 * @return string
	 */
	public static function discount_label( $percent ) {
		$formatted = self::format_discount_percent( $percent );
		if ( '' === $formatted ) {
			return '';
		}

		return $formatted . '% off';
	}

	/**
	 * @param float $regular      Original price.
	 * @param float $discount_pct Discount percent.
	 * @return string
	 */
	public static function calculate_sale_price( $regular, $discount_pct ) {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$sale     = (float) $regular * ( 1 - ( (float) $discount_pct / 100 ) );
		if ( $sale < 0 ) {
			$sale = 0;
		}

		return wc_format_decimal( $sale, $decimals );
	}

	/**
	 * @param mixed $package Raw package.
	 * @return array|null
	 */
	public static function normalize_package( $package ) {
		if ( ! is_array( $package ) ) {
			return null;
		}

		$qty = isset( $package['qty'] ) ? preg_replace( '/[^0-9]/', '', (string) $package['qty'] ) : '';
		if ( '' === $qty ) {
			return null;
		}

		$regular = isset( $package['regular_price'] ) ? wc_format_decimal( $package['regular_price'] ) : '';
		if ( '' === $regular || (float) $regular < 0 ) {
			return null;
		}

		$discount = self::parse_discount_percent( isset( $package['discount'] ) ? $package['discount'] : 0 );
		$sale     = self::calculate_sale_price( $regular, $discount );

		return array(
			'qty'           => $qty,
			'discount'      => self::format_discount_percent( $discount ),
			'regular_price' => $regular,
			'sale_price'    => $sale,
		);
	}

	/**
	 * Product name shown on service cards.
	 *
	 * @param int $product_id Product ID.
	 * @return string
	 */
	public static function product_title( $product_id ) {
		$product_id = (int) $product_id;
		if ( $product_id < 1 ) {
			return '';
		}

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				return $product->get_name();
			}
		}

		$title = get_the_title( $product_id );
		return is_string( $title ) ? $title : '';
	}

	/**
	 * Payload for the frontend widget (includes formatted prices).
	 *
	 * @param array $services   Services.
	 * @param int   $product_id Product ID. When set, card title uses the product name.
	 * @return array
	 */
	public static function services_payload( $services, $product_id = 0 ) {
		$out           = array();
		$product_title = self::product_title( $product_id );

		foreach ( $services as $service ) {
			$packages = array();
			foreach ( $service['packages'] as $package ) {
				$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
				$regular  = round( (float) $package['regular_price'], $decimals );
				$percent  = self::parse_discount_percent( isset( $package['discount'] ) ? $package['discount'] : 0 );
				$sale     = round( (float) self::calculate_sale_price( $regular, $percent ), $decimals );
				$save     = max( 0, round( $regular - $sale, $decimals ) );

				$packages[] = array(
					'qty'         => $package['qty'],
					'discount'    => self::discount_label( $percent ),
					'sale'        => $sale,
					'regular'     => $regular,
					'save'        => $save,
					'saleHtml'    => self::price_html( $sale ),
					'regularHtml' => $regular > $sale ? self::price_html( $regular ) : '',
					'saveHtml'    => $save > 0 ? self::price_html( $save ) : '',
				);
			}

			$out[] = array(
				'title'    => '' !== $product_title ? $product_title : ( isset( $service['title'] ) ? $service['title'] : '' ),
				'style'    => $service['style'],
				'features' => ! empty( $service['features'] ) && is_array( $service['features'] ) ? array_values( $service['features'] ) : array(),
				'packages' => $packages,
			);
		}

		return $out;
	}

	/**
	 * @param float $amount Amount.
	 * @return string
	 */
	public static function price_html( $amount ) {
		if ( ! function_exists( 'wc_price' ) ) {
			return esc_html( number_format( (float) $amount, 2 ) );
		}

		return wc_price( (float) $amount );
	}

	/**
	 * @param string $html Price HTML from wc_price().
	 * @return string
	 */
	public static function kses_price( $html ) {
		return wp_kses(
			$html,
			array(
				'span' => array(
					'class'     => true,
					'translate' => true,
				),
				'bdi'  => array(),
			)
		);
	}

	public static function icon_user() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg>';
	}

	/**
	 * Default crown icon.
	 *
	 * @return string
	 */
	public static function icon_crown() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M3 18h18v2.4H3V18zm1.2-3.6L5.4 7.2l4.2 3.6L12 5.4l2.4 5.4 4.2-3.6 1.2 7.2H4.2z"/></svg>';
	}

	/**
	 * Check icon for selected service.
	 *
	 * @return string
	 */
	public static function icon_check() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>';
	}

	/**
	 * Tag icon for savings.
	 *
	 * @return string
	 */
	public static function icon_tag() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.4 11.6l-9-9A1.5 1.5 0 0011.4 2H4.5A1.5 1.5 0 003 3.5v6.9c0 .4.2.8.4 1.1l9 9a1.5 1.5 0 002.1 0l6.9-6.9a1.5 1.5 0 000-2zM7.1 8.4A1.6 1.6 0 117.1 5a1.6 1.6 0 010 3.4z"/></svg>';
	}
}
