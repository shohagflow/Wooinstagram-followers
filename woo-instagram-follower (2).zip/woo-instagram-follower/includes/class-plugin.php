<?php
/**
 * Plugin bootstrap.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	/**
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_woocommerce_notice' ) );
			return;
		}

		Product_Meta::instance();
		Cart::instance();
		Ajax::instance();
		Float_Cart::instance();
		Float_Settings::instance();

		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 25 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		add_shortcode( 'ct_follower', array( $this, 'shortcode' ) );

		if ( did_action( 'elementor/loaded' ) ) {
			add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
			add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_assets' ) );
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_assets' ) );
		} else {
			add_action( 'admin_notices', array( $this, 'missing_elementor_notice' ) );
		}
	}

	public function missing_woocommerce_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning is-dismissible"><p>';
		echo esc_html__( 'Woo Instagram Follower requires WooCommerce to be installed and active.', 'woo-instagram-follower' );
		echo '</p></div>';
	}

	public function missing_elementor_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning is-dismissible"><p>';
		echo esc_html__( 'Woo Instagram Follower: activate Elementor to use the CT- follower widget.', 'woo-instagram-follower' );
		echo '</p></div>';
	}

	public function register_widgets( $widgets_manager ) {
		require_once WIFL_PATH . 'widgets/class-ct-follower.php';
		$widgets_manager->register( new Widgets\CT_Follower() );
	}

	public function register_assets() {
		wp_register_style(
			'wifl-frontend',
			WIFL_URL . 'assets/css/frontend.css',
			array(),
			WIFL_VERSION
		);

		$deps = array( 'jquery' );
		if ( wp_script_is( 'wc-cart-fragments', 'registered' ) ) {
			$deps[] = 'wc-cart-fragments';
		}

		wp_register_script(
			'wifl-frontend',
			WIFL_URL . 'assets/js/frontend.js',
			$deps,
			WIFL_VERSION,
			true
		);

		wp_localize_script(
			'wifl-frontend',
			'wiflSettings',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wifl_add_to_cart' ),
				'i18n'    => array(
					'adding' => esc_html__( 'Adding…', 'woo-instagram-follower' ),
					'added'  => esc_html__( 'Added to cart', 'woo-instagram-follower' ),
					'error'  => esc_html__( 'Could not add to cart.', 'woo-instagram-follower' ),
				),
			)
		);
	}

	/**
	 * Optional shortcode: [ct_follower id="123"]
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'     => 0,
				'button' => __( 'Add to Cart', 'woo-instagram-follower' ),
			),
			$atts,
			'ct_follower'
		);

		$product_id = absint( $atts['id'] );
		if ( ! $product_id && function_exists( 'is_product' ) && is_product() ) {
			$product_id = (int) get_the_ID();
		}

		$services = array();
		if ( $product_id && Helpers::is_enabled( $product_id ) ) {
			$services = Helpers::services_payload( Helpers::get_services( $product_id ), $product_id );
		}

		if ( empty( $services ) ) {
			return '';
		}

		$this->register_assets();
		wp_enqueue_style( 'wifl-frontend' );
		wp_enqueue_script( 'wifl-frontend' );

		$settings = array(
			'button_text'        => $atts['button'],
			'savings_text'       => __( "You're saving", 'woo-instagram-follower' ),
			'show_regular_price' => 'yes',
			'show_savings'       => 'yes',
		);

		ob_start();
		Frontend::render( $product_id, $settings, $services );
		return ob_get_clean();
	}

	public function admin_assets( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'product' !== $screen->id ) {
			return;
		}

		wp_enqueue_style(
			'wifl-admin',
			WIFL_URL . 'assets/css/admin.css',
			array(),
			WIFL_VERSION
		);

		wp_enqueue_script(
			'wifl-admin',
			WIFL_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			WIFL_VERSION,
			true
		);

		wp_localize_script(
			'wifl-admin',
			'wiflAdmin',
			array(
				'i18n' => array(
					'service'  => esc_html__( 'Service type', 'woo-instagram-follower' ),
					'remove'   => esc_html__( 'Remove', 'woo-instagram-follower' ),
					'confirm'  => esc_html__( 'Remove this service type?', 'woo-instagram-follower' ),
					'features' => esc_html__( 'Helping brands reach new audiences.', 'woo-instagram-follower' ),
				),
			)
		);
	}
}
