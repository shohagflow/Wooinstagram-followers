(function ($) {
	'use strict';

	function uid() {
		return Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);
	}

	function featureTemplate(serviceIndex, featureIndex) {
		var html = $('#tmpl-wifl-feature').html() || '';
		return html.replace(/__S__/g, serviceIndex).replace(/__F__/g, featureIndex);
	}

	function packageTemplate(serviceIndex, packageIndex) {
		var html = $('#tmpl-wifl-package').html() || '';
		return html.replace(/__S__/g, serviceIndex).replace(/__P__/g, packageIndex);
	}

	$(document).on('click', '.wifl-remove-service', function (e) {
		e.preventDefault();
		var $cards = $('#wifl-services-wrap .wifl-service-card');
		if ($cards.length <= 1) {
			return;
		}
		var msg = window.wiflAdmin && wiflAdmin.i18n ? wiflAdmin.i18n.confirm : 'Remove this service type?';
		if (window.confirm(msg)) {
			$(this).closest('.wifl-service-card').remove();
			if ($('#wifl-services-wrap .wifl-service-card').length <= 1) {
				$('#wifl-services-wrap .wifl-remove-service').remove();
			}
		}
	});

	$(document).on('click', '.wifl-add-feature', function (e) {
		e.preventDefault();
		var $card = $(this).closest('.wifl-service-card');
		var s = $card.attr('data-service');
		$card.find('.wifl-features-list').append(featureTemplate(s, uid()));
	});

	$(document).on('click', '.wifl-remove-feature', function (e) {
		e.preventDefault();
		var $list = $(this).closest('.wifl-features-list');
		if ($list.find('.wifl-feature-row').length <= 1) {
			$(this).closest('.wifl-feature-row').find('input').val('');
			return;
		}
		$(this).closest('.wifl-feature-row').remove();
	});

	$(document).on('click', '.wifl-add-package', function (e) {
		e.preventDefault();
		var $card = $(this).closest('.wifl-service-card');
		var s = $card.attr('data-service');
		$card.find('.wifl-packages-table tbody').append(packageTemplate(s, uid()));
	});

	$(document).on('click', '.wifl-remove-package', function (e) {
		e.preventDefault();
		var $tbody = $(this).closest('tbody');
		if ($tbody.find('tr').length <= 1) {
			$(this).closest('tr').find('input').val('');
			return;
		}
		$(this).closest('tr').remove();
	});
})(jQuery);
