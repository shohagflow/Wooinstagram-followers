(function () {
	'use strict';

	function qs(sel, root) {
		return (root || document).querySelector(sel);
	}

	function esc(str) {
		return String(str || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function post(action, extra) {
		var cfg = window.wiflFloat || {};
		var body = new URLSearchParams();
		body.set('action', action);
		body.set('nonce', cfg.nonce || '');
		if (extra) {
			Object.keys(extra).forEach(function (key) {
				body.set(key, extra[key]);
			});
		}
		return fetch(cfg.ajaxUrl || '/wp-admin/admin-ajax.php', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (res) {
			return res.json();
		});
	}

	function platIcon(name) {
		var key = String(name || 'instagram');
		if (key === 'tiktok') {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M14.2 3h2.3c.2 2 1.5 3.6 3.5 4v2.4c-1.3 0-2.5-.4-3.5-1.1v6.4A6.7 6.7 0 117.2 8.2v2.5a4.2 4.2 0 104.2 4.2V3z"/></svg>';
		}
		if (key === 'youtube') {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M23 12.2s0-3.2-.4-4.6c-.2-.9-.9-1.6-1.8-1.8C18.9 5.4 12 5.4 12 5.4s-6.9 0-8.8.4c-.9.2-1.6.9-1.8 1.8C1 9 1 12.2 1 12.2s0 3.2.4 4.6c.2.9.9 1.6 1.8 1.8 1.9.4 8.8.4 8.8.4s6.9 0 8.8-.4c.9-.2 1.6-.9 1.8-1.8.4-1.4.4-4.6.4-4.6zM9.8 15.6V8.8l6.4 3.4-6.4 3.4z"/></svg>';
		}
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M7 3h10a4 4 0 014 4v10a4 4 0 01-4 4H7a4 4 0 01-4-4V7a4 4 0 014-4zm5 4.5A4.5 4.5 0 1016.5 12 4.5 4.5 0 0012 7.5zm0 7.4A2.9 2.9 0 1114.9 12 2.9 2.9 0 0112 14.9zM17.4 6.2a1.1 1.1 0 11-1.1 1.1 1.1 1.1 0 011.1-1.1z"/></svg>';
	}

	function thumb(item) {
		if (item.thumb) {
			return '<img class="wifl-line__thumb" src="' + esc(item.thumb) + '" alt="" />';
		}
		return '<span class="wifl-line__thumb"></span>';
	}

	function setCount(root, count) {
		count = parseInt(count, 10) || 0;
		root.setAttribute('data-count', String(count));
		root.hidden = count < 1;
		root.querySelectorAll('.wifl-dock__badge, .wifl-plat__qty').forEach(function (el) {
			el.textContent = String(count);
		});
	}

	function renderDrawer(root, data) {
		var body = qs('#wifl-drawer-body', root);
		var foot = qs('#wifl-drawer-foot', root);
		if (!body || !foot) {
			return;
		}

		var items = data.items || [];
		var html = '';
		if (!items.length) {
			body.innerHTML = '<p class="wifl-empty-cart">Your cart is empty.</p>';
			foot.innerHTML = '';
			return;
		}

		html += '<div class="wifl-card">';
		html += '<div class="wifl-account"><span class="wifl-account__avatar"></span><div>';
		html += '<div class="wifl-account__name">Your Account</div>';
		if (data.savedHtml) {
			html += '<span class="wifl-account__saved">' + data.savedHtml + ' saved!</span>';
		}
		html += '</div></div>';

		var groups = {};
		items.forEach(function (item) {
			var key = item.platform || 'instagram';
			if (!groups[key]) {
				groups[key] = [];
			}
			groups[key].push(item);
		});

		Object.keys(groups).forEach(function (plat) {
			var list = groups[plat];
			html += '<div class="wifl-group-label"><span>' + esc(plat.charAt(0).toUpperCase() + plat.slice(1)) + '</span><span>' + list.length + (list.length === 1 ? ' item' : ' items') + '</span></div>';
			list.forEach(function (item) {
				html += '<div class="wifl-line">';
				html += thumb(item);
				html += '<div><div class="wifl-line__name">' + esc(item.name) + '</div><div class="wifl-line__price">' + (item.saleHtml || '');
				if (item.regularHtml) {
					html += '<span class="wifl-line__regular">' + item.regularHtml + '</span>';
				}
				html += '</div></div>';
				html += '<div class="wifl-line__ctrl">';
				html += '<button type="button" class="wifl-js-remove" data-key="' + esc(item.key) + '" aria-label="Remove">✕</button>';
				html += '<span>' + esc(item.package) + '</span>';
				html += '<button type="button" class="wifl-line__plus wifl-js-open-cart" aria-hidden="true">+</button>';
				html += '</div></div>';
			});
		});
		html += '</div>';

		html += '<h3 class="wifl-section-title">Add more items</h3>';
		html += '<div class="wifl-tabs">';
		(data.tabs || []).forEach(function (tab, i) {
			html += '<button type="button" class="wifl-tab' + (i === 0 ? ' is-active' : '') + '" data-tab="' + esc(tab.id) + '">' + esc(tab.label) + '</button>';
		});
		html += '</div><div class="wifl-card" data-suggest>';

		(data.suggestions || []).forEach(function (item) {
			html += '<div class="wifl-line" data-platform="' + esc(item.platform) + '">';
			html += thumb(item);
			html += '<div><div class="wifl-line__name">' + esc(item.name) + ' <span class="wifl-plat__icon" style="display:inline-flex;width:14px;height:14px;vertical-align:middle">' + platIcon(item.platform) + '</span></div>';
			html += '<div class="wifl-line__price">' + (item.saleHtml || '');
			if (item.regularHtml) {
				html += '<span class="wifl-line__regular">' + item.regularHtml + '</span>';
			}
			html += '</div></div>';
			html += '<button type="button" class="wifl-suggest__add" data-id="' + esc(item.id) + '">+ Add</button>';
			html += '</div>';
		});
		html += '</div>';

		body.innerHTML = html;

		var checkout = data.checkoutUrl || (window.wiflFloat && window.wiflFloat.checkoutUrl) || '/checkout';
		foot.innerHTML =
			'<div><div class="wifl-total-label">Your Total</div><div class="wifl-total-row"><span class="wifl-total-sale">' +
			(data.saleHtml || '') +
			'</span>' +
			(data.regularHtml ? '<span class="wifl-total-regular">' + data.regularHtml + '</span>' : '') +
			'</div></div><a class="wifl-checkout" href="' +
			esc(checkout) +
			'">Checkout</a>';
	}

	function openDrawer(root) {
		var drawer = qs('#wifl-drawer', root);
		if (!drawer) {
			return;
		}
		drawer.hidden = false;
		document.documentElement.style.overflow = 'hidden';
		post('wifl_float_cart').then(function (json) {
			if (json && json.success) {
				renderDrawer(root, json.data || {});
				setCount(root, json.data && json.data.count);
			}
		});
	}

	function closeDrawer(root) {
		var drawer = qs('#wifl-drawer', root);
		if (drawer) {
			drawer.hidden = true;
		}
		document.documentElement.style.overflow = '';
	}

	function bind(root) {
		if (!root || root.getAttribute('data-ready') === '1') {
			return;
		}
		root.setAttribute('data-ready', '1');

		root.addEventListener('click', function (e) {
			if (e.target.closest('.wifl-js-open-cart')) {
				e.preventDefault();
				openDrawer(root);
				return;
			}
			if (e.target.closest('.wifl-js-close-cart')) {
				e.preventDefault();
				closeDrawer(root);
				return;
			}
			var remove = e.target.closest('.wifl-js-remove');
			if (remove) {
				e.preventDefault();
				post('wifl_float_remove', { key: remove.getAttribute('data-key') || '' }).then(function (json) {
					if (json && json.success) {
						renderDrawer(root, json.data || {});
						setCount(root, json.data && json.data.count);
						if (window.jQuery) {
							window.jQuery(document.body).trigger('wc_fragment_refresh');
						}
					}
				});
				return;
			}
			var add = e.target.closest('.wifl-suggest__add');
			if (add) {
				e.preventDefault();
				add.disabled = true;
				post('wifl_float_add', { product_id: add.getAttribute('data-id') || '0' })
					.then(function (json) {
						if (json && json.success) {
							renderDrawer(root, json.data || {});
							setCount(root, json.data && json.data.count);
							if (window.jQuery) {
								window.jQuery(document.body).trigger('added_to_cart', [{}, '', null]);
								window.jQuery(document.body).trigger('wc_fragment_refresh');
							}
						}
					})
					.finally(function () {
						add.disabled = false;
					});
				return;
			}
			var tab = e.target.closest('.wifl-tab');
			if (tab) {
				e.preventDefault();
				root.querySelectorAll('.wifl-tab').forEach(function (el) {
					el.classList.toggle('is-active', el === tab);
				});
				var id = tab.getAttribute('data-tab');
				root.querySelectorAll('[data-suggest] .wifl-line').forEach(function (row) {
					row.hidden = id !== 'all' && row.getAttribute('data-platform') !== id;
				});
			}
		});

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') {
				closeDrawer(root);
			}
		});
	}

	function init() {
		var root = qs('.wifl-float');
		if (!root) {
			return;
		}
		bind(root);
		var count = parseInt(root.getAttribute('data-count'), 10) || 0;
		setCount(root, count);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	if (window.jQuery) {
		window.jQuery(document.body).on('added_to_cart', function () {
			var root = qs('.wifl-float');
			if (!root) {
				return;
			}
			post('wifl_float_cart').then(function (json) {
				if (json && json.success) {
					setCount(root, json.data && json.data.count);
					var drawer = qs('#wifl-drawer', root);
					if (drawer && !drawer.hidden) {
						renderDrawer(root, json.data || {});
					}
				}
			});
		});
	}
})();
