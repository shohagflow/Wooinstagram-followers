<?php
/**
 * Full-page cart template.
 *
 * @package WIFL
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

\WIFL\Cart_Page::instance()->render_page();
