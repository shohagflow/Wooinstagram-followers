<?php
/**
 * Fallback template — custom checkout UI is disabled; use WooCommerce default checkout.
 *
 * @package WIFL
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Intentionally empty: Checkout_Page no longer overrides the checkout template.
status_header( 404 );
nocache_headers();
wp_die( esc_html__( 'This template is unused. Use the WooCommerce checkout page.', 'woo-instagram-follower' ) );
