<?php
/**
 * Cart, mini-cart, and order line-item data.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Cart {

	/**
	 * @var Cart|null
	 */
	private static $instance = null;

	/**
	 * @return Cart
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'apply_custom_price' ), 20, 1 );
		add_filter( 'woocommerce_add_cart_item', array( $this, 'harden_cart_item' ), 20, 1 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'from_session' ), 10, 2 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'cart_item_data' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'order_line_item' ), 10, 4 );
		add_filter( 'woocommerce_add_to_cart_sold_individually_found_in_cart', array( $this, 'allow_repeat_packages' ), 10, 5 );
		add_filter( 'woocommerce_cart_item_thumbnail', array( $this, 'cart_item_thumbnail' ), 20, 3 );
		add_filter( 'woocommerce_store_api_cart_item_images', array( $this, 'store_api_cart_item_images' ), 20, 3 );
	}

	/**
	 * Allow the same product to be added again with a different package.
	 *
	 * @param bool  $found_in_cart Found.
	 * @param int   $product_id    Product ID.
	 * @param int   $variation_id  Variation ID.
	 * @param array $cart_item_data Cart item data.
	 * @param int   $cart_id       Cart id.
	 * @return bool
	 */
	public function allow_repeat_packages( $found_in_cart, $product_id, $variation_id, $cart_item_data, $cart_id ) {
		if ( ! empty( $cart_item_data['wifl'] ) || ! empty( $cart_item_data['wifl_subscription'] ) ) {
			return false;
		}
		return $found_in_cart;
	}

	/**
	 * Re-resolve package from product meta when an item is added.
	 *
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	public function harden_cart_item( $cart_item ) {
		if ( ! empty( $cart_item['wifl_subscription'] ) ) {
			return $this->harden_subscription_item( $cart_item );
		}
		if ( empty( $cart_item['wifl'] ) ) {
			return $cart_item;
		}
		$resolved = Helpers::resolve_cart_wifl( $cart_item );
		if ( ! $resolved ) {
			return $cart_item;
		}
		$cart_item['wifl'] = $resolved;
		if ( ! empty( $cart_item['data'] ) && is_object( $cart_item['data'] ) ) {
			$cart_item['data']->set_price( (float) $resolved['price'] );
		}
		$cart_item['quantity'] = 1;
		return $cart_item;
	}

	/**
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	private function harden_subscription_item( $cart_item ) {
		$product_id = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
		$plan_id    = isset( $cart_item['wifl_subscription']['plan_id'] ) ? $cart_item['wifl_subscription']['plan_id'] : '';
		$payload    = Product_Subscription_Meta::cart_item_payload( $product_id, $plan_id );
		if ( ! $payload ) {
			return $cart_item;
		}
		if ( ! empty( $cart_item['wifl_subscription']['uniq'] ) ) {
			$payload['wifl_subscription']['uniq'] = wc_clean( (string) $cart_item['wifl_subscription']['uniq'] );
		}
		$cart_item['wifl_subscription'] = $payload['wifl_subscription'];
		if ( ! empty( $cart_item['data'] ) && is_object( $cart_item['data'] ) ) {
			$cart_item['data']->set_price( (float) $payload['wifl_subscription']['price'] );
		}
		$cart_item['quantity'] = 1;
		return $cart_item;
	}

	/**
	 * @param \WC_Cart $cart Cart.
	 */
	public function apply_custom_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		if ( ! $cart || ! is_object( $cart ) || ! method_exists( $cart, 'get_cart' ) ) {
			return;
		}

		foreach ( $cart->get_cart() as $key => $item ) {
			if ( ! empty( $item['wifl_subscription'] ) && is_array( $item['wifl_subscription'] ) ) {
				$hardened = $this->harden_subscription_item( $item );
				$cart->cart_contents[ $key ]['wifl_subscription'] = $hardened['wifl_subscription'];
				if ( ! empty( $item['data'] ) && is_object( $item['data'] ) ) {
					$item['data']->set_price( (float) $hardened['wifl_subscription']['price'] );
				}
				if ( (int) $item['quantity'] !== 1 ) {
					$cart->set_quantity( $key, 1, false );
				}
				continue;
			}

			if ( empty( $item['wifl'] ) || ! is_array( $item['wifl'] ) ) {
				continue;
			}

			$resolved = Helpers::resolve_cart_wifl( $item );
			if ( ! $resolved ) {
				$cart->remove_cart_item( $key );
				continue;
			}

			$cart->cart_contents[ $key ]['wifl'] = $resolved;
			if ( ! empty( $item['data'] ) && is_object( $item['data'] ) ) {
				$item['data']->set_price( (float) $resolved['price'] );
			}

			if ( (int) $item['quantity'] !== 1 ) {
				$cart->set_quantity( $key, 1, false );
			}
		}
	}

	/**
	 * @param array $item_data Item data.
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	public function cart_item_data( $item_data, $cart_item ) {
		if ( ! empty( $cart_item['wifl_subscription'] ) && is_array( $cart_item['wifl_subscription'] ) ) {
			$sub = $cart_item['wifl_subscription'];
			if ( ! empty( $sub['qty'] ) ) {
				$label = trim( ( isset( $sub['qty'] ) ? $sub['qty'] : '' ) . ' ' . ( isset( $sub['qty_label'] ) ? $sub['qty_label'] : '' ) );
				$item_data[] = array(
					'key'   => esc_html__( 'Subscription', 'woo-instagram-follower' ),
					'value' => wc_clean( $label ? $label : ( isset( $sub['name'] ) ? $sub['name'] : '' ) ),
				);
			}
			if ( ! empty( $sub['period'] ) ) {
				$item_data[] = array(
					'key'   => esc_html__( 'Billing', 'woo-instagram-follower' ),
					'value' => wc_clean( $sub['period'] ),
				);
			}
			return $item_data;
		}

		if ( empty( $cart_item['wifl'] ) || ! is_array( $cart_item['wifl'] ) ) {
			return $item_data;
		}

		if ( ! empty( $cart_item['wifl']['service'] ) ) {
			$item_data[] = array(
				'key'   => esc_html__( 'Service', 'woo-instagram-follower' ),
				'value' => wc_clean( $cart_item['wifl']['service'] ),
			);
		}

		if ( ! empty( $cart_item['wifl']['qty'] ) ) {
			$item_data[] = array(
				'key'   => esc_html__( 'Package', 'woo-instagram-follower' ),
				'value' => wc_clean( $cart_item['wifl']['qty'] ),
			);
		}

		return $item_data;
	}

	/**
	 * @param \WC_Order_Item_Product $item          Order item.
	 * @param string                 $cart_item_key Cart key.
	 * @param array                  $values        Cart values.
	 * @param \WC_Order              $order         Order.
	 */
	public function order_line_item( $item, $cart_item_key, $values, $order ) {
		if ( ! empty( $values['wifl_subscription'] ) && is_array( $values['wifl_subscription'] ) ) {
			$sub = $values['wifl_subscription'];
			$product_id = isset( $values['product_id'] ) ? (int) $values['product_id'] : 0;
			$payload    = Product_Subscription_Meta::cart_item_payload( $product_id, isset( $sub['plan_id'] ) ? $sub['plan_id'] : '' );
			if ( $payload ) {
				$sub = $payload['wifl_subscription'];
			}
			if ( ! empty( $sub['name'] ) ) {
				$item->add_meta_data( __( 'Plan', 'woo-instagram-follower' ), wc_clean( $sub['name'] ), true );
			}
			$label = trim( ( isset( $sub['qty'] ) ? $sub['qty'] : '' ) . ' ' . ( isset( $sub['qty_label'] ) ? $sub['qty_label'] : '' ) );
			if ( $label ) {
				$item->add_meta_data( __( 'Subscription', 'woo-instagram-follower' ), wc_clean( $label ), true );
			}
			if ( ! empty( $sub['period'] ) ) {
				$item->add_meta_data( __( 'Billing', 'woo-instagram-follower' ), wc_clean( $sub['period'] ), true );
			}
			$item->add_meta_data( '_wifl_subscription', $sub, true );
			return;
		}

		if ( empty( $values['wifl'] ) || ! is_array( $values['wifl'] ) ) {
			return;
		}

		// Always re-resolve from product meta before writing order meta.
		$wifl = Helpers::resolve_cart_wifl( $values );
		if ( ! $wifl ) {
			$wifl = $values['wifl'];
		}

		if ( ! empty( $wifl['service'] ) ) {
			$item->add_meta_data( __( 'Service', 'woo-instagram-follower' ), wc_clean( $wifl['service'] ), true );
		}

		if ( ! empty( $wifl['qty'] ) ) {
			$item->add_meta_data( __( 'Package', 'woo-instagram-follower' ), wc_clean( $wifl['qty'] ), true );
		}

		$accounts = Helpers::get_accounts();
		$pid      = isset( $values['product_id'] ) ? (int) $values['product_id'] : 0;
		$name     = isset( $values['data'] ) && is_object( $values['data'] ) ? $values['data']->get_name() : '';
		$platform = Helpers::platform_key( $pid, $name );
		$user     = ! empty( $accounts[ $platform ] ) ? Helpers::sanitize_username( $accounts[ $platform ] ) : '';
		$targets  = Helpers::get_targets();
		$target   = isset( $targets[ $cart_item_key ] ) ? $targets[ $cart_item_key ] : '';
		if ( $target && ! Helpers::is_allowed_target_url( $target, $platform ) ) {
			$target = '';
		}
		$link = Helpers::resolve_smm_link( $platform, $user, $name, $target );

		if ( $user ) {
			$item->add_meta_data( __( 'Username', 'woo-instagram-follower' ), $user, true );
			$item->add_meta_data( __( 'Platform', 'woo-instagram-follower' ), Helpers::platform_label( $platform ), true );
		}
		if ( $link ) {
			$item->add_meta_data( __( 'Target URL', 'woo-instagram-follower' ), esc_url_raw( $link ), true );
		}

		// Hidden meta for SMM fulfillment (server-resolved only).
		$item->add_meta_data( '_wifl_platform', $platform, true );
		$item->add_meta_data( '_wifl_username', $user, true );
		$item->add_meta_data( '_wifl_target_link', esc_url_raw( $link ), true );
		$item->add_meta_data( '_wifl_qty', isset( $wifl['qty'] ) ? wc_clean( $wifl['qty'] ) : '', true );
		$item->add_meta_data( '_wifl_smm_service_id', isset( $wifl['smm_service_id'] ) ? absint( $wifl['smm_service_id'] ) : 0, true );
		$item->add_meta_data( '_wifl_service_index', isset( $wifl['service_index'] ) ? (int) $wifl['service_index'] : 0, true );
		$item->add_meta_data( '_wifl_package_index', isset( $wifl['package_index'] ) ? (int) $wifl['package_index'] : 0, true );
		$item->add_meta_data( '_wifl_data', $wifl, true );
	}

	/**
	 * Classic cart/checkout thumbnail → platform service icon.
	 *
	 * @param string $thumbnail     HTML.
	 * @param array  $cart_item     Cart item.
	 * @param string $cart_item_key Key.
	 * @return string
	 */
	public function cart_item_thumbnail( $thumbnail, $cart_item, $cart_item_key ) {
		if ( empty( $cart_item['wifl'] ) ) {
			return $thumbnail;
		}
		$url  = Helpers::cart_item_icon_url( $cart_item );
		$alt  = ! empty( $cart_item['data'] ) && is_object( $cart_item['data'] ) ? $cart_item['data']->get_name() : '';
		return sprintf(
			'<img src="%1$s" alt="%2$s" width="48" height="48" class="wifl-cart-thumb" decoding="async" />',
			esc_attr( $url ),
			esc_attr( $alt )
		);
	}

	/**
	 * Cart / Checkout blocks order summary image (Store API).
	 *
	 * @param array  $product_images Images.
	 * @param array  $cart_item      Cart item.
	 * @param string $cart_item_key  Key.
	 * @return array
	 */
	public function store_api_cart_item_images( $product_images, $cart_item, $cart_item_key ) {
		if ( empty( $cart_item['wifl'] ) ) {
			return $product_images;
		}

		$url  = Helpers::cart_item_icon_url( $cart_item );
		$name = ! empty( $cart_item['data'] ) && is_object( $cart_item['data'] ) ? $cart_item['data']->get_name() : __( 'Service', 'woo-instagram-follower' );

		return array(
			(object) array(
				'id'        => 0,
				'src'       => $url,
				'thumbnail' => $url,
				'srcset'    => '',
				'sizes'     => '',
				'name'      => $name,
				'alt'       => $name,
			),
		);
	}

	/**
	 * Keep custom package data when the cart is restored — re-resolved from product meta.
	 *
	 * @param array $cart_item Cart item.
	 * @param array $values    Session values.
	 * @return array
	 */
	public function from_session( $cart_item, $values ) {
		if ( ! empty( $values['wifl_subscription'] ) ) {
			$cart_item['wifl_subscription'] = $values['wifl_subscription'];
			return $this->harden_subscription_item( $cart_item );
		}
		if ( empty( $values['wifl'] ) ) {
			return $cart_item;
		}
		$cart_item['wifl'] = $values['wifl'];
		$resolved          = Helpers::resolve_cart_wifl( $cart_item );
		if ( $resolved ) {
			$cart_item['wifl'] = $resolved;
			if ( ! empty( $cart_item['data'] ) && is_object( $cart_item['data'] ) ) {
				$cart_item['data']->set_price( (float) $resolved['price'] );
			}
		}
		return $cart_item;
	}
}
