<?php
/**
 * Send paid WooCommerce line items to the SMM provider and sync status.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Smm_Fulfillment {

	const CRON_HOOK = 'wifl_smm_sync_statuses';
	const LOG_SOURCE = 'wifl-smm';

	/**
	 * @var Smm_Fulfillment|null
	 */
	private static $instance = null;

	/**
	 * @return Smm_Fulfillment
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( 'woocommerce_payment_complete', array( $this, 'on_payment_complete' ), 20 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'on_status_change' ), 20 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'on_status_change' ), 20 );
		add_action( self::CRON_HOOK, array( $this, 'sync_open_orders' ) );

		add_action( 'init', array( $this, 'maybe_schedule_cron' ) );
		register_deactivation_hook( WIFL_FILE, array( __CLASS__, 'clear_cron' ) );

		add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'admin_order_box' ) );
		add_action( 'woocommerce_order_item_add_action_buttons', array( $this, 'admin_item_actions' ), 10, 1 );
		add_action( 'admin_post_wifl_smm_retry_item', array( $this, 'admin_retry_item' ) );
	}

	public function maybe_schedule_cron() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 120, 'five_minutes', self::CRON_HOOK );
		}
	}

	/**
	 * Register a 5-minute cron schedule.
	 *
	 * @param array $schedules Schedules.
	 * @return array
	 */
	public static function cron_schedules( $schedules ) {
		if ( empty( $schedules['five_minutes'] ) ) {
			$schedules['five_minutes'] = array(
				'interval' => 300,
				'display'  => __( 'Every five minutes', 'woo-instagram-follower' ),
			);
		}
		return $schedules;
	}

	public static function clear_cron() {
		$ts = wp_next_scheduled( self::CRON_HOOK );
		if ( $ts ) {
			wp_unschedule_event( $ts, self::CRON_HOOK );
		}
	}

	/**
	 * @param int $order_id Order ID.
	 */
	public function on_payment_complete( $order_id ) {
		$this->fulfill_order( (int) $order_id );
	}

	/**
	 * @param int $order_id Order ID.
	 */
	public function on_status_change( $order_id ) {
		$this->fulfill_order( (int) $order_id );
	}

	/**
	 * Create provider orders for each WIFL line item (once).
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function fulfill_order( $order_id ) {
		$order_id = (int) $order_id;
		if ( $order_id < 1 || ! Smm_Api::is_enabled() ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		if ( ! $this->order_ready( $order ) ) {
			return;
		}

		// Order-level lock against concurrent hooks.
		$lock_key = '_wifl_smm_fulfill_lock';
		$lock     = (int) $order->get_meta( $lock_key );
		if ( $lock && ( time() - $lock ) < 60 ) {
			return;
		}
		$order->update_meta_data( $lock_key, time() );
		$order->save();

		$needs_status = false;

		foreach ( $order->get_items() as $item_id => $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product ) {
				continue;
			}

			$result = $this->fulfill_item( $order, $item, (int) $item_id );
			if ( ! empty( $result['provider_id'] ) ) {
				$needs_status = true;
			}
		}

		if ( $needs_status ) {
			$order->update_meta_data( '_wifl_smm_needs_status', 'yes' );
		}

		$order->delete_meta_data( $lock_key );
		$order->save();
	}

	/**
	 * @param \WC_Order $order Order.
	 * @return bool
	 */
	private function order_ready( $order ) {
		if ( $order->has_status( array( 'processing', 'completed' ) ) ) {
			return true;
		}
		if ( method_exists( $order, 'is_paid' ) && $order->is_paid() ) {
			return true;
		}
		return false;
	}

	/**
	 * @param \WC_Order              $order   Order.
	 * @param \WC_Order_Item_Product $item    Item.
	 * @param int                    $item_id Item ID.
	 * @return array{provider_id?:string,error?:string,skipped?:bool}
	 */
	private function fulfill_item( $order, $item, $item_id ) {
		$existing = $item->get_meta( '_wifl_smm_order_id', true );
		if ( $existing ) {
			return array(
				'provider_id' => (string) $existing,
				'skipped'     => true,
			);
		}

		// Already attempted successfully flag (race).
		if ( 'yes' === $item->get_meta( '_wifl_smm_sent', true ) ) {
			return array( 'skipped' => true );
		}

		$service_id = absint( $item->get_meta( '_wifl_smm_service_id', true ) );
		$qty        = preg_replace( '/[^0-9]/', '', (string) $item->get_meta( '_wifl_qty', true ) );
		$platform   = (string) $item->get_meta( '_wifl_platform', true );
		$username   = ltrim( (string) $item->get_meta( '_wifl_username', true ), '@' );
		$target     = (string) $item->get_meta( '_wifl_target_link', true );
		$product_name = $item->get_name();

		// Always prefer product meta (indexes) over stored service ID.
		$from_product = $this->resolve_service_id_from_product( $item );
		if ( $from_product > 0 ) {
			$service_id = $from_product;
		}
		if ( ! $qty ) {
			$wifl = $item->get_meta( '_wifl_data', true );
			if ( is_array( $wifl ) && ! empty( $wifl['qty'] ) ) {
				$qty = preg_replace( '/[^0-9]/', '', (string) $wifl['qty'] );
			}
		}
		// Re-resolve qty from product package when indexes exist.
		$s = (int) $item->get_meta( '_wifl_service_index', true );
		$p = (int) $item->get_meta( '_wifl_package_index', true );
		$services = Helpers::get_services( $item->get_product_id() );
		if ( ! empty( $services[ $s ]['packages'][ $p ]['qty'] ) ) {
			$qty = preg_replace( '/[^0-9]/', '', (string) $services[ $s ]['packages'][ $p ]['qty'] );
		}
		if ( ! $username ) {
			$username = Helpers::sanitize_username( (string) $item->get_meta( __( 'Username', 'woo-instagram-follower' ), true ) );
		} else {
			$username = Helpers::sanitize_username( $username );
		}
		if ( ! $target ) {
			$target = (string) $item->get_meta( __( 'Target URL', 'woo-instagram-follower' ), true );
		}
		if ( $target && ! Helpers::is_allowed_target_url( $target, $platform ) ) {
			$target = '';
		}
		if ( ! $platform ) {
			$pid  = $item->get_product_id();
			$platform = Helpers::platform_key( $pid, $product_name );
		}

		if ( $service_id < 1 ) {
			$msg = __( 'SMM skipped: no Service ID mapped for this package.', 'woo-instagram-follower' );
			$this->fail_item( $order, $item, $msg );
			return array( 'error' => $msg );
		}

		if ( ! $qty ) {
			$msg = __( 'SMM skipped: package quantity missing.', 'woo-instagram-follower' );
			$this->fail_item( $order, $item, $msg );
			return array( 'error' => $msg );
		}

		$needs_post = Helpers::needs_post_link( $product_name );
		if ( $needs_post && ! $target ) {
			$msg = __( 'SMM skipped: post/reel URL missing for this package.', 'woo-instagram-follower' );
			$this->fail_item( $order, $item, $msg );
			return array( 'error' => $msg );
		}

		if ( ! $needs_post && ! $username && ! $target ) {
			$msg = __( 'SMM skipped: username missing for this line item.', 'woo-instagram-follower' );
			$this->fail_item( $order, $item, $msg );
			return array( 'error' => $msg );
		}

		$link = Helpers::resolve_smm_link( $platform, $username, $product_name, $target );
		if ( ! $link ) {
			$msg = __( 'SMM skipped: could not build target link.', 'woo-instagram-follower' );
			$this->fail_item( $order, $item, $msg );
			return array( 'error' => $msg );
		}

		// Mark sent BEFORE the API call to prevent duplicate submits on concurrent hooks.
		$item->update_meta_data( '_wifl_smm_sent', 'yes' );
		$item->update_meta_data( '_wifl_smm_status', 'Submitting' );
		$item->save();

		$response = Smm_Api::request(
			'add',
			array(
				'service'  => $service_id,
				'link'     => $link,
				'quantity' => (int) $qty,
			)
		);

		if ( is_wp_error( $response ) ) {
			$item->delete_meta_data( '_wifl_smm_sent' );
			$item->save();
			$this->fail_item( $order, $item, $response->get_error_message(), $response->get_error_data() );
			return array( 'error' => $response->get_error_message() );
		}

		if ( ! empty( $response['error'] ) ) {
			$item->delete_meta_data( '_wifl_smm_sent' );
			$item->save();
			$msg = (string) $response['error'];
			$this->fail_item( $order, $item, $msg, $response );
			return array( 'error' => $msg );
		}

		$provider_id = isset( $response['order'] ) ? (string) $response['order'] : '';
		if ( '' === $provider_id ) {
			$item->delete_meta_data( '_wifl_smm_sent' );
			$item->save();
			$msg = __( 'SMM API returned no order ID.', 'woo-instagram-follower' );
			$this->fail_item( $order, $item, $msg, $response );
			return array( 'error' => $msg );
		}

		$item->update_meta_data( '_wifl_smm_order_id', $provider_id );
		$item->update_meta_data( '_wifl_smm_status', 'Pending' );
		$item->update_meta_data( '_wifl_smm_link', $link );
		$item->delete_meta_data( '_wifl_smm_last_error' );
		$item->update_meta_data( 'SMM Order ID', $provider_id );
		$item->update_meta_data( 'SMM Status', 'Pending' );
		$item->save();

		$order->add_order_note(
			sprintf(
				/* translators: 1: item id, 2: provider order id, 3: link */
				__( 'SMM order created for item #%1$d → Provider ID %2$s (%3$s).', 'woo-instagram-follower' ),
				$item_id,
				$provider_id,
				$link
			)
		);

		$this->log(
			'info',
			sprintf( 'Order %d item %d → provider %s', $order->get_id(), $item_id, $provider_id ),
			array(
				'service' => $service_id,
				'qty'     => $qty,
				'link'    => $link,
			)
		);

		return array( 'provider_id' => $provider_id );
	}

	/**
	 * @param \WC_Order_Item_Product $item Item.
	 * @return int
	 */
	private function resolve_service_id_from_product( $item ) {
		$s = (int) $item->get_meta( '_wifl_service_index', true );
		$p = (int) $item->get_meta( '_wifl_package_index', true );
		$wifl = $item->get_meta( '_wifl_data', true );
		if ( ( ! $s && ! $p ) && is_array( $wifl ) ) {
			$s = isset( $wifl['service_index'] ) ? (int) $wifl['service_index'] : 0;
			$p = isset( $wifl['package_index'] ) ? (int) $wifl['package_index'] : 0;
		}
		$services = Helpers::get_services( $item->get_product_id() );
		if ( ! empty( $services[ $s ]['packages'][ $p ]['smm_service_id'] ) ) {
			return absint( $services[ $s ]['packages'][ $p ]['smm_service_id'] );
		}
		// Do not fall back to a client-influenced smm_service_id blob.
		return 0;
	}

	/**
	 * @param \WC_Order              $order   Order.
	 * @param \WC_Order_Item_Product $item    Item.
	 * @param string                 $message Message.
	 * @param mixed                  $context Context.
	 */
	private function fail_item( $order, $item, $message, $context = null ) {
		$item->update_meta_data( '_wifl_smm_status', 'Failed' );
		$item->update_meta_data( '_wifl_smm_last_error', wc_clean( $message ) );
		$item->update_meta_data( 'SMM Status', 'Failed' );
		$item->save();

		$order->add_order_note(
			sprintf(
				/* translators: %s: error */
				__( 'SMM fulfillment error: %s', 'woo-instagram-follower' ),
				$message
			)
		);

		$this->log(
			'error',
			sprintf( 'Order %d item %d: %s', $order->get_id(), $item->get_id(), $message ),
			is_array( $context ) ? $context : array( 'context' => $context )
		);
	}

	/**
	 * Poll provider for open SMM orders.
	 */
	public function sync_open_orders() {
		if ( ! Smm_Api::is_enabled() || ! function_exists( 'wc_get_orders' ) ) {
			return;
		}

		$orders = wc_get_orders(
			array(
				'limit'      => 30,
				'status'     => array( 'processing', 'completed' ),
				'meta_key'   => '_wifl_smm_needs_status',
				'meta_value' => 'yes',
				'return'     => 'objects',
			)
		);

		foreach ( $orders as $order ) {
			$this->sync_order_status( $order );
		}
	}

	/**
	 * @param \WC_Order $order Order.
	 */
	public function sync_order_status( $order ) {
		if ( ! $order ) {
			return;
		}

		$provider_ids = array();
		$map          = array(); // provider_id => item

		foreach ( $order->get_items() as $item_id => $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product ) {
				continue;
			}
			$pid = (string) $item->get_meta( '_wifl_smm_order_id', true );
			if ( ! $pid ) {
				continue;
			}
			$status = strtolower( (string) $item->get_meta( '_wifl_smm_status', true ) );
			if ( in_array( $status, array( 'completed', 'canceled', 'cancelled', 'refunded' ), true ) ) {
				continue;
			}
			$provider_ids[]    = $pid;
			$map[ $pid ]       = $item;
		}

		if ( empty( $provider_ids ) ) {
			$order->delete_meta_data( '_wifl_smm_needs_status' );
			$order->save();
			return;
		}

		// Batch up to 100.
		$chunks = array_chunk( $provider_ids, 100 );
		$all_done = true;

		foreach ( $chunks as $chunk ) {
			$response = Smm_Api::request(
				'status',
				array(
					'orders' => implode( ',', $chunk ),
				)
			);

			if ( is_wp_error( $response ) ) {
				$this->log( 'error', 'Status sync failed: ' . $response->get_error_message(), array( 'order' => $order->get_id() ) );
				$all_done = false;
				continue;
			}

			// Single-order response shape when only one ID was sent without batch.
			if ( isset( $response['status'] ) && 1 === count( $chunk ) ) {
				$response = array( $chunk[0] => $response );
			}

			foreach ( $chunk as $pid ) {
				$row = isset( $response[ $pid ] ) ? $response[ $pid ] : null;
				if ( ! $row || ! is_array( $row ) ) {
					$all_done = false;
					continue;
				}
				if ( ! empty( $row['error'] ) ) {
					$all_done = false;
					continue;
				}

				$item   = isset( $map[ $pid ] ) ? $map[ $pid ] : null;
				$status = isset( $row['status'] ) ? (string) $row['status'] : '';
				if ( ! $item || ! $status ) {
					$all_done = false;
					continue;
				}

				$item->update_meta_data( '_wifl_smm_status', $status );
				$item->update_meta_data( 'SMM Status', $status );
				if ( isset( $row['start_count'] ) ) {
					$item->update_meta_data( '_wifl_smm_start_count', $row['start_count'] );
				}
				if ( isset( $row['remains'] ) ) {
					$item->update_meta_data( '_wifl_smm_remains', $row['remains'] );
				}
				if ( isset( $row['charge'] ) ) {
					$item->update_meta_data( '_wifl_smm_charge', $row['charge'] );
				}
				$item->save();

				$normalized = strtolower( $status );
				if ( ! in_array( $normalized, array( 'completed', 'canceled', 'cancelled', 'refunded' ), true ) ) {
					$all_done = false;
				}
			}
		}

		if ( $all_done ) {
			$order->delete_meta_data( '_wifl_smm_needs_status' );
			$order->add_order_note( __( 'All SMM provider orders reached a final status.', 'woo-instagram-follower' ) );
		}

		$order->save();
	}

	/**
	 * @param \WC_Order $order Order.
	 */
	public function admin_order_box( $order ) {
		if ( ! $order || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$rows = array();
		foreach ( $order->get_items() as $item_id => $item ) {
			$provider = $item->get_meta( '_wifl_smm_order_id', true );
			$status   = $item->get_meta( '_wifl_smm_status', true );
			$error    = $item->get_meta( '_wifl_smm_last_error', true );
			if ( ! $provider && ! $status && ! $error ) {
				continue;
			}
			$rows[] = array(
				'item'     => $item_id,
				'name'     => $item->get_name(),
				'provider' => $provider,
				'status'   => $status,
				'error'    => $error,
			);
		}

		if ( empty( $rows ) ) {
			return;
		}
		?>
		<div class="wifl-smm-order-box" style="margin-top:16px;padding:12px;background:#fff;border:1px solid #dcdcde;">
			<h3 style="margin-top:0;"><?php esc_html_e( 'SMM Fulfillment', 'woo-instagram-follower' ); ?></h3>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Item', 'woo-instagram-follower' ); ?></th>
						<th><?php esc_html_e( 'Provider Order', 'woo-instagram-follower' ); ?></th>
						<th><?php esc_html_e( 'Status', 'woo-instagram-follower' ); ?></th>
						<th><?php esc_html_e( 'Error', 'woo-instagram-follower' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<td>#<?php echo esc_html( (string) $row['item'] ); ?> <?php echo esc_html( $row['name'] ); ?></td>
							<td><?php echo esc_html( $row['provider'] ? (string) $row['provider'] : '—' ); ?></td>
							<td><?php echo esc_html( $row['status'] ? (string) $row['status'] : '—' ); ?></td>
							<td><?php echo esc_html( $row['error'] ? (string) $row['error'] : '—' ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * @param \WC_Order_Item $item Item.
	 */
	public function admin_item_actions( $item ) {
		if ( ! $item instanceof \WC_Order_Item_Product || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( $item->get_meta( '_wifl_smm_order_id', true ) ) {
			return;
		}
		if ( ! $item->get_meta( '_wifl_smm_service_id', true ) && ! $item->get_meta( '_wifl_data', true ) ) {
			return;
		}

		$url = wp_nonce_url(
			add_query_arg(
				array(
					'action'   => 'wifl_smm_retry_item',
					'order_id' => $item->get_order_id(),
					'item_id'  => $item->get_id(),
				),
				admin_url( 'admin-post.php' )
			),
			'wifl_smm_retry_' . $item->get_id()
		);
		echo '<a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Retry SMM order', 'woo-instagram-follower' ) . '</a> ';
	}

	public function admin_retry_item() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Forbidden', 'woo-instagram-follower' ) );
		}
		$item_id  = isset( $_GET['item_id'] ) ? absint( $_GET['item_id'] ) : 0;
		$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		check_admin_referer( 'wifl_smm_retry_' . $item_id );

		$order = wc_get_order( $order_id );
		$item  = $order ? $order->get_item( $item_id ) : null;
		if ( $item instanceof \WC_Order_Item_Product ) {
			$item->delete_meta_data( '_wifl_smm_sent' );
			$item->delete_meta_data( '_wifl_smm_order_id' );
			$item->delete_meta_data( '_wifl_smm_last_error' );
			$item->save();
			$this->fulfill_item( $order, $item, $item_id );
			if ( $item->get_meta( '_wifl_smm_order_id', true ) ) {
				$order->update_meta_data( '_wifl_smm_needs_status', 'yes' );
			}
			$order->save();
		}

		wp_safe_redirect( admin_url( 'post.php?post=' . $order_id . '&action=edit' ) );
		exit;
	}

	/**
	 * @param string $level   Level.
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	private function log( $level, $message, $context = array() ) {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}
		$logger = wc_get_logger();
		$logger->log(
			$level,
			$message,
			array_merge(
				array( 'source' => self::LOG_SOURCE ),
				$context
			)
		);
	}
}
