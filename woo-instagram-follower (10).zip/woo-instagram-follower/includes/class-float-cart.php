<?php
/**
 * Floating View cart dock + side drawer.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Float_Cart {

	/**
	 * @var Float_Cart|null
	 */
	private static $instance = null;

	/**
	 * @var bool
	 */
	private $rendered = false;

	/**
	 * @return Float_Cart
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 99 );
		add_action( 'wp_body_open', array( $this, 'render' ), 20 );
		add_action( 'wp_footer', array( $this, 'render' ), 5 );
		add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'fragments' ) );
		add_action( 'wp_ajax_wifl_float_cart', array( $this, 'ajax_cart' ) );
		add_action( 'wp_ajax_nopriv_wifl_float_cart', array( $this, 'ajax_cart' ) );
		add_action( 'wp_ajax_wifl_float_remove', array( $this, 'ajax_remove' ) );
		add_action( 'wp_ajax_nopriv_wifl_float_remove', array( $this, 'ajax_remove' ) );
		add_action( 'wp_ajax_wifl_float_add', array( $this, 'ajax_add' ) );
		add_action( 'wp_ajax_nopriv_wifl_float_add', array( $this, 'ajax_add' ) );
	}

	public function enqueue() {
		if ( is_admin() || ! function_exists( 'WC' ) ) {
			return;
		}

		$settings = Float_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}

		$this->load_frontend_assets();
	}

	/**
	 * Register and enqueue floating cart assets (drawer + optional dock).
	 */
	public function load_frontend_assets() {
		if ( is_admin() || ! function_exists( 'WC' ) ) {
			return;
		}

		$settings = Float_Settings::get();

		wp_register_style(
			'wifl-float-cart',
			WIFL_URL . 'assets/css/float-cart.css',
			array(),
			WIFL_VERSION
		);

		wp_register_script(
			'wifl-float-cart',
			WIFL_URL . 'assets/js/float-cart.js',
			array(),
			WIFL_VERSION,
			true
		);

		wp_enqueue_style( 'wifl-float-cart' );

		$css = sprintf(
			'.wifl-float{--wifl-float-bg:%1$s;--wifl-float-text:%2$s;--wifl-float-badge:%3$s;--wifl-float-view-bg:%4$s;--wifl-float-accent:%5$s;--wifl-float-radius:%6$spx;--wifl-float-label-size:%7$spx;right:%8$spx;bottom:%9$spx;}',
			esc_attr( $settings['dock_bg'] ),
			esc_attr( $settings['text_color'] ),
			esc_attr( $settings['badge_bg'] ),
			esc_attr( $settings['view_bg'] ),
			esc_attr( $settings['accent'] ),
			esc_attr( $settings['radius'] ),
			esc_attr( $settings['font_size'] ),
			esc_attr( $settings['offset_right'] ),
			esc_attr( $settings['offset_bottom'] )
		);
		wp_add_inline_style( 'wifl-float-cart', $css );

		wp_enqueue_script( 'wifl-float-cart' );

		$this->ensure_cart();

		wp_localize_script(
			'wifl-float-cart',
			'wiflFloat',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wifl_float_cart' ),
				'checkoutUrl' => $this->cart_url(),
				'shopUrl'     => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
				'cart'        => $this->cart_payload(),
			)
		);
	}

	/**
	 * Load floating cart assets when another component (e.g. CT cart menu) needs the drawer.
	 */
	public function ensure_frontend_assets() {
		$this->load_frontend_assets();
	}

	/**
	 * @param array $fragments Fragments.
	 * @return array
	 */
	public function fragments( $fragments ) {
		$count = $this->cart_count();
		$fragments['span.wifl-dock__badge']      = $this->badge_html( $count );
		$fragments['span.wifl-dock__plats-mini'] = $this->dock_icons_html();
		$fragments['div.wifl-dock__plats']       = $this->platforms_html();
		$fragments['span.wifl-float-sync']       = '<span class="wifl-float-sync" data-count="' . esc_attr( (string) $count ) . '" hidden></span>';
		$fragments['.wifl-cart-menu__badge']     = '<span class="wifl-cart-menu__badge">' . esc_html( (string) max( 0, $count ) ) . '</span>';
		return $fragments;
	}

	public function render() {
		if ( $this->rendered ) {
			return;
		}
		if ( is_admin() || ! function_exists( 'WC' ) ) {
			return;
		}
		$settings = Float_Settings::get();
		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
			return;
		}

		$this->ensure_cart();
		$count     = $this->cart_count();
		$show_dock = ( 'yes' === $settings['enabled'] );
		$label     = $settings['button_text'];
		$extra     = ( 'yes' !== $settings['show_hover'] ) ? ' wifl-float--simple' : '';
		if ( ! $show_dock ) {
			$extra .= ' wifl-float--drawer-only';
		}
		?>
		<div class="wifl-float<?php echo esc_attr( $extra ); ?>" data-count="<?php echo esc_attr( (string) $count ); ?>">
			<span class="wifl-float-sync" data-count="<?php echo esc_attr( (string) $count ); ?>" hidden></span>
			<?php if ( $show_dock ) : ?>
			<div class="wifl-dock" id="wifl-dock">
				<button type="button" class="wifl-dock__collapsed wifl-js-open-cart" aria-label="<?php echo esc_attr( $label ); ?>">
					<?php echo $this->dock_icons_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo $this->badge_html( $count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span class="wifl-dock__label"><?php echo esc_html( $label ); ?></span>
				</button>
				<div class="wifl-dock__expanded">
					<?php echo $this->platforms_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<button type="button" class="wifl-dock__view wifl-js-open-cart"><?php echo esc_html( $label ); ?></button>
				</div>
			</div>
			<?php endif; ?>

			<div class="wifl-drawer" id="wifl-drawer" hidden>
				<div class="wifl-drawer__overlay wifl-js-close-cart"></div>
				<aside class="wifl-drawer__panel" role="dialog" aria-modal="true" aria-labelledby="wifl-drawer-title">
					<div class="wifl-drawer__head">
						<button type="button" class="wifl-drawer__back wifl-js-close-cart" aria-label="<?php esc_attr_e( 'Close cart', 'woo-instagram-follower' ); ?>">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>
						</button>
						<h2 id="wifl-drawer-title"><?php esc_html_e( 'Your Cart', 'woo-instagram-follower' ); ?></h2>
						<span class="wifl-drawer__head-spacer"></span>
					</div>
					<div class="wifl-drawer__body" id="wifl-drawer-body"></div>
					<div class="wifl-drawer__foot" id="wifl-drawer-foot"></div>
				</aside>
			</div>
		</div>
		<?php
		$this->rendered = true;
	}

	public function ajax_cart() {
		$this->ensure_cart();
		wp_send_json_success( $this->cart_payload() );
	}

	public function ajax_remove() {
		check_ajax_referer( 'wifl_float_cart', 'nonce' );
		$this->ensure_cart();
		$key = isset( $_POST['key'] ) ? wc_clean( wp_unslash( $_POST['key'] ) ) : '';
		if ( $key && WC()->cart ) {
			WC()->cart->remove_cart_item( $key );
			WC()->cart->calculate_totals();
		}
		wp_send_json_success( $this->cart_payload() );
	}

	public function ajax_add() {
		check_ajax_referer( 'wifl_float_cart', 'nonce' );
		$this->ensure_cart();

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$services   = $product_id ? Helpers::get_services( $product_id ) : array();
		if ( empty( $services[0]['packages'][0] ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid product.', 'woo-instagram-follower' ) ), 400 );
		}

		$product = wc_get_product( $product_id );
		$package = $services[0]['packages'][0];
		if ( ! $product ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Product not found.', 'woo-instagram-follower' ) ), 404 );
		}

		WC()->cart->add_to_cart(
			$product_id,
			1,
			0,
			array(),
			Helpers::cart_item_data( $product, $package, 0, 0 )
		);
		WC()->cart->calculate_totals();
		wp_send_json_success( $this->cart_payload() );
	}

	/**
	 * @return array
	 */
	public function cart_payload() {
		$items         = array();
		$sale_total    = 0;
		$regular_total = 0;
		$in_cart       = array();

		if ( WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $key => $item ) {
				$product = isset( $item['data'] ) ? $item['data'] : null;
				if ( ! $product ) {
					continue;
				}
				$pid     = (int) $item['product_id'];
				$wifl    = ! empty( $item['wifl'] ) && is_array( $item['wifl'] ) ? $item['wifl'] : array();
				$qty     = isset( $item['quantity'] ) ? (int) $item['quantity'] : 1;
				$sale    = isset( $wifl['price'] ) ? (float) $wifl['price'] * $qty : (float) $product->get_price() * $qty;
				$regular = isset( $wifl['regular'] ) ? (float) $wifl['regular'] * $qty : $sale;
				$name    = $product->get_name();
				$pkg     = isset( $wifl['qty'] ) ? $wifl['qty'] : (string) $qty;

				$sale_total      += $sale;
				$regular_total   += $regular;
				$in_cart[ $pid ]  = true;

				$items[] = array(
					'key'         => $key,
					'name'        => $name,
					'package'     => $pkg,
					'badge'       => $this->qty_badge( $pkg ),
					'icon'        => $this->service_icon( $name ),
					'platform'    => $this->platform_key( $pid, $name ),
					'saleHtml'    => Helpers::price_html( $sale ),
					'regularHtml' => $regular > $sale ? Helpers::price_html( $regular ) : '',
				);
			}
		}

		$saved = max( 0, $regular_total - $sale_total );

		return array(
			'count'        => $this->cart_count(),
			'items'        => $items,
			'suggestions'  => $this->suggestions( array_keys( $in_cart ) ),
			'tabs'         => $this->suggestion_tabs(),
			'saleHtml'     => Helpers::price_html( $sale_total ),
			'regularHtml'  => $regular_total > $sale_total ? Helpers::price_html( $regular_total ) : '',
			'savedHtml'    => $saved > 0 ? Helpers::price_html( $saved ) : '',
			'checkoutUrl'  => $this->cart_url(),
			'platformsHtml'=> $this->platforms_html(),
			'dockIconsHtml'=> $this->dock_icons_html(),
		);
	}

	/**
	 * Cart page URL for the float Checkout button (accounts / details step).
	 *
	 * @return string
	 */
	private function cart_url() {
		$home = untrailingslashit( home_url( '/' ) );
		$url  = '';

		if ( function_exists( 'wc_get_page_id' ) ) {
			$cart_id = (int) wc_get_page_id( 'cart' );
			if ( $cart_id > 0 ) {
				$permalink = get_permalink( $cart_id );
				if ( $permalink ) {
					$url = (string) $permalink;
				}
			}
		}

		if ( ! $url && function_exists( 'wc_get_cart_url' ) ) {
			$url = (string) wc_get_cart_url();
		}

		// If Woo returns the homepage (cart page unset / wrong), force /cart/.
		if ( ! $url || untrailingslashit( $url ) === $home ) {
			$page = get_page_by_path( 'cart' );
			if ( $page && ! empty( $page->ID ) ) {
				$permalink = get_permalink( (int) $page->ID );
				if ( $permalink && untrailingslashit( $permalink ) !== $home ) {
					return $permalink;
				}
			}
			return trailingslashit( $home ) . 'cart/';
		}

		return $url;
	}

	/**
	 * @param int[] $exclude Product IDs.
	 * @return array
	 */
	private function suggestions( $exclude ) {
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'numberposts'    => 8,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'post__not_in'   => array_map( 'intval', $exclude ),
			)
		);

		$out = array();
		foreach ( (array) $ids as $id ) {
			$services = Helpers::get_services( (int) $id );
			if ( empty( $services ) ) {
				continue;
			}
			$payload = Helpers::services_payload( $services, (int) $id );
			$pkg     = isset( $payload[0]['packages'][0] ) ? $payload[0]['packages'][0] : null;
			$product = wc_get_product( $id );
			if ( ! $product || ! $pkg ) {
				continue;
			}
			$out[] = array(
				'id'          => (int) $id,
				'name'        => $product->get_name(),
				'badge'       => $this->qty_badge( isset( $pkg['qty'] ) ? $pkg['qty'] : '' ),
				'icon'        => $this->service_icon( $product->get_name() ),
				'platform'    => $this->platform_key( (int) $id, $product->get_name() ),
				'saleHtml'    => $pkg['saleHtml'],
				'regularHtml' => $pkg['regularHtml'],
			);
			if ( count( $out ) >= 6 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * @return array
	 */
	private function suggestion_tabs() {
		$tabs = array(
			array(
				'id'    => 'all',
				'label' => __( 'For you', 'woo-instagram-follower' ),
			),
		);
		foreach ( $this->platforms() as $plat ) {
			$tabs[] = array(
				'id'    => $plat['key'],
				'label' => $plat['label'],
			);
		}
		return $tabs;
	}

	/**
	 * @return array
	 */
	private function platforms() {
		$shop   = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
		$counts = $this->platform_counts();
		// Floating dock only shows Instagram, TikTok, and YouTube.
		$order  = array( 'instagram', 'tiktok', 'youtube' );
		$out    = array();

		foreach ( $order as $key ) {
			$count = isset( $counts[ $key ] ) ? (int) $counts[ $key ] : 0;
			$out[] = array(
				'key'    => $key,
				'label'  => Helpers::platform_label( $key ),
				'url'    => $this->platform_url( $key, $shop ),
				'icon'   => Helpers::platform_icon( $key ),
				'active' => $count > 0,
				'count'  => $count,
			);
		}

		return $out;
	}

	/**
	 * Cart line counts keyed by platform.
	 *
	 * @return array<string,int>
	 */
	private function platform_counts() {
		$counts = array();
		if ( ! WC()->cart ) {
			return $counts;
		}
		foreach ( WC()->cart->get_cart() as $item ) {
			$pid  = (int) $item['product_id'];
			$name = isset( $item['data'] ) && is_object( $item['data'] ) ? $item['data']->get_name() : '';
			$key  = Helpers::platform_key( $pid, $name );
			$qty  = isset( $item['quantity'] ) ? max( 1, (int) $item['quantity'] ) : 1;
			if ( ! isset( $counts[ $key ] ) ) {
				$counts[ $key ] = 0;
			}
			$counts[ $key ] += $qty;
		}
		return $counts;
	}

	/**
	 * Expanded dock platform chips.
	 *
	 * @return string
	 */
	private function platforms_html() {
		$html = '<div class="wifl-dock__plats">';
		foreach ( $this->platforms() as $plat ) {
			$active = ! empty( $plat['active'] );
			$html  .= '<a class="wifl-plat' . ( $active ? ' is-active' : ' is-plus' ) . '" href="' . esc_url( $plat['url'] ) . '" title="' . esc_attr( $plat['label'] ) . '" data-platform="' . esc_attr( $plat['key'] ) . '">';
			$html  .= '<span class="wifl-plat__icon" aria-hidden="true">' . $plat['icon'] . '</span>';
			if ( $active ) {
				$html .= '<span class="wifl-plat__qty">' . esc_html( (string) $plat['count'] ) . '</span>';
			} else {
				$html .= '<span class="wifl-plat__add">+</span>';
			}
			$html .= '</a>';
		}
		$html .= '</div>';
		return $html;
	}

	/**
	 * Collapsed dock: icons for platforms currently in the cart.
	 *
	 * @return string
	 */
	private function dock_icons_html() {
		$active = array();
		foreach ( $this->platforms() as $plat ) {
			if ( ! empty( $plat['active'] ) ) {
				$active[] = $plat;
			}
		}

		$html = '<span class="wifl-dock__plats-mini" aria-hidden="true">';
		if ( empty( $active ) ) {
			$html .= '<span class="wifl-dock__plat-mini is-empty">' . Helpers::platform_icon( 'instagram' ) . '</span>';
		} else {
			foreach ( $active as $plat ) {
				$html .= '<span class="wifl-dock__plat-mini" title="' . esc_attr( $plat['label'] ) . '" data-platform="' . esc_attr( $plat['key'] ) . '">' . $plat['icon'] . '</span>';
			}
		}
		$html .= '</span>';
		return $html;
	}

	/**
	 * @param string $key  Platform key.
	 * @param string $shop Shop URL.
	 * @return string
	 */
	private function platform_url( $key, $shop ) {
		$term = get_term_by( 'slug', $key, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			$link = get_term_link( $term );
			if ( ! is_wp_error( $link ) ) {
				return $link;
			}
		}
		return $shop;
	}

	/**
	 * @return int
	 */
	private function cart_count() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return 0;
		}
		return (int) WC()->cart->get_cart_contents_count();
	}

	/**
	 * @param int $count Count.
	 * @return string
	 */
	private function badge_html( $count ) {
		return '<span class="wifl-dock__badge">' . esc_html( (string) max( 0, (int) $count ) ) . '</span>';
	}

	private function ensure_cart() {
		if ( function_exists( 'wc_load_cart' ) && ( is_null( WC()->cart ) || ! WC()->cart ) ) {
			wc_load_cart();
		}
	}

	/**
	 * @param string $name Product name.
	 * @return string
	 */
	private function service_icon( $name ) {
		$n = strtolower( (string) $name );
		if ( false !== strpos( $n, 'like' ) ) {
			return 'likes';
		}
		if ( false !== strpos( $n, 'view' ) ) {
			return 'views';
		}
		if ( false !== strpos( $n, 'comment' ) ) {
			return 'comments';
		}
		if ( false !== strpos( $n, 'follow' ) ) {
			return 'followers';
		}
		return 'likes';
	}

	/**
	 * @param string $qty Package quantity.
	 * @return string
	 */
	private function qty_badge( $qty ) {
		$raw = preg_replace( '/[,\s]+/', '', (string) $qty );
		if ( preg_match( '/^\d+$/', (string) $raw ) ) {
			$n = (int) $raw;
			if ( $n >= 1000 ) {
				$k     = $n / 1000;
				$label = ( abs( $k - round( $k ) ) < 0.05 ) ? (string) (int) round( $k ) : rtrim( rtrim( number_format( $k, 1, '.', '' ), '0' ), '.' );
				return $label . 'K';
			}
			return (string) $n;
		}
		return strtoupper( (string) $raw );
	}

	/**
	 * @param int    $product_id Product ID.
	 * @param string $name       Name.
	 * @return string
	 */
	private function platform_key( $product_id, $name = '' ) {
		return Helpers::platform_key( $product_id, $name );
	}
}
