<?php
/**
 * WooCommerce product data tab: Subscription plans (pricing cards).
 *
 * @package WIFL
 */

namespace WIFL;

use WIFL\Member\Subscriptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Product_Subscription_Meta {

	const META_ENABLED = '_wifl_subscription_enabled';
	const META_PLANS   = '_wifl_subscription_plans';

	/**
	 * @var Product_Subscription_Meta|null
	 */
	private static $instance = null;

	/**
	 * @return Product_Subscription_Meta
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'register_tab' ), 71 );
		add_action( 'woocommerce_product_data_panels', array( $this, 'render_panel' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save' ) );
		add_action( 'template_redirect', array( $this, 'maybe_buy_and_checkout' ), 5 );
	}

	/**
	 * @param array $tabs Tabs.
	 * @return array
	 */
	public function register_tab( $tabs ) {
		$tabs['wifl_subscription'] = array(
			'label'    => esc_html__( 'Subscription', 'woo-instagram-follower' ),
			'target'   => 'wifl_subscription_data',
			'class'    => array( 'show_if_simple', 'show_if_variable' ),
			'priority' => 71,
		);
		return $tabs;
	}

	/**
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function is_enabled( $product_id ) {
		$v = get_post_meta( (int) $product_id, self::META_ENABLED, true );
		if ( 'yes' === $v ) {
			return true;
		}
		// Plans saved without the checkbox still count as enabled.
		return ! empty( self::get_plans( $product_id ) );
	}

	/**
	 * @param int $product_id Product ID.
	 * @return array
	 */
	public static function get_plans( $product_id ) {
		$raw = get_post_meta( (int) $product_id, self::META_PLANS, true );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$clean = array();
		foreach ( $raw as $plan ) {
			$normalized = Subscriptions::normalize_plan( $plan );
			if ( $normalized ) {
				$clean[] = $normalized;
			}
		}
		return $clean;
	}

	/**
	 * Active plans shaped for CT subscription widget / shortcode.
	 *
	 * @param int $product_id Product ID.
	 * @return array
	 */
	public static function get_widget_plans( $product_id ) {
		$product_id = (int) $product_id;
		if ( ! $product_id || ! self::is_enabled( $product_id ) ) {
			return array();
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
		$title   = $product ? $product->get_name() : get_the_title( $product_id );

		$out = array();
		foreach ( self::get_plans( $product_id ) as $plan ) {
			$status = isset( $plan['status'] ) ? $plan['status'] : 'active';
			if ( 'draft' === $status ) {
				continue;
			}
			$plan_name = ! empty( $plan['name'] ) ? $plan['name'] : ( ! empty( $plan['qty'] ) ? $plan['qty'] : $title );
			$out[]     = array(
				'id'           => $plan['id'],
				'name'         => $plan_name,
				'kicker'       => $plan_name,
				'badge'        => $plan['badge'],
				'qty'          => $plan['qty'],
				'qty_label'    => $plan['qty_label'],
				'price'        => $plan['price'],
				'period'       => $plan['period'],
				'unit_price'   => $plan['unit_price'],
				'features'     => $plan['features'],
				'button_text'  => $plan['button_text'],
				'button_url'   => array( 'url' => self::buy_url( $product_id, $plan['id'] ) ),
				'footer'       => $plan['footer'],
				'featured'     => $plan['featured'],
				'product_id'   => $product_id,
				'product_name' => $title,
			);
		}
		return $out;
	}

	/**
	 * Product IDs that have subscription plans (optionally in a category).
	 *
	 * @param int $term_id Optional product_cat term ID (0 = all).
	 * @return int[]
	 */
	public static function get_subscription_product_ids( $term_id = 0 ) {
		$args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'fields'         => 'ids',
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'   => self::META_ENABLED,
					'value' => 'yes',
				),
				array(
					'key'     => self::META_PLANS,
					'compare' => 'EXISTS',
				),
			),
		);

		$term_id = (int) $term_id;
		if ( $term_id > 0 ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $term_id,
				),
			);
		}

		$ids = get_posts( $args );
		$out = array();
		foreach ( (array) $ids as $id ) {
			$id = (int) $id;
			if ( $id && self::get_plans( $id ) ) {
				$out[] = $id;
			}
		}
		return $out;
	}

	/**
	 * All subscription plans site-wide (dynamic).
	 *
	 * @return array
	 */
	public static function get_all_widget_plans() {
		$out = array();
		foreach ( self::get_subscription_product_ids( 0 ) as $product_id ) {
			$out = array_merge( $out, self::get_widget_plans( $product_id ) );
		}
		return $out;
	}

	/**
	 * Plans from all subscription-enabled products in a product category.
	 *
	 * @param int $term_id Category term ID.
	 * @return array
	 */
	public static function get_widget_plans_for_category( $term_id ) {
		$term_id = (int) $term_id;
		if ( $term_id < 1 ) {
			return array();
		}

		$out = array();
		foreach ( self::get_subscription_product_ids( $term_id ) as $product_id ) {
			$out = array_merge( $out, self::get_widget_plans( $product_id ) );
		}
		return $out;
	}

	/**
	 * Signed URL: add subscription plan to cart → custom cart page.
	 * Guests are sent to registration first.
	 *
	 * @param int    $product_id Product ID.
	 * @param string $plan_id    Plan ID.
	 * @return string
	 */
	public static function buy_url( $product_id, $plan_id = '' ) {
		$product_id = (int) $product_id;
		if ( ! $product_id ) {
			return self::cart_redirect_url();
		}

		$buy = self::signed_buy_url( $product_id, $plan_id );

		if ( ! is_user_logged_in() ) {
			return self::registration_gate_url( $buy );
		}

		return $buy;
	}

	/**
	 * Membership register page with return URL after auth.
	 *
	 * @param string $return_url Return URL.
	 * @return string
	 */
	public static function registration_gate_url( $return_url ) {
		$settings = class_exists( '\WIFL\Member\Settings' ) ? \WIFL\Member\Settings::get() : array();
		$can_reg  = empty( $settings['enable_registration'] ) || 'yes' === $settings['enable_registration'];

		if ( class_exists( '\WIFL\Member\Settings' ) ) {
			$base = $can_reg ? \WIFL\Member\Settings::register_url() : \WIFL\Member\Settings::login_url();
		} else {
			$base = $can_reg ? wp_registration_url() : wp_login_url( $return_url );
		}

		return add_query_arg(
			array(
				'wifl_auth'     => $can_reg ? 'register' : 'login',
				'wifl_redirect' => $return_url,
			),
			$base
		);
	}

	/**
	 * HMAC-signed buy URL (works after login — user nonces would break).
	 *
	 * @param int    $product_id Product ID.
	 * @param string $plan_id    Plan ID.
	 * @return string
	 */
	public static function signed_buy_url( $product_id, $plan_id = '' ) {
		$product_id = (int) $product_id;
		$plan_id    = sanitize_key( (string) $plan_id );
		$exp        = time() + DAY_IN_SECONDS;
		$sig        = self::buy_signature( $product_id, $plan_id, $exp );

		return add_query_arg(
			array(
				'wifl_sub_buy' => '1',
				'product_id'   => $product_id,
				'plan_id'      => $plan_id,
				'exp'          => $exp,
				'sig'          => $sig,
			),
			home_url( '/' )
		);
	}

	/**
	 * @param int    $product_id Product ID.
	 * @param string $plan_id    Plan ID.
	 * @param int    $exp        Expiry timestamp.
	 * @return string
	 */
	private static function buy_signature( $product_id, $plan_id, $exp ) {
		$payload = (int) $product_id . '|' . sanitize_key( (string) $plan_id ) . '|' . (int) $exp;
		return hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
	}

	/**
	 * @return bool
	 */
	private static function verify_buy_request() {
		$product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$plan_id    = isset( $_GET['plan_id'] ) ? sanitize_key( wp_unslash( $_GET['plan_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$exp        = isset( $_GET['exp'] ) ? absint( $_GET['exp'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$sig        = isset( $_GET['sig'] ) ? sanitize_text_field( wp_unslash( $_GET['sig'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( $product_id && $exp && $sig && $exp >= time() ) {
			$expected = self::buy_signature( $product_id, $plan_id, $exp );
			if ( hash_equals( $expected, $sig ) ) {
				return true;
			}
		}

		$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
		return (bool) ( $nonce && wp_verify_nonce( $nonce, 'wifl_sub_buy' ) );
	}

	/**
	 * WooCommerce cart page URL (custom cart takeover).
	 *
	 * @return string
	 */
	public static function cart_redirect_url() {
		$home = untrailingslashit( home_url( '/' ) );
		$url  = '';

		if ( function_exists( 'wc_get_page_id' ) ) {
			$cart_id = (int) wc_get_page_id( 'cart' );
			if ( $cart_id > 0 ) {
				$permalink = get_permalink( $cart_id );
				if ( $permalink ) {
					$url = (string) $permalink;
				}
			}
		}

		if ( ! $url && function_exists( 'wc_get_cart_url' ) ) {
			$url = (string) wc_get_cart_url();
		}

		if ( ! $url || untrailingslashit( $url ) === $home ) {
			$page = get_page_by_path( 'cart' );
			if ( $page && ! empty( $page->ID ) ) {
				$permalink = get_permalink( (int) $page->ID );
				if ( $permalink && untrailingslashit( $permalink ) !== $home ) {
					return $permalink;
				}
			}
			return trailingslashit( $home ) . 'cart/';
		}

		return $url;
	}

	/**
	 * @param string $price Raw price.
	 * @return float
	 */
	public static function parse_price( $price ) {
		$clean = preg_replace( '/[^0-9.\-]/', '', str_replace( ',', '', (string) $price ) );
		return (float) $clean;
	}

	/**
	 * Resolve a plan from product meta (server-side).
	 *
	 * @param int    $product_id Product ID.
	 * @param string $plan_id    Plan ID.
	 * @return array|null
	 */
	public static function resolve_plan( $product_id, $plan_id = '' ) {
		$product_id = (int) $product_id;
		if ( ! $product_id || ! self::is_enabled( $product_id ) ) {
			return null;
		}

		$plans   = self::get_plans( $product_id );
		$plan_id = sanitize_key( (string) $plan_id );
		$match   = null;

		foreach ( $plans as $plan ) {
			if ( 'active' !== $plan['status'] ) {
				continue;
			}
			if ( $plan_id && $plan['id'] === $plan_id ) {
				$match = $plan;
				break;
			}
			if ( ! $match ) {
				$match = $plan;
			}
		}

		return $match;
	}

	/**
	 * Cart payload for a subscription plan (price always from product meta).
	 *
	 * @param int    $product_id Product ID.
	 * @param string $plan_id    Plan ID.
	 * @return array|null
	 */
	public static function cart_item_payload( $product_id, $plan_id = '' ) {
		$plan = self::resolve_plan( $product_id, $plan_id );
		if ( ! $plan ) {
			return null;
		}

		return array(
			'wifl_subscription' => array(
				'plan_id'   => $plan['id'],
				'name'      => $plan['name'],
				'qty'       => $plan['qty'],
				'qty_label' => $plan['qty_label'],
				'price'     => self::parse_price( $plan['price'] ),
				'period'    => $plan['period'],
				'uniq'      => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'wiflsub', true ),
			),
		);
	}

	/**
	 * ?wifl_sub_buy=1 → require account → add plan to cart → custom cart page.
	 */
	public function maybe_buy_and_checkout() {
		if ( empty( $_GET['wifl_sub_buy'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$plan_id    = isset( $_GET['plan_id'] ) ? sanitize_key( wp_unslash( $_GET['plan_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$resume     = self::signed_buy_url( $product_id, $plan_id );

		if ( ! is_user_logged_in() ) {
			wc_add_notice( __( 'Please create an account or sign in before purchasing a subscription.', 'woo-instagram-follower' ), 'notice' );
			wp_safe_redirect( self::registration_gate_url( $resume ) );
			exit;
		}

		if ( ! self::verify_buy_request() ) {
			wc_add_notice( __( 'Invalid or expired subscription cart link. Please choose your plan again.', 'woo-instagram-follower' ), 'error' );
			wp_safe_redirect( self::cart_redirect_url() );
			exit;
		}

		$payload = self::cart_item_payload( $product_id, $plan_id );

		if ( ! $payload || ! function_exists( 'WC' ) ) {
			wc_add_notice( __( 'Subscription plan not found.', 'woo-instagram-follower' ), 'error' );
			wp_safe_redirect( self::cart_redirect_url() );
			exit;
		}

		if ( function_exists( 'wc_load_cart' ) && ( is_null( WC()->cart ) || ! WC()->cart ) ) {
			wc_load_cart();
		}

		if ( ! WC()->cart ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}

		WC()->cart->empty_cart();
		$key = WC()->cart->add_to_cart( $product_id, 1, 0, array(), $payload );

		if ( ! $key ) {
			wc_add_notice( __( 'Could not add subscription to cart.', 'woo-instagram-follower' ), 'error' );
			wp_safe_redirect( self::cart_redirect_url() );
			exit;
		}

		WC()->cart->calculate_totals();
		wp_safe_redirect( self::cart_redirect_url() );
		exit;
	}

	public function render_panel() {
		global $post;
		$product_id = $post ? (int) $post->ID : 0;
		$enabled    = self::is_enabled( $product_id ) ? 'yes' : 'no';
		$plans      = self::get_plans( $product_id );
		if ( empty( $plans ) ) {
			$plans = array( Subscriptions::blank_plan() );
		}

		wp_nonce_field( 'wifl_save_product_subscription', 'wifl_sub_nonce' );
		?>
		<div id="wifl_subscription_data" class="panel woocommerce_options_panel">
			<div class="wifl-admin wifl-sub-product">
				<p class="wifl-admin__intro">
					<?php esc_html_e( 'Build subscription pricing cards (like Instagram High Quality plans): quantity, monthly price, features, badge, and CTA. Use the CT subscription widget with “Product” source to show these cards.', 'woo-instagram-follower' ); ?>
				</p>

				<p class="form-field wifl-admin__enable">
					<label for="wifl_subscription_enabled"><?php esc_html_e( 'Enable subscription plans', 'woo-instagram-follower' ); ?></label>
					<input type="checkbox" name="wifl_subscription_enabled" id="wifl_subscription_enabled" value="yes" <?php checked( $enabled, 'yes' ); ?> />
					<span class="description"><?php esc_html_e( 'When enabled, plans below can be shown via the CT subscription widget.', 'woo-instagram-follower' ); ?></span>
				</p>

				<div class="wifl-sub-product-plans" id="wifl-sub-product-plans">
					<?php foreach ( $plans as $index => $plan ) : ?>
						<?php $this->render_plan_card( $index, $plan, count( $plans ) > 1 ); ?>
					<?php endforeach; ?>
				</div>

				<script type="text/html" id="tmpl-wifl-sub-plan-feature">
					<?php $this->render_feature_row( 'wifl_product_subs[__I__]', '__F__', '' ); ?>
				</script>
			</div>
		</div>
		<?php
	}

	/**
	 * @param int|string $index       Index.
	 * @param array      $plan        Plan.
	 * @param bool       $show_remove Show remove.
	 */
	private function render_plan_card( $index, $plan, $show_remove = false ) {
		$name     = 'wifl_product_subs[' . $index . ']';
		$featured = ! empty( $plan['featured'] ) && 'yes' === $plan['featured'];
		$features = $this->feature_list( $plan );
		?>
		<article class="wifl-sub-editor<?php echo $featured ? ' is-featured' : ''; ?>" data-sub-index="<?php echo esc_attr( (string) $index ); ?>">
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>[id]" value="<?php echo esc_attr( isset( $plan['id'] ) ? $plan['id'] : '' ); ?>" />
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>[status]" value="active" />
			<header class="wifl-sub-editor__head">
				<div>
					<strong class="wifl-sub-editor__title"><?php echo esc_html( ! empty( $plan['name'] ) ? $plan['name'] : __( 'New plan', 'woo-instagram-follower' ) ); ?></strong>
					<span class="wifl-sub-editor__meta"><?php echo esc_html( trim( ( isset( $plan['qty'] ) ? $plan['qty'] : '' ) . ' ' . ( isset( $plan['qty_label'] ) ? $plan['qty_label'] : '' ) ) ); ?></span>
				</div>
				<?php if ( $show_remove ) : ?>
					<div class="wifl-sub-editor__head-actions">
						<button type="button" class="button-link-delete wifl-remove-sub-plan"><?php esc_html_e( 'Remove', 'woo-instagram-follower' ); ?></button>
					</div>
				<?php endif; ?>
			</header>

			<div class="wifl-sub-editor__grid">
				<label>
					<span><?php esc_html_e( 'Subscription plan name', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[name]" value="<?php echo esc_attr( isset( $plan['name'] ) ? $plan['name'] : '' ); ?>" placeholder="<?php esc_attr_e( 'Premium Plan', 'woo-instagram-follower' ); ?>" />
				</label>
				<label>
					<span><?php esc_html_e( 'Quantity', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[qty]" value="<?php echo esc_attr( isset( $plan['qty'] ) ? $plan['qty'] : '' ); ?>" placeholder="1,000" />
				</label>
				<label>
					<span><?php esc_html_e( 'Quantity label', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[qty_label]" value="<?php echo esc_attr( isset( $plan['qty_label'] ) ? $plan['qty_label'] : '' ); ?>" placeholder="<?php esc_attr_e( 'likes per post', 'woo-instagram-follower' ); ?>" />
				</label>
				<label>
					<span><?php esc_html_e( 'Price', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[price]" value="<?php echo esc_attr( isset( $plan['price'] ) ? $plan['price'] : '' ); ?>" placeholder="99.99" />
				</label>
				<label>
					<span><?php esc_html_e( 'Period', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[period]" value="<?php echo esc_attr( isset( $plan['period'] ) ? $plan['period'] : '/mo' ); ?>" placeholder="/mo" />
				</label>
				<label>
					<span><?php esc_html_e( 'Button text', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[button_text]" value="<?php echo esc_attr( isset( $plan['button_text'] ) ? $plan['button_text'] : 'get start' ); ?>" />
				</label>
				<label class="wifl-sub-editor__wide">
					<span><?php esc_html_e( 'Footer', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[footer]" value="<?php echo esc_attr( isset( $plan['footer'] ) ? $plan['footer'] : '' ); ?>" placeholder="<?php esc_attr_e( '30-day money back guarantee', 'woo-instagram-follower' ); ?>" />
				</label>
				<div class="wifl-sub-editor__wide wifl-sub-features">
					<span><?php esc_html_e( 'Features', 'woo-instagram-follower' ); ?></span>
					<div class="wifl-sub-features__list">
						<?php foreach ( $features as $f_index => $feature ) : ?>
							<?php $this->render_feature_row( $name, $f_index, $feature ); ?>
						<?php endforeach; ?>
					</div>
					<button type="button" class="button wifl-add-sub-feature"><?php esc_html_e( 'Add feature', 'woo-instagram-follower' ); ?></button>
				</div>
				<label class="wifl-sub-editor__check">
					<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[featured]" value="yes" <?php checked( $featured ); ?> />
					<span><?php esc_html_e( 'Featured plan (highlighted card)', 'woo-instagram-follower' ); ?></span>
				</label>
			</div>
		</article>
		<?php
	}

	/**
	 * @param array $plan Plan.
	 * @return string[]
	 */
	private function feature_list( $plan ) {
		$raw = isset( $plan['features'] ) ? $plan['features'] : '';
		if ( is_array( $raw ) ) {
			$items = array_map( 'strval', $raw );
		} else {
			$items = preg_split( '/\r\n|\r|\n/', (string) $raw );
		}
		$items = array_values( array_filter( array_map( 'trim', $items ) ) );
		return $items ? $items : array( '' );
	}

	/**
	 * @param string     $prefix  Prefix.
	 * @param int|string $f_index Index.
	 * @param string     $feature Feature.
	 */
	private function render_feature_row( $prefix, $f_index, $feature ) {
		?>
		<div class="wifl-sub-feature">
			<input type="text" name="<?php echo esc_attr( $prefix ); ?>[features][<?php echo esc_attr( (string) $f_index ); ?>]" value="<?php echo esc_attr( $feature ); ?>" placeholder="<?php esc_attr_e( 'Real likes from real users', 'woo-instagram-follower' ); ?>" />
			<button type="button" class="button-link-delete wifl-remove-sub-feature" aria-label="<?php esc_attr_e( 'Remove feature', 'woo-instagram-follower' ); ?>">&times;</button>
		</div>
		<?php
	}

	/**
	 * @param int $post_id Product ID.
	 */
	public function save( $post_id ) {
		if ( ! isset( $_POST['wifl_sub_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_sub_nonce'] ) ), 'wifl_save_product_subscription' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$enabled = isset( $_POST['wifl_subscription_enabled'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, self::META_ENABLED, $enabled );

		$raw = array();
		if ( isset( $_POST['wifl_product_subs'] ) && is_array( $_POST['wifl_product_subs'] ) ) {
			$raw = wp_unslash( $_POST['wifl_product_subs'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}

		$plans = array();
		foreach ( $raw as $plan ) {
			$normalized = Subscriptions::normalize_plan( $plan );
			if ( $normalized ) {
				// Card header uses plan name (Label field removed).
				$normalized['kicker'] = $normalized['name'];
				$plans[]              = $normalized;
			}
		}
		update_post_meta( $post_id, self::META_PLANS, $plans );
	}
}
