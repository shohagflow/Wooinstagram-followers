<?php
/**
 * Shared helpers.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helpers {

	/**
	 * Demo services matching the design (editor preview + admin seed).
	 *
	 * @return array
	 */
	public static function demo_services() {
		$features = array(
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
			'Helping brands reach new audiences.',
		);

		$packages = array(
			array(
				'qty'           => '50',
				'off_price'     => '1.99',
				'regular_price' => '2.49',
			),
			array(
				'qty'           => '100',
				'off_price'     => '3.49',
				'regular_price' => '4.99',
			),
			array(
				'qty'           => '250',
				'off_price'     => '6.00',
				'regular_price' => '12.49',
			),
			array(
				'qty'           => '500',
				'off_price'     => '8.00',
				'regular_price' => '24.99',
			),
			array(
				'qty'           => '1000',
				'off_price'     => '15.00',
				'regular_price' => '49.99',
			),
			array(
				'qty'           => '2500',
				'off_price'     => '30.00',
				'regular_price' => '124.99',
			),
			array(
				'qty'           => '5000',
				'off_price'     => '50.00',
				'regular_price' => '249.99',
			),
			array(
				'qty'           => '20000',
				'off_price'     => '120.00',
				'regular_price' => '999.99',
			),
		);

		$premium_packages = array();
		foreach ( $packages as $package ) {
			$premium                  = $package;
			$premium['regular_price'] = wc_format_decimal( (float) $package['regular_price'] * 1.35 );
			$premium['off_price']     = wc_format_decimal( (float) $package['off_price'] * 1.35 );
			$premium_packages[]       = $premium;
		}

		return array(
			array(
				'title'    => 'High Quality Likes',
				'style'    => 'default',
				'icon'     => '',
				'features' => $features,
				'packages' => $packages,
			),
			array(
				'title'    => 'Premium Likes',
				'style'    => 'premium',
				'icon'     => '',
				'features' => $features,
				'packages' => $premium_packages,
			),
		);
	}

	/**
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function is_enabled( $product_id ) {
		$value = get_post_meta( (int) $product_id, '_wifl_enabled', true );
		// Default on when unset so package prices show without requiring a manual toggle.
		if ( '' === $value || false === $value || null === $value ) {
			return true;
		}
		return 'yes' === $value;
	}

	/**
	 * @param int $product_id Product ID.
	 * @return array
	 */
	public static function get_services( $product_id ) {
		$services = get_post_meta( (int) $product_id, '_wifl_services', true );
		if ( ! is_array( $services ) ) {
			return array();
		}

		$clean = array();
		foreach ( $services as $service ) {
			$normalized = self::normalize_service( $service );
			if ( $normalized ) {
				$clean[] = $normalized;
			}
		}

		return $clean;
	}

	/**
	 * @param mixed $service Raw service.
	 * @return array|null
	 */
	public static function normalize_service( $service ) {
		if ( ! is_array( $service ) ) {
			return null;
		}

		$title = isset( $service['title'] ) ? sanitize_text_field( $service['title'] ) : '';

		$style = isset( $service['style'] ) ? sanitize_key( $service['style'] ) : 'default';
		if ( ! in_array( $style, array( 'default', 'premium' ), true ) ) {
			$style = 'default';
		}

		$features = array();
		if ( ! empty( $service['features'] ) && is_array( $service['features'] ) ) {
			foreach ( $service['features'] as $feature ) {
				$feature = sanitize_text_field( $feature );
				if ( '' !== $feature ) {
					$features[] = $feature;
				}
			}
		} elseif ( ! empty( $service['features'] ) && is_string( $service['features'] ) ) {
			$lines = preg_split( '/\r\n|\r|\n/', $service['features'] );
			foreach ( $lines as $line ) {
				$line = sanitize_text_field( $line );
				if ( '' !== $line ) {
					$features[] = $line;
				}
			}
		}

		$packages = array();
		if ( ! empty( $service['packages'] ) && is_array( $service['packages'] ) ) {
			foreach ( $service['packages'] as $package ) {
				$normalized = self::normalize_package( $package );
				if ( $normalized ) {
					$packages[] = $normalized;
				}
			}
		}

		if ( empty( $packages ) && empty( $features ) ) {
			return null;
		}

		return array(
			'title'    => $title,
			'style'    => $style,
			'icon'     => '',
			'features' => $features,
			'packages' => $packages,
		);
	}

	/**
	 * @param mixed $value Raw discount (20, "20", "20% off").
	 * @return float
	 */
	public static function parse_discount_percent( $value ) {
		if ( is_numeric( $value ) ) {
			return max( 0, min( 100, (float) $value ) );
		}

		if ( preg_match( '/([0-9]+(?:\.[0-9]+)?)/', (string) $value, $matches ) ) {
			return max( 0, min( 100, (float) $matches[1] ) );
		}

		return 0;
	}

	/**
	 * @param float $regular      Original price.
	 * @param float $discount_pct Discount percent.
	 * @return string
	 */
	public static function calculate_sale_price( $regular, $discount_pct ) {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$sale     = (float) $regular * ( 1 - ( (float) $discount_pct / 100 ) );
		if ( $sale < 0 ) {
			$sale = 0;
		}

		return wc_format_decimal( $sale, $decimals );
	}

	/**
	 * Plain-text formatted price for package pills.
	 *
	 * @param float $amount Amount.
	 * @return string
	 */
	public static function price_label( $amount ) {
		$html = self::price_html( $amount );
		$text = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( '/\s+/', ' ', $text ) );
	}

	/**
	 * @param mixed $package Raw package.
	 * @return array|null
	 */
	public static function normalize_package( $package ) {
		if ( ! is_array( $package ) ) {
			return null;
		}

		$qty = isset( $package['qty'] ) ? preg_replace( '/[^0-9]/', '', (string) $package['qty'] ) : '';
		if ( '' === $qty ) {
			return null;
		}

		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$regular  = isset( $package['regular_price'] ) ? wc_format_decimal( $package['regular_price'], $decimals ) : '';
		$off      = isset( $package['off_price'] ) ? wc_format_decimal( $package['off_price'], $decimals ) : '';

		if ( '' === $off || false === $off ) {
			if ( isset( $package['sale_price'] ) && '' !== $package['sale_price'] ) {
				$off = wc_format_decimal( $package['sale_price'], $decimals );
			} elseif ( '' !== $regular && isset( $package['discount'] ) && '' !== $package['discount'] ) {
				$legacy_sale = self::calculate_sale_price( $regular, self::parse_discount_percent( $package['discount'] ) );
				$off         = wc_format_decimal( max( 0, (float) $regular - (float) $legacy_sale ), $decimals );
			}
		}

		if ( '' === $off || false === $off || (float) $off < 0 ) {
			return null;
		}

		if ( '' === $regular || false === $regular || (float) $regular < 0 ) {
			$regular = $off;
			$sale    = $off;
		} else {
			// Discount price cannot exceed original price.
			if ( (float) $off > (float) $regular ) {
				$off = $regular;
			}
			$sale = wc_format_decimal( max( 0, (float) $regular - (float) $off ), $decimals );
		}

		return array(
			'qty'            => $qty,
			'off_price'      => $off,
			'regular_price'  => $regular,
			'sale_price'     => $sale,
			'smm_service_id' => isset( $package['smm_service_id'] ) ? absint( $package['smm_service_id'] ) : 0,
		);
	}

	/**
	 * Cart item payload for a WIFL package.
	 *
	 * @param \WC_Product $product        Product.
	 * @param array       $package        Package row.
	 * @param int         $service_index  Service index.
	 * @param int         $package_index  Package index.
	 * @return array
	 */
	public static function cart_item_data( $product, $package, $service_index = 0, $package_index = 0 ) {
		return array(
			'wifl' => array(
				'service'         => $product ? $product->get_name() : '',
				'qty'             => isset( $package['qty'] ) ? $package['qty'] : '',
				'price'           => isset( $package['sale_price'] ) ? (float) $package['sale_price'] : 0,
				'regular'         => isset( $package['regular_price'] ) ? (float) $package['regular_price'] : 0,
				'service_index'   => (int) $service_index,
				'package_index'   => (int) $package_index,
				'smm_service_id'  => isset( $package['smm_service_id'] ) ? absint( $package['smm_service_id'] ) : 0,
				'uniq'            => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'wifl', true ),
			),
		);
	}

	/**
	 * Re-resolve package price / qty / SMM service ID from product meta (never trust client session alone).
	 *
	 * @param array $item Cart item.
	 * @return array|null Fresh wifl array or null if invalid.
	 */
	public static function resolve_cart_wifl( $item ) {
		if ( empty( $item['wifl'] ) || ! is_array( $item['wifl'] ) ) {
			return null;
		}

		$pid = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
		if ( $pid < 1 ) {
			return null;
		}

		$s = isset( $item['wifl']['service_index'] ) ? (int) $item['wifl']['service_index'] : -1;
		$p = isset( $item['wifl']['package_index'] ) ? (int) $item['wifl']['package_index'] : -1;
		if ( $s < 0 || $p < 0 ) {
			return null;
		}

		$services = self::get_services( $pid );
		if ( empty( $services[ $s ]['packages'][ $p ] ) || ! is_array( $services[ $s ]['packages'][ $p ] ) ) {
			return null;
		}

		$package = $services[ $s ]['packages'][ $p ];
		$product = isset( $item['data'] ) && is_object( $item['data'] ) ? $item['data'] : null;
		if ( ! $product && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $pid );
		}

		$fresh = self::cart_item_data( $product, $package, $s, $p );
		if ( empty( $fresh['wifl'] ) || ! is_array( $fresh['wifl'] ) ) {
			return null;
		}

		// Keep cart-line uniqueness so Woo does not merge distinct packages.
		if ( ! empty( $item['wifl']['uniq'] ) ) {
			$fresh['wifl']['uniq'] = wc_clean( (string) $item['wifl']['uniq'] );
		}

		return $fresh['wifl'];
	}

	/**
	 * @param string $username Raw username.
	 * @return string
	 */
	public static function sanitize_username( $username ) {
		$user = ltrim( sanitize_text_field( (string) $username ), '@' );
		$user = preg_replace( '/\s+/', '', $user );
		$user = preg_replace( '/[^A-Za-z0-9._-]/', '', (string) $user );
		return substr( (string) $user, 0, 64 );
	}

	/**
	 * @param string $username Username.
	 * @return bool
	 */
	public static function is_valid_username( $username ) {
		$user = self::sanitize_username( $username );
		return (bool) preg_match( '/^[A-Za-z0-9._-]{2,64}$/', $user );
	}

	/**
	 * Allowed hosts for a platform target URL.
	 *
	 * @param string $platform Platform key.
	 * @return string[]
	 */
	public static function allowed_url_hosts( $platform = '' ) {
		$key = sanitize_key( (string) $platform );
		$map = array(
			'instagram' => array( 'instagram.com', 'www.instagram.com' ),
			'tiktok'    => array( 'tiktok.com', 'www.tiktok.com', 'vm.tiktok.com', 'www.vm.tiktok.com' ),
			'youtube'   => array( 'youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be', 'www.youtu.be' ),
			'facebook'  => array( 'facebook.com', 'www.facebook.com', 'm.facebook.com', 'fb.com', 'www.fb.com' ),
			'twitter'   => array( 'twitter.com', 'www.twitter.com', 'x.com', 'www.x.com', 'mobile.twitter.com' ),
		);
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		$all = array();
		foreach ( $map as $hosts ) {
			$all = array_merge( $all, $hosts );
		}
		return array_values( array_unique( $all ) );
	}

	/**
	 * Validate https post/profile URL for SMM (blocks javascript:, random domains).
	 *
	 * @param string $url      URL.
	 * @param string $platform Optional platform key.
	 * @return bool
	 */
	public static function is_allowed_target_url( $url, $platform = '' ) {
		$url = esc_url_raw( trim( (string) $url ) );
		if ( '' === $url || 0 !== stripos( $url, 'https://' ) ) {
			return false;
		}
		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return false;
		}

		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! is_string( $host ) || '' === $host ) {
			return false;
		}
		$host = strtolower( $host );
		$allowed = self::allowed_url_hosts( $platform );
		foreach ( $allowed as $ok ) {
			if ( $host === $ok || ( strlen( $host ) > strlen( $ok ) && substr( $host, -strlen( '.' . $ok ) ) === '.' . $ok ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Data-URI icon for a cart/checkout line (platform brand colors + service glyph).
	 *
	 * @param array $cart_item Cart item.
	 * @return string
	 */
	public static function cart_item_icon_url( $cart_item ) {
		$pid  = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
		$name = '';
		if ( ! empty( $cart_item['data'] ) && is_object( $cart_item['data'] ) && method_exists( $cart_item['data'], 'get_name' ) ) {
			$name = $cart_item['data']->get_name();
		} elseif ( ! empty( $cart_item['wifl']['service'] ) ) {
			$name = (string) $cart_item['wifl']['service'];
		}
		$platform = self::platform_key( $pid, $name );
		$kind     = self::service_kind( $name );
		return self::platform_service_data_uri( $platform, $kind );
	}

	/**
	 * @param string $platform Platform key.
	 * @param string $kind     followers|likes|views|comments.
	 * @return string data:image/svg+xml URL.
	 */
	public static function platform_service_data_uri( $platform, $kind = 'followers' ) {
		$platform = sanitize_key( (string) $platform );
		$kind     = sanitize_key( (string) $kind );
		$stops    = self::platform_gradient_stops( $platform );
		$glyph    = self::service_kind_glyph_path( $kind );
		$id       = 'g' . substr( md5( $platform . $kind ), 0, 8 );

		$svg = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96" role="img">'
			. '<defs><linearGradient id="' . $id . '" x1="0" y1="0" x2="1" y2="1">'
			. '<stop offset="0%" stop-color="' . esc_attr( $stops[0] ) . '"/>'
			. '<stop offset="50%" stop-color="' . esc_attr( $stops[1] ) . '"/>'
			. '<stop offset="100%" stop-color="' . esc_attr( $stops[2] ) . '"/>'
			. '</linearGradient></defs>'
			. '<circle cx="48" cy="48" r="48" fill="url(#' . $id . ')"/>'
			. '<g fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" transform="translate(24 24) scale(2)">'
			. $glyph
			. '</g></svg>';

		return 'data:image/svg+xml,' . rawurlencode( $svg );
	}

	/**
	 * @param string $platform Platform.
	 * @return string[]
	 */
	public static function platform_gradient_stops( $platform ) {
		$map = array(
			'instagram' => array( '#f9ce34', '#ee2a7b', '#6228d7' ),
			'tiktok'    => array( '#25f4ee', '#010101', '#fe2c55' ),
			'youtube'   => array( '#ff4e45', '#ff0000', '#cc0000' ),
			'facebook'  => array( '#4b95f7', '#1877f2', '#0c5dc7' ),
			'twitter'   => array( '#2a2a2a', '#000000', '#141414' ),
		);
		$key = sanitize_key( (string) $platform );
		return isset( $map[ $key ] ) ? $map[ $key ] : $map['instagram'];
	}

	/**
	 * Inner glyph markup for service kind (24x24 path space).
	 *
	 * @param string $kind Kind.
	 * @return string
	 */
	public static function service_kind_glyph_path( $kind ) {
		$kind = sanitize_key( (string) $kind );
		if ( 'followers' === $kind ) {
			return '<g fill="#fff" stroke="none"><circle cx="12" cy="8" r="3.4"/><path d="M4.2 19.2c0-3.2 3.5-5 7.8-5s7.8 1.8 7.8 5V20H4.2v-.8z"/></g>';
		}
		if ( 'views' === $kind ) {
			return '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3" fill="#fff" stroke="none"/>';
		}
		if ( 'comments' === $kind ) {
			return '<path d="M21 12a8 8 0 01-8 8H7l-4 3V12a8 8 0 018-8h2a8 8 0 018 8z"/>';
		}
		// likes
		return '<path fill="#fff" stroke="none" d="M12 21s-7-4.6-9.5-8.8C.8 9.4 2.2 5.6 5.8 4.6c2-.6 4.1.2 6.2 2.4 2.1-2.2 4.2-3 6.2-2.4 3.6 1 5 4.8 3.3 7.6C19 16.4 12 21 12 21z"/>';
	}

	/**
	 * Build provider "link" from platform + username.
	 *
	 * @param string $platform Platform key.
	 * @param string $username Username (no @).
	 * @return string
	 */
	public static function target_link( $platform, $username ) {
		$user = ltrim( trim( (string) $username ), '@' );
		if ( '' === $user ) {
			return '';
		}

		$key = sanitize_key( (string) $platform );
		if ( ! in_array( $key, self::platform_keys(), true ) ) {
			$key = 'instagram';
		}

		if ( 'tiktok' === $key ) {
			return 'https://www.tiktok.com/@' . rawurlencode( $user );
		}
		if ( 'youtube' === $key ) {
			return 'https://www.youtube.com/@' . rawurlencode( $user );
		}
		if ( 'facebook' === $key ) {
			return 'https://www.facebook.com/' . rawurlencode( $user );
		}
		if ( 'twitter' === $key ) {
			return 'https://x.com/' . rawurlencode( $user );
		}
		return 'https://www.instagram.com/' . rawurlencode( $user ) . '/';
	}

	/**
	 * Product name shown on service cards.
	 *
	 * @param int $product_id Product ID.
	 * @return string
	 */
	public static function product_title( $product_id ) {
		$product_id = (int) $product_id;
		if ( $product_id < 1 ) {
			return '';
		}

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				return $product->get_name();
			}
		}

		$title = get_the_title( $product_id );
		return is_string( $title ) ? $title : '';
	}

	/**
	 * Payload for the frontend widget (includes formatted prices).
	 *
	 * @param array $services   Services.
	 * @param int   $product_id Product ID. When set, card title uses the product name.
	 * @return array
	 */
	public static function services_payload( $services, $product_id = 0 ) {
		$out           = array();
		$product_title = self::product_title( $product_id );

		foreach ( $services as $service ) {
			$packages = array();
			foreach ( $service['packages'] as $package ) {
				$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
				$regular  = round( (float) $package['regular_price'], $decimals );
				$sale     = round( (float) $package['sale_price'], $decimals );
				$save     = isset( $package['off_price'] ) ? round( (float) $package['off_price'], $decimals ) : max( 0, round( $regular - $sale, $decimals ) );

				$packages[] = array(
					'qty'         => $package['qty'],
					'discount'    => self::price_label( $save ) . ' ' . __( 'off', 'woo-instagram-follower' ),
					'sale'        => $sale,
					'regular'     => $regular,
					'save'        => $save,
					'saleHtml'    => self::price_html( $sale ),
					'regularHtml' => $regular > $sale ? self::price_html( $regular ) : '',
					'saveHtml'    => $save > 0 ? self::price_html( $save ) : '',
				);
			}

			$out[] = array(
				'title'    => '' !== $product_title ? $product_title : ( isset( $service['title'] ) ? $service['title'] : '' ),
				'style'    => $service['style'],
				'features' => ! empty( $service['features'] ) && is_array( $service['features'] ) ? array_values( $service['features'] ) : array(),
				'packages' => $packages,
			);
		}

		return $out;
	}

	/**
	 * @param float $amount Amount.
	 * @return string
	 */
	public static function price_html( $amount ) {
		if ( ! function_exists( 'wc_price' ) ) {
			return esc_html( number_format( (float) $amount, 2 ) );
		}

		return wc_price( (float) $amount );
	}

	/**
	 * @param string $html Price HTML from wc_price().
	 * @return string
	 */
	public static function kses_price( $html ) {
		return wp_kses(
			$html,
			array(
				'span' => array(
					'class'     => true,
					'translate' => true,
				),
				'bdi'  => array(),
			)
		);
	}

	public static function icon_user() {
		return '<svg class="wifl-icon wifl-icon--user" xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 12a4.25 4.25 0 1 0-4.25-4.25A4.25 4.25 0 0 0 12 12zm0 1.8c-3.7 0-11 1.85-11 5.55V22h22v-2.65c0-3.7-7.3-5.55-11-5.55z"/></svg>';
	}

	/**
	 * Default crown icon.
	 *
	 * @return string
	 */
	public static function icon_crown() {
		return '<svg class="wifl-icon wifl-icon--crown" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 3.2 15.1 9l6.4-1.8-1.8 8.3H4.3L2.5 7.2 8.9 9 12 3.2z"/><path d="M5 18.2h14V21H5z"/></svg>';
	}

	/**
	 * Check icon for selected service.
	 *
	 * @return string
	 */
	public static function icon_check() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>';
	}

	/**
	 * Tag icon for savings.
	 *
	 * @return string
	 */
	public static function icon_tag() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.4 11.6l-9-9A1.5 1.5 0 0011.4 2H4.5A1.5 1.5 0 003 3.5v6.9c0 .4.2.8.4 1.1l9 9a1.5 1.5 0 002.1 0l6.9-6.9a1.5 1.5 0 000-2zM7.1 8.4A1.6 1.6 0 117.1 5a1.6 1.6 0 010 3.4z"/></svg>';
	}

	/**
	 * @param int    $product_id Product ID.
	 * @param string $name       Product name.
	 * @return string
	 */
	public static function platform_key( $product_id, $name = '' ) {
		$bits = array( strtolower( (string) $name ) );
		$terms = wp_get_post_terms( (int) $product_id, 'product_cat' );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$bits[] = strtolower( $term->name . ' ' . $term->slug );
			}
		}
		$blob = implode( ' ', $bits );
		if ( false !== strpos( $blob, 'tiktok' ) || false !== strpos( $blob, 'tik-tok' ) ) {
			return 'tiktok';
		}
		if ( false !== strpos( $blob, 'youtube' ) || false !== strpos( $blob, 'you-tube' ) ) {
			return 'youtube';
		}
		if ( false !== strpos( $blob, 'facebook' ) || false !== strpos( $blob, 'fb-' ) ) {
			return 'facebook';
		}
		if ( false !== strpos( $blob, 'twitter' ) || false !== strpos( $blob, ' x ' ) || false !== strpos( $blob, 'x-' ) ) {
			return 'twitter';
		}
		if ( false !== strpos( $blob, 'instagram' ) || false !== strpos( $blob, 'insta' ) ) {
			return 'instagram';
		}
		return 'instagram';
	}

	/**
	 * @param string $key Platform key.
	 * @return string
	 */
	public static function platform_label( $key ) {
		$map = array(
			'instagram' => 'Instagram',
			'tiktok'    => 'TikTok',
			'youtube'   => 'YouTube',
			'facebook'  => 'Facebook',
			'twitter'   => 'Twitter',
		);
		$key = sanitize_key( $key );
		return isset( $map[ $key ] ) ? $map[ $key ] : 'Instagram';
	}

	/**
	 * @return string[]
	 */
	public static function platform_keys() {
		return array( 'instagram', 'tiktok', 'youtube', 'facebook', 'twitter' );
	}

	/**
	 * @param string $name Product or service name.
	 * @return string followers|likes|views|comments
	 */
	public static function service_kind( $name ) {
		$n = strtolower( (string) $name );
		if ( false !== strpos( $n, 'like' ) ) {
			return 'likes';
		}
		if ( false !== strpos( $n, 'view' ) ) {
			return 'views';
		}
		if ( false !== strpos( $n, 'comment' ) ) {
			return 'comments';
		}
		if ( false !== strpos( $n, 'follow' ) ) {
			return 'followers';
		}
		return 'followers';
	}

	/**
	 * Likes / views / comments need a post or reel URL (not just a profile).
	 *
	 * @param string $name Product name.
	 * @return bool
	 */
	public static function needs_post_link( $name ) {
		return in_array( self::service_kind( $name ), array( 'likes', 'views', 'comments' ), true );
	}

	/**
	 * Session map of cart_item_key => post/reel URL.
	 *
	 * @return array<string,string>
	 */
	public static function get_targets() {
		$saved = array();
		if ( function_exists( 'WC' ) && WC()->session ) {
			$raw = WC()->session->get( 'wifl_targets' );
			if ( is_array( $raw ) ) {
				foreach ( $raw as $key => $url ) {
					$url = esc_url_raw( (string) $url );
					if ( $url ) {
						$saved[ (string) $key ] = $url;
					}
				}
			}
		}
		return $saved;
	}

	/**
	 * @param array<string,string> $targets Targets.
	 */
	public static function save_targets( $targets ) {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}
		$clean = array();
		if ( is_array( $targets ) ) {
			foreach ( $targets as $key => $url ) {
				$key = wc_clean( (string) $key );
				$url = esc_url_raw( trim( (string) $url ) );
				if ( $key && $url && self::is_allowed_target_url( $url ) ) {
					$clean[ $key ] = $url;
				}
			}
		}
		WC()->session->set( 'wifl_targets', $clean );
	}

	/**
	 * Final SMM link for a line: post URL when required, otherwise profile URL.
	 *
	 * @param string $platform    Platform key.
	 * @param string $username    Username.
	 * @param string $product_name Product name.
	 * @param string $post_url    Optional post/reel URL.
	 * @return string
	 */
	public static function resolve_smm_link( $platform, $username, $product_name, $post_url = '' ) {
		$post_url = esc_url_raw( trim( (string) $post_url ) );
		if ( self::needs_post_link( $product_name ) ) {
			return $post_url;
		}
		if ( $post_url ) {
			return $post_url;
		}
		return self::target_link( $platform, $username );
	}

	/**
	 * @param string $qty  Package quantity.
	 * @param string $name Product name.
	 * @return string
	 */
	public static function package_label( $qty, $name ) {
		$raw = preg_replace( '/[,\s]+/', '', (string) $qty );
		if ( preg_match( '/^\d+$/', (string) $raw ) ) {
			$qty = number_format( (int) $raw );
		} else {
			$qty = (string) $qty;
		}
		return trim( $qty . ' ' . self::service_kind( $name ) );
	}

	/**
	 * @param string $key Platform key.
	 * @return string SVG markup.
	 */
	public static function platform_icon( $key ) {
		$key = sanitize_key( $key );
		if ( 'tiktok' === $key ) {
			// Bold TikTok glyph (valid path; previous arc flags were broken so icon looked empty/weak).
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.76 0 2.89 2.89 0 012.88-2.88c.28 0 .54.04.79.1v-3.5a6.26 6.26 0 00-.79-.05 6.34 6.34 0 106.34 6.34V8.77a8.23 8.23 0 004.76 1.52V6.9a4.85 4.85 0 01-1-.21z"/></svg>';
		}
		if ( 'youtube' === $key ) {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M23 12.2s0-3.2-.4-4.6c-.2-.9-.9-1.6-1.8-1.8C18.9 5.4 12 5.4 12 5.4s-6.9 0-8.8.4c-.9.2-1.6.9-1.8 1.8C1 9 1 12.2 1 12.2s0 3.2.4 4.6c.2.9.9 1.6 1.8 1.8 1.9.4 8.8.4 8.8.4s6.9 0 8.8-.4c.9-.2 1.6-.9 1.8-1.8.4-1.4.4-4.6.4-4.6zM9.8 15.6V8.8l6.4 3.4-6.4 3.4z"/></svg>';
		}
		if ( 'facebook' === $key ) {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M14 9h3V6h-3c-2.2 0-4 1.8-4 4v2H7v3h3v7h3v-7h3l1-3h-4v-2c0-.6.4-1 1-1z"/></svg>';
		}
		if ( 'twitter' === $key ) {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.244 2H21.5l-7.5 8.57L22.5 22h-6.56l-5.14-6.71L5.2 22H1.94l8.03-9.17L1.5 2h6.72l4.64 6.18L18.244 2zm-1.15 18h1.81L7.03 3.94H5.09L17.094 20z"/></svg>';
		}
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 3h10a4 4 0 014 4v10a4 4 0 01-4 4H7a4 4 0 01-4-4V7a4 4 0 014-4zm5 4.5A4.5 4.5 0 1016.5 12 4.5 4.5 0 0012 7.5zm0 7.4A2.9 2.9 0 1114.9 12 2.9 2.9 0 0112 14.9zM17.4 6.2a1.1 1.1 0 11-1.1 1.1 1.1 1.1 0 011.1-1.1z"/></svg>';
	}

	/**
	 * Session-stored checkout accounts (usernames + email).
	 *
	 * @return array
	 */
	public static function get_accounts() {
		$defaults = array(
			'instagram' => '',
			'tiktok'    => '',
			'youtube'   => '',
			'facebook'  => '',
			'twitter'   => '',
			'email'     => '',
			'deals'     => '1',
		);
		$saved = array();
		if ( function_exists( 'WC' ) && WC()->session ) {
			$raw = WC()->session->get( 'wifl_accounts' );
			if ( is_array( $raw ) ) {
				$saved = $raw;
			}
		}
		if ( is_user_logged_in() && empty( $saved['email'] ) ) {
			$user = wp_get_current_user();
			if ( $user && $user->user_email ) {
				$defaults['email'] = $user->user_email;
			}
		}
		return array_merge( $defaults, $saved );
	}

	/**
	 * @param array $accounts Accounts.
	 */
	public static function save_accounts( $accounts ) {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}
		$clean = array(
			'instagram' => isset( $accounts['instagram'] ) ? self::sanitize_username( $accounts['instagram'] ) : '',
			'tiktok'    => isset( $accounts['tiktok'] ) ? self::sanitize_username( $accounts['tiktok'] ) : '',
			'youtube'   => isset( $accounts['youtube'] ) ? self::sanitize_username( $accounts['youtube'] ) : '',
			'facebook'  => isset( $accounts['facebook'] ) ? self::sanitize_username( $accounts['facebook'] ) : '',
			'twitter'   => isset( $accounts['twitter'] ) ? self::sanitize_username( $accounts['twitter'] ) : '',
			'email'     => isset( $accounts['email'] ) ? sanitize_email( $accounts['email'] ) : '',
			'deals'     => ! empty( $accounts['deals'] ) ? '1' : '',
		);
		WC()->session->set( 'wifl_accounts', $clean );
	}
}
