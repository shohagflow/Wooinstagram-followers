<?php
/**
 * Default WooCommerce checkout bridge (no custom checkout UI).
 *
 * Keeps protected social account / target URL fields on the standard checkout form.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Checkout_Page {

	/**
	 * @var Checkout_Page|null
	 */
	private static $instance = null;

	/**
	 * @return Checkout_Page
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Use WooCommerce's default checkout template — do not takeover or replace it.
		add_action( 'woocommerce_before_checkout_billing_form', array( $this, 'render_protected_account_fields' ), 5 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'save_checkout_meta' ), 20, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ), 40 );
	}

	/**
	 * Brand the Place Order button on block + classic checkout.
	 */
	public function enqueue_styles() {
		if ( is_admin() || ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return;
		}

		wp_register_style( 'wifl-checkout-brand', false, array(), WIFL_VERSION );
		wp_enqueue_style( 'wifl-checkout-brand' );
		wp_add_inline_style(
			'wifl-checkout-brand',
			'.wc-block-components-checkout-place-order-button,'
			. '.wc-block-components-checkout-place-order-button.contained,'
			. '.wc-block-components-button.wc-block-components-checkout-place-order-button,'
			. '#place_order,'
			. '.woocommerce-checkout #place_order{'
			. 'background:#FF553C!important;'
			. 'background-color:#FF553C!important;'
			. 'border-color:#FF553C!important;'
			. 'color:#fff!important;'
			. '}'
			. '.wc-block-components-checkout-place-order-button:hover,'
			. '.wc-block-components-checkout-place-order-button:focus,'
			. '.wc-block-components-checkout-place-order-button.contained:hover,'
			. '.wc-block-components-checkout-place-order-button.contained:focus,'
			. '#place_order:hover,'
			. '#place_order:focus{'
			. 'background:#e64a34!important;'
			. 'background-color:#e64a34!important;'
			. 'border-color:#e64a34!important;'
			. 'color:#fff!important;'
			. '}'
		);
	}

	/**
	 * Hidden fields submitted with the default WC checkout form (nonce-protected).
	 */
	public function render_protected_account_fields() {
		if ( is_admin() || ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return;
		}
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$accounts = Helpers::get_accounts();
		$targets  = Helpers::get_targets();

		echo '<div class="wifl-ck__protected-fields" hidden aria-hidden="true">';
		foreach ( Helpers::platform_keys() as $key ) {
			$val = isset( $accounts[ $key ] ) ? Helpers::sanitize_username( $accounts[ $key ] ) : '';
			if ( '' === $val ) {
				continue;
			}
			printf(
				'<input type="hidden" name="wifl_user_%1$s" value="%2$s" />',
				esc_attr( $key ),
				esc_attr( $val )
			);
		}
		foreach ( WC()->cart->get_cart() as $key => $item ) {
			if ( empty( $item['wifl'] ) ) {
				continue;
			}
			$url = isset( $targets[ $key ] ) ? $targets[ $key ] : '';
			if ( ! $url ) {
				continue;
			}
			printf(
				'<input type="hidden" name="wifl_target[%1$s]" value="%2$s" />',
				esc_attr( $key ),
				esc_attr( $url )
			);
		}
		echo '</div>';
	}

	/**
	 * @param \WC_Order $order Order.
	 * @param array     $data  Data.
	 */
	public function save_checkout_meta( $order, $data ) {
		if ( ! WC()->session ) {
			return;
		}
		$refill   = (string) WC()->session->get( 'wifl_refill' );
		$delivery = (string) WC()->session->get( 'wifl_delivery' );
		if ( $refill ) {
			$order->update_meta_data( '_wifl_refill', $refill );
		}
		if ( $delivery ) {
			$order->update_meta_data( '_wifl_delivery', $delivery );
		}
	}
}
