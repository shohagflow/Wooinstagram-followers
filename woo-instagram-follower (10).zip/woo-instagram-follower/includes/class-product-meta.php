<?php
/**
 * WooCommerce product data tab + nested repeaters.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Product_Meta {

	/**
	 * @var Product_Meta|null
	 */
	private static $instance = null;

	/**
	 * @return Product_Meta
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'register_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'render_panel' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save' ) );
		add_filter( 'woocommerce_is_purchasable', array( $this, 'maybe_force_purchasable' ), 10, 2 );
		add_action( 'wp_ajax_wifl_admin_smm_services', array( $this, 'ajax_smm_services' ) );
	}

	/**
	 * @param array $tabs Tabs.
	 * @return array
	 */
	public function register_tab( $tabs ) {
		$tabs['wifl'] = array(
			'label'    => esc_html__( 'Social Media Package', 'woo-instagram-follower' ),
			'target'   => 'wifl_product_data',
			'class'    => array( 'show_if_simple', 'show_if_variable' ),
			'priority' => 70,
		);
		return $tabs;
	}

	public function render_panel() {
		global $post;

		$product_id = $post ? (int) $post->ID : 0;
		$enabled    = Helpers::is_enabled( $product_id ) ? 'yes' : 'no';
		$services   = Helpers::get_services( $product_id );

		wp_nonce_field( 'wifl_save_product', 'wifl_nonce' );
		?>
		<div id="wifl_product_data" class="panel woocommerce_options_panel">
			<div class="wifl-admin">
				<p class="wifl-admin__intro">
					<?php esc_html_e( 'Enable package pricing for the CT- follower Elementor widget. Choose an SMM service from the API for each quantity row. Discount price cannot be higher than original price.', 'woo-instagram-follower' ); ?>
				</p>

				<p class="form-field wifl-admin__enable">
					<label for="wifl_enabled"><?php esc_html_e( 'Enable packages', 'woo-instagram-follower' ); ?></label>
					<input type="checkbox" name="wifl_enabled" id="wifl_enabled" value="yes" <?php checked( $enabled, 'yes' ); ?> />
					<span class="description"><?php esc_html_e( 'Package prices override the catalog price when added from the widget.', 'woo-instagram-follower' ); ?></span>
				</p>

				<div class="wifl-services-wrap" id="wifl-services-wrap">
					<?php
					if ( empty( $services ) ) {
						$this->render_service_row( 0, $this->blank_service(), false );
					} else {
						$show_remove = count( $services ) > 1;
						foreach ( $services as $s_index => $service ) {
							$this->render_service_row( $s_index, $service, $show_remove );
						}
					}
					?>
				</div>
				<script type="text/html" id="tmpl-wifl-feature">
					<?php $this->render_feature_row( '__S__', '__F__', '' ); ?>
				</script>
				<script type="text/html" id="tmpl-wifl-package">
					<?php $this->render_package_row( '__S__', '__P__', $this->blank_package() ); ?>
				</script>
			</div>
		</div>
		<?php
	}

	/**
	 * @return array
	 */
	private function blank_service() {
		return array(
			'style'    => 'default',
			'features' => array( '' ),
			'packages' => array( $this->blank_package() ),
		);
	}

	/**
	 * @return array
	 */
	private function blank_package() {
		return array(
			'qty'            => '',
			'off_price'      => '',
			'regular_price'  => '',
			'smm_service_id' => '',
		);
	}

	/**
	 * @param int|string $s_index      Service index.
	 * @param array      $service      Service data.
	 * @param bool       $show_remove  Whether to show the remove control.
	 */
	private function render_service_row( $s_index, $service, $show_remove = false ) {
		$style    = isset( $service['style'] ) ? $service['style'] : 'default';
		$features = ! empty( $service['features'] ) && is_array( $service['features'] ) ? $service['features'] : array( '' );
		$packages = ! empty( $service['packages'] ) && is_array( $service['packages'] ) ? $service['packages'] : array( $this->blank_package() );
		?>
		<div class="wifl-service-card" data-service="<?php echo esc_attr( (string) $s_index ); ?>">
			<div class="wifl-service-card__head">
				<strong class="wifl-service-card__label"><?php esc_html_e( 'Service type', 'woo-instagram-follower' ); ?></strong>
				<?php if ( $show_remove ) : ?>
					<button type="button" class="button-link-delete wifl-remove-service"><?php esc_html_e( 'Remove', 'woo-instagram-follower' ); ?></button>
				<?php endif; ?>
			</div>

			<p class="form-field">
				<label><?php esc_html_e( 'Card style', 'woo-instagram-follower' ); ?></label>
				<select name="wifl_services[<?php echo esc_attr( (string) $s_index ); ?>][style]">
					<option value="default" <?php selected( $style, 'default' ); ?>><?php esc_html_e( 'Standard', 'woo-instagram-follower' ); ?></option>
					<option value="premium" <?php selected( $style, 'premium' ); ?>><?php esc_html_e( 'Premium header', 'woo-instagram-follower' ); ?></option>
				</select>
				<span class="description"><?php esc_html_e( 'The frontend card title uses this product’s name. The icon is shown automatically from the card style.', 'woo-instagram-follower' ); ?></span>
			</p>

			<div class="wifl-features">
				<div class="wifl-features__head">
					<strong><?php esc_html_e( 'Features', 'woo-instagram-follower' ); ?></strong>
				</div>
				<div class="wifl-features-list">
					<?php foreach ( $features as $f_index => $feature ) : ?>
						<?php $this->render_feature_row( $s_index, $f_index, $feature ); ?>
					<?php endforeach; ?>
				</div>
				<div class="wifl-features__footer">
					<button type="button" class="button wifl-add-feature"><?php esc_html_e( 'Add feature', 'woo-instagram-follower' ); ?></button>
				</div>
			</div>

			<div class="wifl-packages">
				<div class="wifl-packages__head">
					<strong><?php esc_html_e( 'Quantity packages', 'woo-instagram-follower' ); ?></strong>
				</div>
				<table class="widefat wifl-packages-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Quantity', 'woo-instagram-follower' ); ?></th>
							<th><?php esc_html_e( 'Discount price', 'woo-instagram-follower' ); ?></th>
							<th><?php esc_html_e( 'Original price', 'woo-instagram-follower' ); ?></th>
							<th class="wifl-col-smm"><?php esc_html_e( 'SMM service', 'woo-instagram-follower' ); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $packages as $p_index => $package ) : ?>
							<?php $this->render_package_row( $s_index, $p_index, $package ); ?>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="wifl-packages__footer">
					<button type="button" class="button wifl-add-package"><?php esc_html_e( 'Add package', 'woo-instagram-follower' ); ?></button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * @param int|string $s_index Service index.
	 * @param int|string $f_index Feature index.
	 * @param string     $feature Feature text.
	 */
	private function render_feature_row( $s_index, $f_index, $feature ) {
		?>
		<div class="wifl-feature-row">
			<input type="text" name="wifl_services[<?php echo esc_attr( (string) $s_index ); ?>][features][<?php echo esc_attr( (string) $f_index ); ?>]" value="<?php echo esc_attr( $feature ); ?>" placeholder="<?php esc_attr_e( 'Helping brands reach new audiences.', 'woo-instagram-follower' ); ?>" />
			<button type="button" class="button-link-delete wifl-remove-feature" aria-label="<?php esc_attr_e( 'Remove feature', 'woo-instagram-follower' ); ?>">&times;</button>
		</div>
		<?php
	}

	/**
	 * @param int|string $s_index Service index.
	 * @param int|string $p_index Package index.
	 * @param array      $package Package data.
	 */
	private function render_package_row( $s_index, $p_index, $package ) {
		$qty     = isset( $package['qty'] ) ? $package['qty'] : '';
		$off     = isset( $package['off_price'] ) ? $package['off_price'] : ( isset( $package['sale_price'] ) ? $package['sale_price'] : '' );
		$regular = isset( $package['regular_price'] ) ? $package['regular_price'] : '';
		$smm_id  = isset( $package['smm_service_id'] ) ? absint( $package['smm_service_id'] ) : 0;
		?>
		<tr class="wifl-package-row">
			<td>
				<input type="text" name="wifl_services[<?php echo esc_attr( (string) $s_index ); ?>][packages][<?php echo esc_attr( (string) $p_index ); ?>][qty]" value="<?php echo esc_attr( $qty ); ?>" placeholder="50" />
			</td>
			<td>
				<input type="text" class="wc_input_price wifl-price-discount" name="wifl_services[<?php echo esc_attr( (string) $s_index ); ?>][packages][<?php echo esc_attr( (string) $p_index ); ?>][off_price]" value="<?php echo esc_attr( $off ); ?>" placeholder="1.60" />
			</td>
			<td>
				<input type="text" class="wc_input_price wifl-price-original" name="wifl_services[<?php echo esc_attr( (string) $s_index ); ?>][packages][<?php echo esc_attr( (string) $p_index ); ?>][regular_price]" value="<?php echo esc_attr( $regular ); ?>" placeholder="2.49" />
			</td>
			<td class="wifl-col-smm">
				<select
					class="wifl-smm-service-select"
					name="wifl_services[<?php echo esc_attr( (string) $s_index ); ?>][packages][<?php echo esc_attr( (string) $p_index ); ?>][smm_service_id]"
					data-selected="<?php echo esc_attr( (string) $smm_id ); ?>"
				>
					<option value=""><?php esc_html_e( 'Select SMM service…', 'woo-instagram-follower' ); ?></option>
					<?php if ( $smm_id > 0 ) : ?>
						<option value="<?php echo esc_attr( (string) $smm_id ); ?>" selected>
							<?php
							echo esc_html(
								sprintf(
									/* translators: %d service id */
									__( '%d (saved — loading name…)', 'woo-instagram-follower' ),
									$smm_id
								)
							);
							?>
						</option>
					<?php endif; ?>
				</select>
			</td>
			<td>
				<button type="button" class="button-link-delete wifl-remove-package" aria-label="<?php esc_attr_e( 'Remove package', 'woo-instagram-follower' ); ?>">&times;</button>
			</td>
		</tr>
		<?php
	}

	/**
	 * AJAX: SMM services grouped by category for product package selects.
	 */
	public function ajax_smm_services() {
		check_ajax_referer( 'wifl_admin_product', 'nonce' );
		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'woo-instagram-follower' ) ), 403 );
		}

		$s = Smm_Api::get();
		if ( '' === $s['api_url'] || '' === $s['api_key'] ) {
			wp_send_json_error(
				array(
					'message' => __( 'Connect the SMM API first (Membership → API).', 'woo-instagram-follower' ),
				),
				400
			);
		}

		$force    = ! empty( $_POST['refresh'] );
		$services = Smm_Order::get_services( $force );
		if ( is_wp_error( $services ) ) {
			wp_send_json_error( array( 'message' => $services->get_error_message() ), 500 );
		}

		$groups = array();
		foreach ( $services as $row ) {
			$cat = isset( $row['category'] ) && $row['category'] ? (string) $row['category'] : __( 'Other', 'woo-instagram-follower' );
			if ( ! isset( $groups[ $cat ] ) ) {
				$groups[ $cat ] = array();
			}
			$id = isset( $row['id'] ) ? (int) $row['id'] : 0;
			if ( $id < 1 ) {
				continue;
			}
			$label = $id . ' - ' . ( isset( $row['name'] ) ? $row['name'] : '' );
			if ( ! empty( $row['rate'] ) ) {
				$label .= ' ($' . $row['rate'] . '/1k)';
			}
			$groups[ $cat ][] = array(
				'id'    => $id,
				'label' => $label,
			);
		}

		$out = array();
		$keys = array_keys( $groups );
		natcasesort( $keys );
		foreach ( $keys as $cat ) {
			$out[] = array(
				'category' => $cat,
				'services' => $groups[ $cat ],
			);
		}

		wp_send_json_success(
			array(
				'groups' => $out,
				'count'  => count( $services ),
			)
		);
	}

	/**
	 * @param int $post_id Product ID.
	 */
	public function save( $post_id ) {
		if ( ! isset( $_POST['wifl_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_nonce'] ) ), 'wifl_save_product' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$enabled = isset( $_POST['wifl_enabled'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, '_wifl_enabled', $enabled );

		$raw = array();
		if ( isset( $_POST['wifl_services'] ) && is_array( $_POST['wifl_services'] ) ) {
			$raw = wp_unslash( $_POST['wifl_services'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}

		$services = array();
		foreach ( $raw as $service ) {
			$normalized = Helpers::normalize_service( $service );
			if ( $normalized ) {
				$services[] = $normalized;
			}
		}

		update_post_meta( $post_id, '_wifl_services', $services );
	}

	/**
	 * Allow WIFL products to be purchasable even if catalog price is empty.
	 *
	 * @param bool        $purchasable Purchasable.
	 * @param \WC_Product $product     Product.
	 * @return bool
	 */
	public function maybe_force_purchasable( $purchasable, $product ) {
		if ( $purchasable || ! $product ) {
			return $purchasable;
		}
		if ( ! empty( Helpers::get_services( $product->get_id() ) ) ) {
			return true;
		}
		return $purchasable;
	}
}
