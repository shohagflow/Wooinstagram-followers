<?php
/**
 * Custom WooCommerce cart page (split layout).
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Cart_Page {

	/**
	 * @var Cart_Page|null
	 */
	private static $instance = null;

	/**
	 * @return Cart_Page
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'template_redirect', array( $this, 'takeover' ), 1 );
		add_filter( 'template_include', array( $this, 'template_include' ), PHP_INT_MAX );
		add_filter( 'body_class', array( $this, 'body_class' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 130 );
		add_action( 'wp_enqueue_scripts', array( $this, 'strip_late_assets' ), 999 );
		add_action( 'wp_print_styles', array( $this, 'strip_late_assets' ), 0 );
		add_action( 'wp_print_scripts', array( $this, 'strip_late_assets' ), 0 );
		add_filter( 'woocommerce_checkout_get_value', array( $this, 'prefill_checkout_email' ), 10, 2 );
		add_action( 'woocommerce_checkout_process', array( $this, 'capture_posted_accounts' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_accounts' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'save_order_accounts' ), 10, 2 );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'admin_accounts' ) );
		add_action( 'wp_ajax_wifl_cart_page_state', array( $this, 'ajax_state' ) );
		add_action( 'wp_ajax_nopriv_wifl_cart_page_state', array( $this, 'ajax_state' ) );
		add_action( 'wp_ajax_wifl_cart_page_remove', array( $this, 'ajax_remove' ) );
		add_action( 'wp_ajax_nopriv_wifl_cart_page_remove', array( $this, 'ajax_remove' ) );
		add_action( 'wp_ajax_wifl_cart_page_add', array( $this, 'ajax_add' ) );
		add_action( 'wp_ajax_nopriv_wifl_cart_page_add', array( $this, 'ajax_add' ) );
		add_action( 'wp_ajax_wifl_cart_page_save', array( $this, 'ajax_save' ) );
		add_action( 'wp_ajax_nopriv_wifl_cart_page_save', array( $this, 'ajax_save' ) );
		add_action( 'wp_ajax_wifl_cart_page_forget', array( $this, 'ajax_forget' ) );
		add_action( 'wp_ajax_nopriv_wifl_cart_page_forget', array( $this, 'ajax_forget' ) );
		add_filter( 'elementor/theme/need_override_location', array( $this, 'disable_elementor_chrome' ), 999, 2 );
	}

	/**
	 * @param string $template Template.
	 * @return string
	 */
	public function template_include( $template ) {
		if ( $this->is_cart_page() ) {
			return WIFL_PATH . 'templates/cart-page.php';
		}
		return $template;
	}

	/**
	 * @param string[] $classes Classes.
	 * @return string[]
	 */
	public function body_class( $classes ) {
		if ( $this->is_cart_page() ) {
			$classes[] = 'wifl-co-body';
		}
		return $classes;
	}

	public function takeover() {
		if ( ! $this->is_cart_page() ) {
			return;
		}

		remove_all_actions( 'wp_body_open' );
		add_filter( 'show_admin_bar', '__return_false' );

		status_header( 200 );
		nocache_headers();
		$this->render_page();
		exit;
	}

	/**
	 * @param bool   $need     Need override.
	 * @param string $location Location.
	 * @return bool
	 */
	public function disable_elementor_chrome( $need, $location ) {
		if ( $this->is_cart_page() && in_array( $location, array( 'header', 'footer' ), true ) ) {
			return false;
		}
		return $need;
	}

	public function enqueue() {
		if ( ! $this->is_cart_page() ) {
			return;
		}

		wp_register_style(
			'wifl-cart-page',
			WIFL_URL . 'assets/css/cart-page.css',
			array(),
			WIFL_VERSION
		);
		wp_register_script(
			'wifl-cart-page',
			WIFL_URL . 'assets/js/cart-page.js',
			array(),
			WIFL_VERSION,
			true
		);

		wp_enqueue_style( 'wifl-cart-page' );
		wp_enqueue_script( 'wifl-cart-page' );
		$this->strip_theme_assets();

		$this->ensure_cart();

		wp_localize_script(
			'wifl-cart-page',
			'wiflCartPage',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wifl_cart_page' ),
				'checkoutUrl' => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
				'shopUrl'     => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
				'state'       => $this->payload(),
				'i18n'        => array(
					'required'   => esc_html__( 'Enter a username for each platform in your order.', 'woo-instagram-follower' ),
					'email'      => esc_html__( 'Enter a valid email address.', 'woo-instagram-follower' ),
					'postLink'   => esc_html__( 'Paste the post/reel URL for each likes, views, or comments package.', 'woo-instagram-follower' ),
					'empty'      => esc_html__( 'Your cart is empty.', 'woo-instagram-follower' ),
					'error'      => esc_html__( 'Could not update your cart.', 'woo-instagram-follower' ),
					'inOrder'    => esc_html__( 'In your order', 'woo-instagram-follower' ),
					'reviewPay'  => esc_html__( 'Review & Pay', 'woo-instagram-follower' ),
					'addPackage' => esc_html__( 'Add a package to continue', 'woo-instagram-follower' ),
				),
			)
		);
	}

	/**
	 * Prefill WooCommerce checkout email from the cart page session.
	 *
	 * @param mixed  $value Value.
	 * @param string $input Input key.
	 * @return mixed
	 */
	public function prefill_checkout_email( $value, $input ) {
		if ( 'billing_email' !== $input || ! empty( $value ) ) {
			return $value;
		}
		$accounts = Helpers::get_accounts();
		return ! empty( $accounts['email'] ) ? $accounts['email'] : $value;
	}

	public function capture_posted_accounts() {
		$accounts = Helpers::get_accounts();
		foreach ( Helpers::platform_keys() as $key ) {
			$field = 'wifl_user_' . $key;
			if ( isset( $_POST[ $field ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$accounts[ $key ] = Helpers::sanitize_username( wp_unslash( $_POST[ $field ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			}
		}
		if ( isset( $_POST['billing_email'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$accounts['email'] = sanitize_email( wp_unslash( $_POST['billing_email'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		} elseif ( isset( $_POST['wifl_email'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$accounts['email'] = sanitize_email( wp_unslash( $_POST['wifl_email'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		$accounts['deals'] = isset( $_POST['wifl_deals'] ) ? '1' : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		Helpers::save_accounts( $accounts );

		// Capture target URLs as checkout form fields (protected by WC checkout nonce).
		$targets = Helpers::get_targets();
		if ( isset( $_POST['wifl_target'] ) && is_array( $_POST['wifl_target'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$raw = wp_unslash( $_POST['wifl_target'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			foreach ( $raw as $key => $url ) {
				$key = wc_clean( (string) $key );
				$url = esc_url_raw( trim( (string) $url ) );
				if ( ! $key ) {
					continue;
				}
				if ( $url && Helpers::is_allowed_target_url( $url ) ) {
					$targets[ $key ] = $url;
				} else {
					unset( $targets[ $key ] );
				}
			}
			Helpers::save_targets( $targets );
		}
	}

	/**
	 * @param array     $data   Posted data.
	 * @param \WP_Error $errors Errors.
	 */
	public function validate_accounts( $data, $errors ) {
		$needed   = $this->cart_platforms();
		$accounts = Helpers::get_accounts();
		foreach ( $needed as $key ) {
			$field = 'wifl_user_' . $key;
			$value = isset( $_POST[ $field ] ) ? Helpers::sanitize_username( wp_unslash( $_POST[ $field ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( '' === $value && ! empty( $accounts[ $key ] ) ) {
				$value = Helpers::sanitize_username( $accounts[ $key ] );
			}
			if ( ! Helpers::is_valid_username( $value ) ) {
				$errors->add(
					'wifl_user_' . $key,
					sprintf(
						/* translators: %s platform name */
						esc_html__( 'Please enter a valid %s username.', 'woo-instagram-follower' ),
						Helpers::platform_label( $key )
					)
				);
			}
		}

		$targets = Helpers::get_targets();
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}
		foreach ( WC()->cart->get_cart() as $key => $item ) {
			if ( empty( $item['wifl'] ) ) {
				continue;
			}
			$product = isset( $item['data'] ) ? $item['data'] : null;
			$name    = $product ? $product->get_name() : '';
			if ( ! Helpers::needs_post_link( $name ) ) {
				continue;
			}
			$pid      = isset( $item['product_id'] ) ? (int) $item['product_id'] : 0;
			$platform = Helpers::platform_key( $pid, $name );
			$url      = '';
			if ( isset( $_POST['wifl_target'][ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$url = esc_url_raw( trim( (string) wp_unslash( $_POST['wifl_target'][ $key ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			} elseif ( isset( $targets[ $key ] ) ) {
				$url = $targets[ $key ];
			}
			if ( ! Helpers::is_allowed_target_url( $url, $platform ) ) {
				$errors->add(
					'wifl_target_' . $key,
					sprintf(
						/* translators: %s package label */
						esc_html__( 'Please paste a valid post/reel link for %s.', 'woo-instagram-follower' ),
						Helpers::package_label( isset( $item['wifl']['qty'] ) ? $item['wifl']['qty'] : '', $name )
					)
				);
			}
		}
	}

	/**
	 * @param \WC_Order $order Order.
	 * @param array     $data  Posted data.
	 */
	public function save_order_accounts( $order, $data ) {
		$accounts = Helpers::get_accounts();
		foreach ( Helpers::platform_keys() as $key ) {
			if ( empty( $accounts[ $key ] ) ) {
				continue;
			}
			$label = Helpers::platform_label( $key ) . ' ' . __( 'username', 'woo-instagram-follower' );
			$order->update_meta_data( '_wifl_' . $key, $accounts[ $key ] );
			$order->update_meta_data( $label, $accounts[ $key ] );
		}
		if ( ! empty( $accounts['email'] ) ) {
			$order->update_meta_data( '_wifl_email', $accounts['email'] );
		}
		if ( ! empty( $accounts['deals'] ) ) {
			$order->update_meta_data( '_wifl_deals', 'yes' );
		}
	}

	/**
	 * @param \WC_Order $order Order.
	 */
	public function admin_accounts( $order ) {
		if ( ! $order ) {
			return;
		}
		$rows = array();
		foreach ( Helpers::platform_keys() as $key ) {
			$value = $order->get_meta( '_wifl_' . $key );
			if ( $value ) {
				$rows[] = array(
					'label' => Helpers::platform_label( $key ),
					'value' => $value,
				);
			}
		}
		if ( empty( $rows ) ) {
			return;
		}
		echo '<div class="wifl-order-accounts" style="margin-top:12px">';
		echo '<h3>' . esc_html__( 'Social accounts', 'woo-instagram-follower' ) . '</h3>';
		foreach ( $rows as $row ) {
			echo '<p><strong>' . esc_html( $row['label'] ) . ':</strong> @' . esc_html( $row['value'] ) . '</p>';
		}
		echo '</div>';
	}

	public function ajax_state() {
		check_ajax_referer( 'wifl_cart_page', 'nonce' );
		$this->ensure_cart();
		$this->maybe_save_posted_accounts();
		wp_send_json_success( $this->payload() );
	}

	public function ajax_remove() {
		check_ajax_referer( 'wifl_cart_page', 'nonce' );
		$this->ensure_cart();
		$this->maybe_save_posted_accounts();
		$key = isset( $_POST['key'] ) ? wc_clean( wp_unslash( $_POST['key'] ) ) : '';
		if ( $key && WC()->cart ) {
			WC()->cart->remove_cart_item( $key );
			WC()->cart->calculate_totals();
		}
		wp_send_json_success( $this->payload() );
	}

	public function ajax_add() {
		check_ajax_referer( 'wifl_cart_page', 'nonce' );
		$this->ensure_cart();
		$this->maybe_save_posted_accounts();

		$product_id    = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$service_index = isset( $_POST['service'] ) ? absint( $_POST['service'] ) : 0;
		$package_index = isset( $_POST['package'] ) ? absint( $_POST['package'] ) : 0;

		$services = $product_id ? Helpers::get_services( $product_id ) : array();
		if ( empty( $services[ $service_index ]['packages'][ $package_index ] ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid package.', 'woo-instagram-follower' ) ), 400 );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Product not found.', 'woo-instagram-follower' ) ), 404 );
		}

		$package = $services[ $service_index ]['packages'][ $package_index ];
		WC()->cart->add_to_cart(
			$product_id,
			1,
			0,
			array(),
			Helpers::cart_item_data( $product, $package, $service_index, $package_index )
		);
		WC()->cart->calculate_totals();
		wp_send_json_success( $this->payload() );
	}

	public function ajax_save() {
		check_ajax_referer( 'wifl_cart_page', 'nonce' );
		$this->ensure_cart();
		$this->maybe_save_posted_accounts();

		$needed = $this->cart_platforms();
		$accounts = Helpers::get_accounts();
		foreach ( $needed as $key ) {
			$user = Helpers::sanitize_username( isset( $accounts[ $key ] ) ? $accounts[ $key ] : '' );
			if ( ! Helpers::is_valid_username( $user ) ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s platform name */
							esc_html__( 'Please enter a valid %s username.', 'woo-instagram-follower' ),
							Helpers::platform_label( $key )
						),
					),
					400
				);
			}
		}

		$email = isset( $accounts['email'] ) ? $accounts['email'] : '';
		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Enter a valid email address.', 'woo-instagram-follower' ) ), 400 );
		}

		$targets = Helpers::get_targets();
		if ( WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $key => $item ) {
				$product = isset( $item['data'] ) ? $item['data'] : null;
				$name    = $product ? $product->get_name() : '';
				if ( ! Helpers::needs_post_link( $name ) ) {
					continue;
				}
				$pid      = isset( $item['product_id'] ) ? (int) $item['product_id'] : 0;
				$platform = Helpers::platform_key( $pid, $name );
				$url      = isset( $targets[ $key ] ) ? $targets[ $key ] : '';
				if ( ! Helpers::is_allowed_target_url( $url, $platform ) ) {
					wp_send_json_error(
						array(
							'message' => sprintf(
								/* translators: %s package label */
								esc_html__( 'Please paste a valid post/reel link for %s.', 'woo-instagram-follower' ),
								Helpers::package_label( isset( $item['wifl']['qty'] ) ? $item['wifl']['qty'] : '', $name )
							),
						),
						400
					);
				}
			}
		}

		$this->remember_usernames( $accounts );

		wp_send_json_success(
			array(
				'ok'          => true,
				'checkoutUrl' => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
				'state'       => $this->payload(),
			)
		);
	}

	public function ajax_forget() {
		check_ajax_referer( 'wifl_cart_page', 'nonce' );
		$platform = isset( $_POST['platform'] ) ? sanitize_key( wp_unslash( $_POST['platform'] ) ) : '';
		$user     = isset( $_POST['user'] ) ? ltrim( sanitize_text_field( wp_unslash( $_POST['user'] ) ), '@' ) : '';
		$recent   = $this->get_recent();
		if ( $platform && isset( $recent[ $platform ] ) ) {
			$recent[ $platform ] = array_values(
				array_filter(
					$recent[ $platform ],
					function ( $row ) use ( $user ) {
						return strtolower( (string) $row ) !== strtolower( $user );
					}
				)
			);
			$this->persist_recent( $recent );
		}
		$this->maybe_save_posted_accounts();
		wp_send_json_success( $this->payload() );
	}

	public function render_page() {
		$this->ensure_cart();
		$state = $this->payload();
		$shop  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
		$cta   = $state['empty'] ? esc_html__( 'Add a package to continue', 'woo-instagram-follower' ) : esc_html__( 'Review & Pay', 'woo-instagram-follower' );
		?>
		<!DOCTYPE html>
		<html class="wifl-co-html" <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>" />
			<meta name="viewport" content="width=device-width, initial-scale=1" />
			<?php wp_head(); ?>
			<style id="wifl-co-kill">
				html.wifl-co-html,html.wifl-co-html body.wifl-co-body{margin:0!important;padding:0!important;background:#1e2022!important}
				html.wifl-co-html body.wifl-co-body>:not(.wifl-co):not(#wpadminbar){display:none!important;visibility:hidden!important;height:0!important;overflow:hidden!important;pointer-events:none!important}
			</style>
		</head>
		<body <?php body_class( 'wifl-co-body' ); ?>>
			<div class="wifl-co" data-empty="<?php echo $state['empty'] ? '1' : '0'; ?>">
				<?php $this->render_aside( $state ); ?>
				<main class="wifl-co__main">
					<div class="wifl-co__main-inner">
						<?php
						if ( function_exists( 'wc_print_notices' ) ) {
							echo '<div class="wifl-co__notices">';
							wc_print_notices();
							echo '</div>';
						}
						?>
						<form class="wifl-co__form" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" method="post">
							<?php wp_nonce_field( 'wifl_cart_page', 'wifl_cart_nonce' ); ?>
							<?php $this->render_main_fields( $state, $shop ); ?>
							<button type="button" class="wifl-co__cta wifl-js-continue" <?php disabled( $state['empty'] ); ?>>
								<?php echo $cta; ?>
							</button>
							<p class="wifl-co__cta-note"><?php esc_html_e( 'Nothing charged yet. You review your order before paying.', 'woo-instagram-follower' ); ?></p>
						</form>
					</div>
				</main>
			</div>
			<?php wp_print_scripts( 'wifl-cart-page' ); ?>
		</body>
		</html>
		<?php
	}

	/**
	 * @param array $state State.
	 */
	private function render_aside( $state ) {
		$brand = get_bloginfo( 'name' );
		?>
		<aside class="wifl-co__aside">
			<div class="wifl-co__aside-inner">
				<div class="wifl-co__items" data-items>
					<?php echo $this->items_html( $state['items'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>

				<div class="wifl-co__trust">
					<div class="wifl-co__stars">
						<span class="wifl-co__stars-icons" aria-hidden="true">★★★★★</span>
						<span>4.8 – 12,743 reviews</span>
					</div>
					<blockquote class="wifl-co__quote">
						“<?php echo esc_html( sprintf( __( '%s is a top-end platform for investing in a large number of premium followers and likes for your Instagram account.', 'woo-instagram-follower' ), $brand ) ); ?>”
						<cite>
							US Magazine
							<span class="wifl-co__quote-stars" aria-hidden="true">★★★★★</span>
						</cite>
					</blockquote>
					<ul class="wifl-co__perks">
						<li>
							<span aria-hidden="true"><?php echo $this->icon_lock(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<?php esc_html_e( 'No password required', 'woo-instagram-follower' ); ?>
						</li>
						<li>
							<span aria-hidden="true"><?php echo $this->icon_bolt(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<?php esc_html_e( 'Delivery starts in ~5 min', 'woo-instagram-follower' ); ?>
						</li>
						<li>
							<span aria-hidden="true"><?php echo $this->icon_refresh(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<?php esc_html_e( 'Free refills for 30 days', 'woo-instagram-follower' ); ?>
						</li>
						<li>
							<span aria-hidden="true"><?php echo $this->icon_chat(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<?php esc_html_e( '24/7 support', 'woo-instagram-follower' ); ?>
						</li>
					</ul>
					<div class="wifl-co__pays" aria-label="<?php esc_attr_e( 'Accepted payment methods', 'woo-instagram-follower' ); ?>">
						<span class="wifl-co-pay wifl-co-pay--visa">VISA</span>
						<span class="wifl-co-pay wifl-co-pay--mc"><i></i><i></i></span>
						<span class="wifl-co-pay wifl-co-pay--amex">AMEX</span>
						<span class="wifl-co-pay wifl-co-pay--gpay">GPay</span>
					</div>
				</div>
			</div>
		</aside>
		<?php
	}

	/**
	 * @param array  $state State.
	 * @param string $back  Back URL.
	 */
	private function render_main_fields( $state, $back ) {
		?>
		<nav class="wifl-co__crumbs" aria-label="<?php esc_attr_e( 'Checkout progress', 'woo-instagram-follower' ); ?>">
			<span class="is-on"><?php esc_html_e( 'Details', 'woo-instagram-follower' ); ?></span>
			<span class="wifl-co__crumbs-sep" aria-hidden="true">—</span>
			<span><?php esc_html_e( 'Checkout', 'woo-instagram-follower' ); ?></span>
			<span class="wifl-co__crumbs-sep" aria-hidden="true">—</span>
			<span class="wifl-co__crumbs-secure"><?php echo $this->icon_lock(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php esc_html_e( 'Secure', 'woo-instagram-follower' ); ?></span>
		</nav>

		<div class="wifl-co__head">
			<a class="wifl-co__back" href="<?php echo esc_url( $back ); ?>">
				<span aria-hidden="true">‹</span> <?php esc_html_e( 'Back', 'woo-instagram-follower' ); ?>
			</a>
			<span class="wifl-co__note">
				<?php echo $this->icon_info(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php esc_html_e( 'Public profile only', 'woo-instagram-follower' ); ?>
			</span>
		</div>

		<div class="wifl-co__accounts" data-accounts>
			<?php echo $this->accounts_html( $state ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>

		<div class="wifl-co__delivery">
			<div class="wifl-co-sec-head">
				<h2><?php esc_html_e( 'Delivery updates', 'woo-instagram-follower' ); ?></h2>
				<span><?php esc_html_e( 'Only about this order', 'woo-instagram-follower' ); ?></span>
			</div>
			<label class="wifl-co-label" for="wifl_email"><?php esc_html_e( 'Email address', 'woo-instagram-follower' ); ?></label>
			<label class="wifl-co-field">
				<span class="wifl-co-field__icon" aria-hidden="true"><?php echo $this->icon_mail(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<input
					type="email"
					name="wifl_email"
					id="wifl_email"
					class="wifl-co-field__input"
					placeholder="<?php esc_attr_e( 'Email address', 'woo-instagram-follower' ); ?>"
					value="<?php echo esc_attr( $state['accounts']['email'] ); ?>"
					autocomplete="email"
					required
				/>
			</label>
			<label class="wifl-co-check">
				<input type="checkbox" name="wifl_deals" value="1" <?php checked( ! empty( $state['accounts']['deals'] ) ); ?> />
				<span><?php esc_html_e( 'Email me occasional deals', 'woo-instagram-follower' ); ?></span>
			</label>
		</div>

		<div class="wifl-co__complete">
			<h2><?php esc_html_e( 'Complete your profile', 'woo-instagram-follower' ); ?></h2>
			<div class="wifl-co-upsells" data-upsells>
				<?php echo $this->upsells_html( $state ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
			<p class="wifl-co__complete-note"><?php esc_html_e( 'They arrive together with your order, so the growth reads as real.', 'woo-instagram-follower' ); ?></p>
		</div>
		<?php
	}

	/**
	 * @return array
	 */
	public function payload() {
		$this->ensure_cart();

		$items         = array();
		$sale_total    = 0.0;
		$regular_total = 0.0;
		$in_cart       = array();
		$platforms     = array();
		$accounts      = Helpers::get_accounts();
		$targets       = Helpers::get_targets();
		$recent        = $this->get_recent();

		if ( WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $key => $item ) {
				$product = isset( $item['data'] ) ? $item['data'] : null;
				if ( ! $product ) {
					continue;
				}
				$pid  = (int) $item['product_id'];
				$wifl = ! empty( $item['wifl'] ) && is_array( $item['wifl'] ) ? $item['wifl'] : array();
				$sub  = ! empty( $item['wifl_subscription'] ) && is_array( $item['wifl_subscription'] ) ? $item['wifl_subscription'] : array();
				$qty  = isset( $item['quantity'] ) ? (int) $item['quantity'] : 1;

				if ( $sub ) {
					$sale    = isset( $sub['price'] ) ? (float) $sub['price'] * $qty : (float) $product->get_price() * $qty;
					$regular = $sale;
					$name    = ! empty( $sub['name'] ) ? $sub['name'] : $product->get_name();
					$pkg     = trim( ( isset( $sub['qty'] ) ? $sub['qty'] : '' ) . ' ' . ( isset( $sub['qty_label'] ) ? $sub['qty_label'] : '' ) );
					if ( '' === $pkg ) {
						$pkg = $name;
					}
				} else {
					$sale    = isset( $wifl['price'] ) ? (float) $wifl['price'] * $qty : (float) $product->get_price() * $qty;
					$regular = isset( $wifl['regular'] ) ? (float) $wifl['regular'] * $qty : $sale;
					$name    = $product->get_name();
					$pkg     = isset( $wifl['qty'] ) ? $wifl['qty'] : (string) $qty;
				}

				$plat = Helpers::platform_key( $pid, $name );

				$sale_total        += $sale;
				$regular_total     += $regular;
				$in_cart[ $pid ]    = true;
				$platforms[ $plat ] = true;

				$items[] = array(
					'key'           => $key,
					'id'            => $pid,
					'label'         => Helpers::package_label( $pkg, $name ),
					'name'          => $name,
					'platform'      => $plat,
					'icon'          => Helpers::platform_icon( $plat ),
					'saleHtml'      => Helpers::price_html( $sale ),
					'hint'          => $this->in_order_hint( $name ),
					'service_index' => isset( $wifl['service_index'] ) ? (int) $wifl['service_index'] : 0,
					'package_index' => isset( $wifl['package_index'] ) ? (int) $wifl['package_index'] : 0,
					'qty'           => $pkg,
					'needsLink'     => $sub ? false : Helpers::needs_post_link( $name ),
					'targetUrl'     => isset( $targets[ $key ] ) ? $targets[ $key ] : '',
					'isSubscription'=> ! empty( $sub ),
				);
			}
		}

		$saved    = max( 0, $regular_total - $sale_total );
		$subtotal = $regular_total > $sale_total ? $regular_total : $sale_total;
		$upsells  = $this->upsells( array_keys( $in_cart ), $items );

		$platform_fields = array();
		foreach ( Helpers::platform_keys() as $key ) {
			if ( empty( $platforms[ $key ] ) ) {
				continue;
			}
			$platform_fields[] = array(
				'key'      => $key,
				'heading'  => sprintf(
					/* translators: %s platform name */
					__( '%s account', 'woo-instagram-follower' ),
					Helpers::platform_label( $key )
				),
				'label'    => sprintf(
					/* translators: %s platform name */
					__( '%s username', 'woo-instagram-follower' ),
					Helpers::platform_label( $key )
				),
				'icon'     => Helpers::platform_icon( $key ),
				'value'    => isset( $accounts[ $key ] ) ? ltrim( (string) $accounts[ $key ], '@' ) : '',
				'required' => true,
				'recent'   => isset( $recent[ $key ] ) ? $recent[ $key ] : array(),
			);
		}

		$total_html = Helpers::price_html( $sale_total );
		$plain      = html_entity_decode( wp_strip_all_tags( $total_html ), ENT_QUOTES, 'UTF-8' );
		$headline   = trim( $plain . ' ' . ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ) );

		$state = array(
			'empty'          => empty( $items ),
			'count'          => WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0,
			'items'          => $items,
			'platforms'      => array_keys( $platforms ),
			'platformFields' => $platform_fields,
			'accounts'       => $accounts,
			'recent'         => $recent,
			'upsells'        => $upsells,
			'subtotalHtml'   => Helpers::price_html( $subtotal ),
			'discountHtml'   => $saved > 0 ? '−' . wp_strip_all_tags( html_entity_decode( Helpers::price_html( $saved ), ENT_QUOTES, 'UTF-8' ) ) : '',
			'totalHtml'      => $total_html,
			'totalHeadline'  => $headline,
			'itemsHtml'      => $this->items_html( $items ),
			'sumsHtml'       => '',
			'accountsHtml'   => '',
			'upsellsHtml'    => '',
			'checkoutUrl'    => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
			'shopUrl'        => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
		);

		return $this->with_html( $state );
	}

	/**
	 * Fill HTML fragments after payload base is built.
	 *
	 * @param array $state State.
	 * @return array
	 */
	private function with_html( $state ) {
		$state['sumsHtml']     = '';
		$state['accountsHtml'] = $this->accounts_html( $state );
		$state['upsellsHtml']  = $this->upsells_html( $state );
		return $state;
	}

	/**
	 * @param array $items Items.
	 * @return string
	 */
	private function items_html( $items ) {
		ob_start();
		echo '<h2 class="wifl-co__order-title">' . esc_html__( 'Order', 'woo-instagram-follower' ) . '</h2>';
		if ( empty( $items ) ) {
			echo '<p class="wifl-co__empty-items">' . esc_html__( 'No packages yet.', 'woo-instagram-follower' ) . '</p>';
			return ob_get_clean();
		}
		foreach ( $items as $item ) {
			?>
			<div class="wifl-co-item" data-key="<?php echo esc_attr( $item['key'] ); ?>">
				<span class="wifl-co-item__icon wifl-co-item__icon--<?php echo esc_attr( $item['platform'] ); ?>">
					<?php echo $item['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</span>
				<span class="wifl-co-item__name"><?php echo esc_html( $item['label'] ); ?></span>
				<span class="wifl-co-item__price"><?php echo Helpers::kses_price( $item['saleHtml'] ); ?></span>
				<button type="button" class="wifl-co-item__x wifl-js-remove" data-key="<?php echo esc_attr( $item['key'] ); ?>" aria-label="<?php esc_attr_e( 'Remove', 'woo-instagram-follower' ); ?>">×</button>
			</div>
			<?php
		}
		return ob_get_clean();
	}

	/**
	 * @param array $state State.
	 * @return string
	 */
	private function sums_html( $state ) {
		ob_start();
		?>
		<div class="wifl-co-sum">
			<span><?php esc_html_e( 'Subtotal', 'woo-instagram-follower' ); ?></span>
			<span><?php echo Helpers::kses_price( $state['subtotalHtml'] ); ?></span>
		</div>
		<?php if ( ! empty( $state['discountHtml'] ) ) : ?>
			<div class="wifl-co-sum wifl-co-sum--save">
				<span><?php esc_html_e( 'Add-on discount', 'woo-instagram-follower' ); ?></span>
				<span><?php echo esc_html( $state['discountHtml'] ); ?></span>
			</div>
		<?php endif; ?>
		<div class="wifl-co-sum wifl-co-sum--total">
			<span><?php esc_html_e( 'Total', 'woo-instagram-follower' ); ?></span>
			<span><?php echo esc_html( $state['totalHeadline'] ); ?></span>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * @param array $state State.
	 * @return string
	 */
	private function accounts_html( $state ) {
		$fields = isset( $state['platformFields'] ) ? $state['platformFields'] : array();
		$items  = isset( $state['items'] ) && is_array( $state['items'] ) ? $state['items'] : array();
		$needs  = false;
		foreach ( $items as $item ) {
			if ( ! empty( $item['needsLink'] ) ) {
				$needs = true;
				break;
			}
		}
		if ( empty( $fields ) && ! $needs ) {
			return '';
		}
		ob_start();
		foreach ( $fields as $field ) {
			$recent = ! empty( $field['recent'] ) && is_array( $field['recent'] ) ? $field['recent'] : array();
			?>
			<section class="wifl-co-acc">
				<div class="wifl-co-label-row">
					<label class="wifl-co-label" for="wifl_user_<?php echo esc_attr( $field['key'] ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
					<?php if ( ! empty( $field['required'] ) ) : ?>
						<span class="wifl-co-field__req"><?php esc_html_e( 'REQUIRED', 'woo-instagram-follower' ); ?></span>
					<?php endif; ?>
				</div>
				<label class="wifl-co-field">
					<span class="wifl-co-field__icon wifl-co-field__icon--<?php echo esc_attr( $field['key'] ); ?>" aria-hidden="true">
						<?php echo $field['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</span>
					<input
						type="text"
						id="wifl_user_<?php echo esc_attr( $field['key'] ); ?>"
						name="wifl_user_<?php echo esc_attr( $field['key'] ); ?>"
						class="wifl-co-field__input"
						placeholder="<?php echo esc_attr( $field['label'] ); ?>"
						value="<?php echo esc_attr( $field['value'] ); ?>"
						autocomplete="off"
						spellcheck="false"
						<?php echo ! empty( $field['required'] ) ? 'required' : ''; ?>
					/>
				</label>
				<?php if ( ! empty( $recent ) ) : ?>
					<div class="wifl-co-recent">
						<span><?php esc_html_e( 'Recent', 'woo-instagram-follower' ); ?></span>
						<?php foreach ( $recent as $user ) : ?>
							<span class="wifl-co-chip">
								<button type="button" class="wifl-co-chip__btn wifl-js-recent" data-platform="<?php echo esc_attr( $field['key'] ); ?>" data-user="<?php echo esc_attr( $user ); ?>">
									<span class="wifl-co-chip__av" aria-hidden="true"><?php echo esc_html( strtoupper( substr( $user, 0, 1 ) ) ); ?></span>
									@<?php echo esc_html( $user ); ?>
								</button>
								<button type="button" class="wifl-co-chip__x wifl-js-forget" data-platform="<?php echo esc_attr( $field['key'] ); ?>" data-user="<?php echo esc_attr( $user ); ?>" aria-label="<?php esc_attr_e( 'Remove', 'woo-instagram-follower' ); ?>">×</button>
							</span>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</section>
			<?php
		}

		$items = isset( $state['items'] ) && is_array( $state['items'] ) ? $state['items'] : array();
		foreach ( $items as $item ) {
			if ( empty( $item['needsLink'] ) ) {
				continue;
			}
			$key   = isset( $item['key'] ) ? (string) $item['key'] : '';
			$label = isset( $item['label'] ) ? $item['label'] : __( 'Package', 'woo-instagram-follower' );
			$value = isset( $item['targetUrl'] ) ? $item['targetUrl'] : '';
			$ph    = 'instagram' === ( isset( $item['platform'] ) ? $item['platform'] : '' )
				? 'https://www.instagram.com/p/…/'
				: ( 'tiktok' === $item['platform'] ? 'https://www.tiktok.com/@user/video/…' : 'https://www.youtube.com/watch?v=…' );
			?>
			<section class="wifl-co-acc wifl-co-acc--link">
				<div class="wifl-co-label-row">
					<label class="wifl-co-label" for="wifl_target_<?php echo esc_attr( $key ); ?>">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s package label */
								__( 'Post / reel link for %s', 'woo-instagram-follower' ),
								$label
							)
						);
						?>
					</label>
					<span class="wifl-co-field__req"><?php esc_html_e( 'REQUIRED', 'woo-instagram-follower' ); ?></span>
				</div>
				<label class="wifl-co-field">
					<span class="wifl-co-field__icon" aria-hidden="true"><?php echo $this->icon_link(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<input
						type="url"
						id="wifl_target_<?php echo esc_attr( $key ); ?>"
						name="wifl_target[<?php echo esc_attr( $key ); ?>]"
						class="wifl-co-field__input"
						placeholder="<?php echo esc_attr( $ph ); ?>"
						value="<?php echo esc_attr( $value ); ?>"
						autocomplete="off"
						spellcheck="false"
						required
					/>
				</label>
				<p class="wifl-co-field-hint"><?php esc_html_e( 'Paste the full post, reel, or video URL where likes/views/comments should be delivered.', 'woo-instagram-follower' ); ?></p>
			</section>
			<?php
		}

		return ob_get_clean();
	}

	/**
	 * @param array $state State.
	 * @return string
	 */
	private function upsells_html( $state ) {
		$rows = isset( $state['upsells'] ) ? $state['upsells'] : array();
		if ( empty( $rows ) ) {
			return '';
		}
		ob_start();
		foreach ( $rows as $row ) {
			$in = ! empty( $row['inOrder'] );
			?>
			<div class="wifl-co-up <?php echo $in ? 'is-in' : ''; ?>" data-id="<?php echo esc_attr( (string) $row['id'] ); ?>">
				<?php if ( $in ) : ?>
					<span class="wifl-co-up__mark" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
					</span>
				<?php else : ?>
					<button type="button" class="wifl-co-up__add wifl-js-add" data-id="<?php echo esc_attr( (string) $row['id'] ); ?>" data-service="<?php echo esc_attr( (string) $row['service'] ); ?>" data-package="<?php echo esc_attr( (string) $row['package'] ); ?>" aria-label="<?php esc_attr_e( 'Add to order', 'woo-instagram-follower' ); ?>"></button>
				<?php endif; ?>
				<div class="wifl-co-up__body">
					<div class="wifl-co-up__title"><?php echo esc_html( $row['title'] ); ?></div>
					<div class="wifl-co-up__hint"><?php echo esc_html( $row['hint'] ); ?></div>
				</div>
				<div class="wifl-co-up__side">
					<?php if ( $in ) : ?>
						<span class="wifl-co-up__in"><?php esc_html_e( 'In your order', 'woo-instagram-follower' ); ?></span>
					<?php else : ?>
						<span class="wifl-co-up__price"><?php echo esc_html( $row['priceHtml'] ); ?></span>
					<?php endif; ?>
				</div>
			</div>
			<?php
		}
		return ob_get_clean();
	}

	/**
	 * @param int[] $exclude Product IDs in cart.
	 * @param array $items   Cart items.
	 * @return array
	 */
	private function upsells( $exclude, $items ) {
		$out = array();
		foreach ( $items as $item ) {
			$out[] = array(
				'id'       => (int) $item['id'],
				'service'  => 0,
				'package'  => 0,
				'title'    => $item['label'],
				'hint'     => $item['hint'],
				'priceHtml'=> '',
				'inOrder'  => true,
				'key'      => $item['key'],
			);
		}

		$ids = get_posts(
			array(
				'post_type'    => 'product',
				'post_status'  => 'publish',
				'numberposts'  => 12,
				'orderby'      => 'date',
				'order'        => 'DESC',
				'fields'       => 'ids',
				'post__not_in' => array_map( 'intval', $exclude ),
			)
		);

		foreach ( (array) $ids as $id ) {
			$services = Helpers::get_services( (int) $id );
			if ( empty( $services ) ) {
				continue;
			}
			$product = wc_get_product( $id );
			if ( ! $product ) {
				continue;
			}
			$pkg = $services[0]['packages'][0];
			$sale = (float) $pkg['sale_price'];
			$out[] = array(
				'id'        => (int) $id,
				'service'   => 0,
				'package'   => 0,
				'title'     => Helpers::package_label( $pkg['qty'], $product->get_name() ),
				'hint'      => $this->upsell_hint( $product->get_name() ),
				'priceHtml' => '+' . html_entity_decode( wp_strip_all_tags( Helpers::price_html( $sale ) ), ENT_QUOTES, 'UTF-8' ),
				'inOrder'   => false,
				'key'       => '',
			);
			if ( count( $out ) >= count( $items ) + 4 ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * @param string $name Product name.
	 * @return string
	 */
	private function in_order_hint( $name ) {
		$kind = Helpers::service_kind( $name );
		if ( 'likes' === $kind ) {
			return __( 'A bump in likes that matches the rest of this order.', 'woo-instagram-follower' );
		}
		if ( 'views' === $kind ) {
			return __( 'Views that land with the rest of your order.', 'woo-instagram-follower' );
		}
		return __( 'A starter pack that looks natural next to your order.', 'woo-instagram-follower' );
	}

	/**
	 * @param string $name Product name.
	 * @return string
	 */
	private function upsell_hint( $name ) {
		$kind = Helpers::service_kind( $name );
		if ( 'likes' === $kind ) {
			return __( 'From real, active accounts.', 'woo-instagram-follower' );
		}
		if ( 'views' === $kind ) {
			return __( 'Higher-retention, premium accounts.', 'woo-instagram-follower' );
		}
		return __( 'From real, active accounts.', 'woo-instagram-follower' );
	}

	/**
	 * @return string[]
	 */
	private function cart_platforms() {
		$plats = array();
		if ( ! WC()->cart ) {
			return $plats;
		}
		foreach ( WC()->cart->get_cart() as $item ) {
			$pid  = (int) $item['product_id'];
			$name = isset( $item['data'] ) ? $item['data']->get_name() : '';
			$key  = Helpers::platform_key( $pid, $name );
			$plats[ $key ] = $key;
		}
		return array_values( $plats );
	}

	private function maybe_save_posted_accounts() {
		$accounts = Helpers::get_accounts();
		foreach ( Helpers::platform_keys() as $key ) {
			$field = 'wifl_user_' . $key;
			if ( isset( $_POST[ $field ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$accounts[ $key ] = Helpers::sanitize_username( wp_unslash( $_POST[ $field ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			}
		}
		if ( isset( $_POST['email'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$accounts['email'] = sanitize_email( wp_unslash( $_POST['email'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		if ( isset( $_POST['wifl_email'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$accounts['email'] = sanitize_email( wp_unslash( $_POST['wifl_email'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		if ( isset( $_POST['billing_email'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$accounts['email'] = sanitize_email( wp_unslash( $_POST['billing_email'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		if ( isset( $_POST['deals'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$accounts['deals'] = '1' === (string) wp_unslash( $_POST['deals'] ) ? '1' : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		Helpers::save_accounts( $accounts );
		$this->remember_usernames( $accounts );

		$targets = Helpers::get_targets();
		if ( isset( $_POST['wifl_target'] ) && is_array( $_POST['wifl_target'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$raw = wp_unslash( $_POST['wifl_target'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			foreach ( $raw as $key => $url ) {
				$key = wc_clean( (string) $key );
				$url = esc_url_raw( trim( (string) $url ) );
				if ( $key && $url && Helpers::is_allowed_target_url( $url ) ) {
					$targets[ $key ] = $url;
				} elseif ( $key ) {
					unset( $targets[ $key ] );
				}
			}
		}
		// Drop targets for cart keys that no longer exist.
		if ( WC()->cart ) {
			$keys = array_keys( WC()->cart->get_cart() );
			foreach ( array_keys( $targets ) as $key ) {
				if ( ! in_array( $key, $keys, true ) ) {
					unset( $targets[ $key ] );
				}
			}
		}
		Helpers::save_targets( $targets );
	}

	/**
	 * @return bool
	 */
	private function is_cart_page() {
		return ! is_admin() && function_exists( 'is_cart' ) && is_cart();
	}

	private function ensure_cart() {
		if ( function_exists( 'wc_load_cart' ) && ( is_null( WC()->cart ) || ! WC()->cart ) ) {
			wc_load_cart();
		}
	}

	public function strip_late_assets() {
		if ( $this->is_cart_page() ) {
			$this->strip_theme_assets();
		}
	}

	private function strip_theme_assets() {
		$needles = array(
			'elementor',
			'hello-elementor',
			'e-animation',
			'e-sticky',
			'e-popup',
			'e-apple',
			'widget-heading',
			'widget-image',
			'widget-nav-menu',
			'widget-social',
			'widget-icon-list',
			'wifl-float',
			'wifl-frontend',
			'wifl-cart-menu',
			'base-desktop',
			'base-mobile',
			'local-',
			'wp-block-library',
			'select2',
			'woocommerce-layout',
			'woocommerce-smallscreen',
			'woocommerce-general',
			'wc_stripe',
			'wc-stripe',
			'stripelink',
		);
		$keep = array( 'wifl-cart-page', 'wifl-checkout-page' );

		global $wp_styles, $wp_scripts;
		if ( $wp_styles instanceof \WP_Styles ) {
			foreach ( (array) $wp_styles->queue as $handle ) {
				if ( $this->should_strip_asset( $handle, $needles, $keep ) ) {
					wp_dequeue_style( $handle );
				}
			}
		}
		if ( $wp_scripts instanceof \WP_Scripts ) {
			foreach ( (array) $wp_scripts->queue as $handle ) {
				if ( $this->should_strip_asset( $handle, $needles, $keep ) ) {
					wp_dequeue_script( $handle );
				}
			}
		}
	}

	/**
	 * @param string   $handle  Asset handle.
	 * @param string[] $needles Substrings to strip.
	 * @param string[] $keep    Handles to keep.
	 * @return bool
	 */
	private function should_strip_asset( $handle, $needles, $keep ) {
		foreach ( $keep as $ok ) {
			if ( 0 === strpos( $handle, $ok ) ) {
				return false;
			}
		}
		foreach ( $needles as $needle ) {
			if ( false !== strpos( $handle, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return array
	 */
	private function get_recent() {
		$out = array(
			'instagram' => array(),
			'tiktok'    => array(),
			'youtube'   => array(),
		);
		$raw = array();
		if ( function_exists( 'WC' ) && WC()->session ) {
			$saved = WC()->session->get( 'wifl_recent_accounts' );
			if ( is_array( $saved ) ) {
				$raw = $saved;
			}
		}
		if ( empty( $raw ) && ! empty( $_COOKIE['wifl_recent'] ) ) {
			$cookie = json_decode( wp_unslash( $_COOKIE['wifl_recent'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( is_array( $cookie ) ) {
				$raw = $cookie;
			}
		}
		foreach ( $out as $key => $empty ) {
			if ( empty( $raw[ $key ] ) || ! is_array( $raw[ $key ] ) ) {
				continue;
			}
			$clean = array();
			foreach ( $raw[ $key ] as $user ) {
				$user = ltrim( sanitize_text_field( (string) $user ), '@' );
				if ( '' === $user ) {
					continue;
				}
				$clean[ strtolower( $user ) ] = $user;
			}
			$out[ $key ] = array_values( $clean );
		}
		return $out;
	}

	/**
	 * @param array $accounts Accounts.
	 */
	private function remember_usernames( $accounts ) {
		$recent = $this->get_recent();
		foreach ( Helpers::platform_keys() as $key ) {
			$user = isset( $accounts[ $key ] ) ? ltrim( (string) $accounts[ $key ], '@' ) : '';
			if ( '' === $user ) {
				continue;
			}
			$list = isset( $recent[ $key ] ) ? $recent[ $key ] : array();
			$list = array_values(
				array_filter(
					$list,
					function ( $row ) use ( $user ) {
						return strtolower( (string) $row ) !== strtolower( $user );
					}
				)
			);
			array_unshift( $list, $user );
			$recent[ $key ] = array_slice( $list, 0, 4 );
		}
		$this->persist_recent( $recent );
	}

	/**
	 * @param array $recent Recent usernames.
	 */
	private function persist_recent( $recent ) {
		if ( function_exists( 'WC' ) && WC()->session ) {
			WC()->session->set( 'wifl_recent_accounts', $recent );
		}
		$path = defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/';
		$host = defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '';
		setcookie( 'wifl_recent', wp_json_encode( $recent ), time() + YEAR_IN_SECONDS, $path, $host, is_ssl(), true );
	}

	private function icon_lock() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></svg>';
	}

	private function icon_bolt() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L4 14h7l-1 8 10-14h-7l0-6z"/></svg>';
	}

	private function icon_refresh() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M21 12a9 9 0 11-3-6.7"/><path d="M21 4v6h-6"/></svg>';
	}

	private function icon_chat() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 12a8 8 0 01-8 8H7l-4 3V12a8 8 0 018-8h2a8 8 0 018 8z"/></svg>';
	}

	private function icon_mail() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 7 9-7"/></svg>';
	}

	private function icon_link() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.07 0l1.41-1.41a5 5 0 00-7.07-7.07L10 5.93"/><path d="M14 11a5 5 0 00-7.07 0L5.52 12.4a5 5 0 007.07 7.07L14 18.07"/></svg>';
	}

	private function icon_info() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/></svg>';
	}
}
