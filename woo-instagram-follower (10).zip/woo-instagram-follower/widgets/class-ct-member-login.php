<?php
/**
 * Elementor widget: CT member login (login + registration).
 *
 * @package WIFL
 */

namespace WIFL\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Plugin as ElementorPlugin;
use Elementor\Repeater;
use Elementor\Widget_Base;
use WIFL\Member\Forms;
use WIFL\Member\Member;
use WIFL\Member\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CT_Member_Login extends Widget_Base {

	public function get_name() {
		return 'ct-member-login';
	}

	public function get_title() {
		return esc_html__( 'CT member login', 'woo-instagram-follower' );
	}

	public function get_icon() {
		return 'eicon-lock-user';
	}

	public function get_categories() {
		return array( 'basic' );
	}

	public function get_keywords() {
		return array( 'login', 'register', 'member', 'sign in', 'account', 'ct' );
	}

	public function get_style_depends() {
		return array( 'wifl-member' );
	}

	public function get_script_depends() {
		return array( 'wifl-member' );
	}

	public function has_widget_inner_wrapper(): bool {
		return ! ElementorPlugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function get_html_wrapper_class() {
		return 'elementor-widget-ct-member-login';
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Form', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Layout', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'split',
				'options' => array(
					'split'   => esc_html__( 'Split (form + promo)', 'woo-instagram-follower' ),
					'default' => esc_html__( 'Form only', 'woo-instagram-follower' ),
				),
			)
		);

		$this->add_control(
			'show_promo',
			array(
				'label'        => esc_html__( 'Promo panel', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'layout' => 'split',
				),
			)
		);

		$this->add_control(
			'hide_promo_tablet',
			array(
				'label'        => esc_html__( 'Hide promo on tablet', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Show', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'layout'     => 'split',
					'show_promo' => 'yes',
				),
			)
		);

		$this->add_control(
			'hide_promo_mobile',
			array(
				'label'        => esc_html__( 'Hide promo on mobile', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Show', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'layout'     => 'split',
					'show_promo' => 'yes',
				),
			)
		);

		$this->add_control(
			'default_panel',
			array(
				'label'   => esc_html__( 'Default panel', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'login',
				'options' => array(
					'login'    => esc_html__( 'Login', 'woo-instagram-follower' ),
					'register' => esc_html__( 'Registration', 'woo-instagram-follower' ),
				),
			)
		);

		$this->add_control(
			'show_logo',
			array(
				'label'        => esc_html__( 'Show logo', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'logo',
			array(
				'label'       => esc_html__( 'Logo', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::MEDIA,
				'default'     => array(
					'url' => '',
				),
				'description' => esc_html__( 'Upload a logo for this form. Falls back to Membership settings if empty.', 'woo-instagram-follower' ),
				'condition'   => array(
					'show_logo' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		$this->register_redirect_controls();
		$this->register_brand_content_controls();
		$this->register_login_content_controls();
		$this->register_register_content_controls();
		$this->register_promo_content_controls();

		$this->start_controls_section(
			'section_layout',
			array(
				'label' => esc_html__( 'Size & spacing', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'form_width',
			array(
				'label'      => esc_html__( 'Width', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'vw' ),
				'range'      => array(
					'px' => array(
						'min' => 320,
						'max' => 1600,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'default'    => array(
					'size' => 100,
					'unit' => '%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'form_max_width',
			array(
				'label'      => esc_html__( 'Max width', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 400,
						'max' => 1600,
					),
				),
				'default'    => array(
					'size' => 100,
					'unit' => '%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form__layout' => 'max-width: {{SIZE}}{{UNIT}}; width: 100%;',
				),
			)
		);

		$this->add_responsive_control(
			'form_min_height',
			array(
				'label'      => esc_html__( 'Min height', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'vh', 'px' ),
				'range'      => array(
					'vh' => array(
						'min' => 50,
						'max' => 100,
					),
					'px' => array(
						'min' => 400,
						'max' => 1200,
					),
				),
				'default'    => array(
					'size' => 100,
					'unit' => 'vh',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form' => 'min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'form_height',
			array(
				'label'      => esc_html__( 'Height', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'vh', 'px' ),
				'range'      => array(
					'vh' => array(
						'min' => 50,
						'max' => 100,
					),
					'px' => array(
						'min' => 400,
						'max' => 1200,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'form_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'default'    => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_max_width',
			array(
				'label'      => esc_html__( 'Form card max width', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 280,
						'max' => 560,
					),
				),
				'default'    => array(
					'size' => 420,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form__card' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'layout_gap',
			array(
				'label'      => esc_html__( 'Column gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 64,
					),
				),
				'default'    => array(
					'size' => 0,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form__layout' => 'gap: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'layout' => 'split',
				),
			)
		);

		$this->add_control(
			'form_align',
			array(
				'label'     => esc_html__( 'Horizontal align', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => esc_html__( 'Left', 'woo-instagram-follower' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'     => array(
						'title' => esc_html__( 'Center', 'woo-instagram-follower' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'   => array(
						'title' => esc_html__( 'Right', 'woo-instagram-follower' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-form-wrap' => 'display: flex; width: 100%; justify-content: {{VALUE}};',
					'{{WRAPPER}} .wifl-member-form' => 'width: 100%;',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_form_style',
			array(
				'label' => esc_html__( 'Form box', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'form_bg',
				'selector' => '{{WRAPPER}} .wifl-member-form',
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'form_border',
				'selector' => '{{WRAPPER}} .wifl-member-form',
			)
		);

		$this->add_responsive_control(
			'form_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_fields_style',
			array(
				'label' => esc_html__( 'Fields', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'field_height',
			array(
				'label'      => esc_html__( 'Height', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 40,
						'max' => 80,
					),
				),
				'default'    => array(
					'size' => 56,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-field' => 'height: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'field_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '0',
					'right'  => '16',
					'bottom' => '0',
					'left'   => '16',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-field' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .wifl-member-field--password' => 'padding-right: calc({{RIGHT}}{{UNIT}} + 32px);',
				),
			)
		);

		$this->add_responsive_control(
			'field_icon_gap',
			array(
				'label'      => esc_html__( 'Icon & text gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 4,
						'max' => 32,
					),
				),
				'default'    => array(
					'size' => 12,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-field' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'field_gap',
			array(
				'label'      => esc_html__( 'Gap between fields', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 32,
					),
				),
				'default'    => array(
					'size' => 12,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form__fields' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'field_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-field' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => 'field_border',
				'selector'       => '{{WRAPPER}} .wifl-member-field',
				'fields_options' => array(
					'border' => array(
						'default' => 'solid',
					),
					'width'  => array(
						'default' => array(
							'top'    => '1',
							'right'  => '1',
							'bottom' => '1',
							'left'   => '1',
							'unit'   => 'px',
						),
					),
					'color'  => array(
						'default' => '#e5e7eb',
					),
				),
			)
		);

		$this->add_control(
			'field_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-field__input' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'field_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '12',
					'right'  => '12',
					'bottom' => '12',
					'left'   => '12',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-field' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->register_login_style_controls();
		$this->register_register_style_controls();
		$this->register_promo_style_controls();

		$this->start_controls_section(
			'section_logo_style',
			array(
				'label'     => esc_html__( 'Logo', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_logo' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'logo_max_height',
			array(
				'label'      => esc_html__( 'Max height', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 20,
						'max' => 120,
					),
				),
				'default'    => array(
					'size' => 42,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form__logo img' => 'max-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'logo_spacing',
			array(
				'label'      => esc_html__( 'Bottom spacing', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 48,
					),
				),
				'default'    => array(
					'size' => 20,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form__logo' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * @return array
	 */
	private function content_defaults() {
		return Settings::defaults();
	}

	private function register_redirect_controls() {
		$this->start_controls_section(
			'section_redirects',
			array(
				'label' => esc_html__( 'Redirects', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'login_redirect_link',
			array(
				'label'       => esc_html__( 'After login redirect', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active' => true,
				),
				'placeholder' => esc_html__( 'https://your-site.com/profile/', 'woo-instagram-follower' ),
				'default'     => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'description' => esc_html__( 'Leave empty to use Membership settings. Use the dynamic tag to pick an internal page.', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'register_redirect_link',
			array(
				'label'       => esc_html__( 'After register redirect', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active' => true,
				),
				'placeholder' => esc_html__( 'https://your-site.com/profile/', 'woo-instagram-follower' ),
				'default'     => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'description' => esc_html__( 'Leave empty to use Membership settings. Use the dynamic tag to pick an internal page.', 'woo-instagram-follower' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * @param array $link Elementor URL control value.
	 * @return string
	 */
	private function resolve_url_control( $link ) {
		if ( empty( $link ) || ! is_array( $link ) || empty( $link['url'] ) ) {
			return '';
		}

		return esc_url_raw( $link['url'] );
	}

	private function register_brand_content_controls() {
		$d = $this->content_defaults();

		$this->start_controls_section(
			'section_brand_content',
			array(
				'label' => esc_html__( 'Brand', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'membership_name',
			array(
				'label'       => esc_html__( 'Brand name', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => $d['membership_name'],
				'description' => esc_html__( 'Shown when no logo image is set.', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'brand_color',
			array(
				'label'     => esc_html__( 'Brand color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => $d['brand_color'],
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-form' => '--wifl-member-brand: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_login_content_controls() {
		$d = $this->content_defaults();

		$this->start_controls_section(
			'section_login_content',
			array(
				'label' => esc_html__( 'Login panel', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'login_title',
			array(
				'label'   => esc_html__( 'Title', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['login_title'],
			)
		);

		$this->add_control(
			'login_subtitle',
			array(
				'label'   => esc_html__( 'Subtitle', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => $d['login_subtitle'],
				'rows'    => 2,
			)
		);

		$this->add_control(
			'login_fields_heading',
			array(
				'label'     => esc_html__( 'Fields', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'login_email_placeholder',
			array(
				'label'   => esc_html__( 'Email placeholder', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Email address', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'login_password_placeholder',
			array(
				'label'   => esc_html__( 'Password placeholder', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Password', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'show_remember',
			array(
				'label'        => esc_html__( 'Remember me', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'login_remember_text',
			array(
				'label'     => esc_html__( 'Remember me label', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Remember me', 'woo-instagram-follower' ),
				'condition' => array(
					'show_remember' => 'yes',
				),
			)
		);

		$this->add_control(
			'login_button',
			array(
				'label'     => esc_html__( 'Button text', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => $d['login_button'],
				'separator' => 'before',
			)
		);

		$this->add_control(
			'login_footer_text',
			array(
				'label'   => esc_html__( 'Footer text', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['login_footer_text'],
			)
		);

		$this->add_control(
			'login_footer_link',
			array(
				'label'   => esc_html__( 'Footer link text', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['login_footer_link'],
			)
		);

		$this->end_controls_section();
	}

	private function register_register_content_controls() {
		$d = $this->content_defaults();

		$this->start_controls_section(
			'section_register_content',
			array(
				'label' => esc_html__( 'Registration panel', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'enable_registration',
			array(
				'label'        => esc_html__( 'Allow registration', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'No', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => $d['enable_registration'],
			)
		);

		$this->add_control(
			'register_title',
			array(
				'label'   => esc_html__( 'Title', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['register_title'],
			)
		);

		$this->add_control(
			'register_subtitle',
			array(
				'label'   => esc_html__( 'Subtitle', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => $d['register_subtitle'],
				'rows'    => 2,
			)
		);

		$this->add_control(
			'register_fields_heading',
			array(
				'label'     => esc_html__( 'Fields', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'register_email_placeholder',
			array(
				'label'   => esc_html__( 'Email placeholder', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Email address', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'register_password_placeholder',
			array(
				'label'   => esc_html__( 'Password placeholder', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Create a password', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'register_confirm_placeholder',
			array(
				'label'   => esc_html__( 'Confirm password placeholder', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Confirm password', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'register_button',
			array(
				'label'     => esc_html__( 'Button text', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => $d['register_button'],
				'separator' => 'before',
			)
		);

		$this->add_control(
			'register_footer_text',
			array(
				'label'   => esc_html__( 'Footer text', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['register_footer_text'],
			)
		);

		$this->add_control(
			'register_footer_link',
			array(
				'label'   => esc_html__( 'Footer link text', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['register_footer_link'],
			)
		);

		$this->end_controls_section();
	}

	private function register_promo_content_controls() {
		$d = $this->content_defaults();

		$this->start_controls_section(
			'section_promo_content',
			array(
				'label'     => esc_html__( 'Promo panel', 'woo-instagram-follower' ),
				'condition' => array(
					'layout'     => 'split',
					'show_promo' => 'yes',
				),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'slide_quote',
			array(
				'label'   => esc_html__( 'Quote', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => $d['promo_quote'],
				'rows'    => 3,
			)
		);

		$repeater->add_control(
			'slide_author_name',
			array(
				'label'   => esc_html__( 'Author name', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['promo_author_name'],
			)
		);

		$repeater->add_control(
			'slide_author_subtitle',
			array(
				'label'   => esc_html__( 'Author subtitle', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['promo_author_subtitle'],
			)
		);

		$repeater->add_control(
			'slide_avatar_badge',
			array(
				'label'   => esc_html__( 'Avatar badge', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '1',
			)
		);

		$this->add_control(
			'promo_slides',
			array(
				'label'       => esc_html__( 'Testimonial slides', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => $this->default_promo_slides(),
				'title_field' => '{{{ slide_author_name }}}',
			)
		);

		$this->add_control(
			'promo_slider_heading',
			array(
				'label'     => esc_html__( 'Slider', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'promo_autoplay',
			array(
				'label'        => esc_html__( 'Autoplay', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'No', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'promo_autoplay_speed',
			array(
				'label'      => esc_html__( 'Autoplay speed (ms)', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 2000,
						'max' => 12000,
					),
				),
				'default'    => array(
					'size' => 2000,
					'unit' => 'px',
				),
				'condition'  => array(
					'promo_autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'promo_slide_effect',
			array(
				'label'   => esc_html__( 'Animation', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'reveal',
				'options' => array(
					'reveal' => esc_html__( 'Hide & show', 'woo-instagram-follower' ),
					'fade'   => esc_html__( 'Fade up', 'woo-instagram-follower' ),
					'slide'  => esc_html__( 'Slide', 'woo-instagram-follower' ),
				),
			)
		);

		$this->add_control(
			'promo_community_heading',
			array(
				'label'     => esc_html__( 'Community', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$face_repeater = new Repeater();

		$face_repeater->add_control(
			'face_image',
			array(
				'label'   => esc_html__( 'Avatar image', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array( 'url' => '' ),
			)
		);

		$this->add_control(
			'promo_faces',
			array(
				'label'       => esc_html__( 'Community avatars', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $face_repeater->get_controls(),
				'default'     => $this->default_promo_faces(),
				'title_field' => esc_html__( 'Avatar', 'woo-instagram-follower' ),
				'prevent_empty' => false,
			)
		);

		$this->add_control(
			'promo_you_label',
			array(
				'label'   => esc_html__( 'You badge text', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['promo_you_label'],
			)
		);

		$this->add_control(
			'promo_social_proof',
			array(
				'label'       => esc_html__( 'Social proof line', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => $d['promo_social_proof'],
				'rows'        => 2,
				'description' => esc_html__( 'Use <span class="wifl-member-promo__social-strong"> for bold text.', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'promo_status',
			array(
				'label'   => esc_html__( 'Status line', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['promo_status'],
			)
		);

		$this->add_control(
			'promo_footer_label',
			array(
				'label'   => esc_html__( 'Footer label', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => $d['promo_footer_label'],
			)
		);

		$this->end_controls_section();
	}

	/**
	 * @return array
	 */
	private function default_promo_faces() {
		return array(
			array( 'face_image' => array( 'url' => '' ) ),
			array( 'face_image' => array( 'url' => '' ) ),
			array( 'face_image' => array( 'url' => '' ) ),
			array( 'face_image' => array( 'url' => '' ) ),
		);
	}

	/**
	 * @return array
	 */
	private function default_promo_slides() {
		$d = $this->content_defaults();

		return array(
			array(
				'slide_quote'           => $d['promo_quote'],
				'slide_author_name'     => $d['promo_author_name'],
				'slide_author_subtitle' => $d['promo_author_subtitle'],
				'slide_avatar_badge'    => '1',
			),
			array(
				'slide_quote'           => 'A hugely reliable website where you can buy Instagram followers and likes in packages of any size and scope.',
				'slide_author_name'     => 'ABC Action News',
				'slide_author_subtitle' => 'Press review',
				'slide_avatar_badge'    => '2',
			),
			array(
				'slide_quote'           => 'One of the best places to elevate your Instagram account on any budget, with fast delivery and real results.',
				'slide_author_name'     => 'Creator Weekly',
				'slide_author_subtitle' => 'Editor review',
				'slide_avatar_badge'    => '3',
			),
		);
	}

	private function register_login_style_controls() {
		$this->start_controls_section(
			'section_login_style',
			array(
				'label' => esc_html__( 'Login panel', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'login_title_typography',
				'label'    => esc_html__( 'Title typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-member-panel--login .wifl-member-form__title',
			)
		);

		$this->add_control(
			'login_title_color',
			array(
				'label'     => esc_html__( 'Title color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--login .wifl-member-form__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'login_subtitle_typography',
				'label'     => esc_html__( 'Subtitle typography', 'woo-instagram-follower' ),
				'selector'  => '{{WRAPPER}} .wifl-member-panel--login .wifl-member-form__subtitle',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'login_subtitle_color',
			array(
				'label'     => esc_html__( 'Subtitle color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--login .wifl-member-form__subtitle' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'login_footer_typography',
				'label'     => esc_html__( 'Footer typography', 'woo-instagram-follower' ),
				'selector'  => '{{WRAPPER}} .wifl-member-panel--login .wifl-member-form__footer',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'login_footer_color',
			array(
				'label'     => esc_html__( 'Footer color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--login .wifl-member-form__footer' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'login_link_color',
			array(
				'label'     => esc_html__( 'Footer link color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--login .wifl-member-switch' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'login_button_heading',
			array(
				'label'     => esc_html__( 'Button', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'login_button_typography',
				'selector' => '{{WRAPPER}} .wifl-member-panel--login .wifl-member-btn',
			)
		);

		$this->add_control(
			'login_button_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#374151',
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--login .wifl-member-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'login_button_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--login .wifl-member-btn' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'login_button_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-panel--login .wifl-member-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_register_style_controls() {
		$this->start_controls_section(
			'section_register_style',
			array(
				'label' => esc_html__( 'Registration panel', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'register_title_typography',
				'label'    => esc_html__( 'Title typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-member-panel--register .wifl-member-form__title',
			)
		);

		$this->add_control(
			'register_title_color',
			array(
				'label'     => esc_html__( 'Title color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--register .wifl-member-form__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'register_subtitle_typography',
				'label'     => esc_html__( 'Subtitle typography', 'woo-instagram-follower' ),
				'selector'  => '{{WRAPPER}} .wifl-member-panel--register .wifl-member-form__subtitle',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'register_subtitle_color',
			array(
				'label'     => esc_html__( 'Subtitle color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--register .wifl-member-form__subtitle' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'register_footer_typography',
				'label'     => esc_html__( 'Footer typography', 'woo-instagram-follower' ),
				'selector'  => '{{WRAPPER}} .wifl-member-panel--register .wifl-member-form__footer',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'register_footer_color',
			array(
				'label'     => esc_html__( 'Footer color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--register .wifl-member-form__footer' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'register_link_color',
			array(
				'label'     => esc_html__( 'Footer link color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--register .wifl-member-switch' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'register_button_heading',
			array(
				'label'     => esc_html__( 'Button', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'register_button_typography',
				'selector' => '{{WRAPPER}} .wifl-member-panel--register .wifl-member-btn',
			)
		);

		$this->add_control(
			'register_button_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#374151',
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--register .wifl-member-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'register_button_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-panel--register .wifl-member-btn' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'register_button_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-panel--register .wifl-member-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_promo_style_controls() {
		$this->start_controls_section(
			'section_promo_style',
			array(
				'label'     => esc_html__( 'Promo panel', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'layout'     => 'split',
					'show_promo' => 'yes',
				),
			)
		);

		$this->add_control(
			'promo_brand_color',
			array(
				'label'     => esc_html__( 'Panel accent', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffb5a7',
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-form__promo' => 'background: radial-gradient(circle at 1px 1px, rgba(0, 0, 0, 0.07) 1px, transparent 0) 0 0 / 16px 16px, linear-gradient(160deg, color-mix(in srgb, {{VALUE}} 72%, #fff), {{VALUE}});',
				),
			)
		);

		$this->add_responsive_control(
			'promo_grid_column_width',
			array(
				'label'      => esc_html__( 'Column width', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( '%', 'px', 'vw' ),
				'range'      => array(
					'%'  => array( 'min' => 10, 'max' => 90 ),
					'px' => array( 'min' => 200, 'max' => 1200 ),
				),
				'default'    => array( 'size' => 50, 'unit' => '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form--split .wifl-member-form__layout' => 'grid-template-columns: minmax(0, 1fr) minmax(0, {{SIZE}}{{UNIT}});',
				),
				'separator'  => 'before',
			)
		);

		$this->add_responsive_control(
			'promo_min_height',
			array(
				'label'      => esc_html__( 'Min height', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'vh', 'px' ),
				'default'    => array( 'size' => 100, 'unit' => 'vh' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-form__promo' => 'min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'promo_shell_max_width',
			array(
				'label'      => esc_html__( 'Content max width', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'default'    => array( 'size' => 360, 'unit' => 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-promo__shell' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'promo_slide_duration',
			array(
				'label'      => esc_html__( 'Transition duration (ms)', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 200,
						'max' => 1200,
					),
				),
				'default'    => array(
					'size' => 500,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-member-promo__slide' => 'transition-duration: {{SIZE}}ms;',
				),
				'separator'  => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'promo_quote_typography',
				'label'    => esc_html__( 'Quote typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-member-promo__quote',
			)
		);

		$this->add_control(
			'promo_quote_color',
			array(
				'label'     => esc_html__( 'Quote color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-promo__quote' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'promo_author_typography',
				'label'     => esc_html__( 'Author typography', 'woo-instagram-follower' ),
				'selector'  => '{{WRAPPER}} .wifl-member-promo__author-name',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'promo_social_color',
			array(
				'label'     => esc_html__( 'Social proof color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-member-promo__social' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		Member::enqueue_assets();

		if ( ! Member::can_show_login_form() ) {
			echo Member::logged_in_form_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		$settings = $this->get_settings_for_display();
		$layout   = isset( $settings['layout'] ) ? $settings['layout'] : 'split';

		if ( 'split' === $layout && 'yes' !== ( $settings['show_promo'] ?? 'yes' ) ) {
			$layout = 'default';
		}

		$logo_url = '';
		if ( ! empty( $settings['logo']['url'] ) ) {
			$logo_url = $settings['logo']['url'];
		}

		$atts = array(
			'layout'        => $layout,
			'show_logo'     => $settings['show_logo'] ?? 'yes',
			'view'          => $settings['default_panel'] ?? 'login',
			'full_height'   => 'yes',
			'logo_url'      => $logo_url,
			'show_remember' => ! empty( $settings['show_remember'] ) && 'yes' === $settings['show_remember'] ? 'yes' : 'no',
			'enable_registration' => ! empty( $settings['enable_registration'] ) && 'yes' === $settings['enable_registration'] ? 'yes' : 'no',
			'login_redirect_url'    => $this->resolve_url_control( $settings['login_redirect_link'] ?? array() ),
			'register_redirect_url' => $this->resolve_url_control( $settings['register_redirect_link'] ?? array() ),
		);

		foreach ( Forms::overridable_content_keys() as $key ) {
			if ( isset( $settings[ $key ] ) ) {
				$atts[ $key ] = $settings[ $key ];
			}
		}

		if ( ! empty( $settings['promo_faces'] ) && is_array( $settings['promo_faces'] ) ) {
			$atts['promo_faces'] = $settings['promo_faces'];
		} else {
			for ( $i = 1; $i <= 4; $i++ ) {
				$face_key = 'promo_face_' . $i;
				if ( ! empty( $settings[ $face_key ] ) ) {
					$atts[ $face_key ] = $settings[ $face_key ];
				}
			}
		}

		if ( ! empty( $settings['promo_slides'] ) && is_array( $settings['promo_slides'] ) ) {
			$atts['promo_slides'] = $settings['promo_slides'];
		}

		$atts['promo_autoplay'] = ! empty( $settings['promo_autoplay'] ) && 'yes' === $settings['promo_autoplay'] ? 'yes' : 'no';
		if ( ! empty( $settings['promo_autoplay_speed']['size'] ) ) {
			$atts['promo_autoplay_speed'] = absint( $settings['promo_autoplay_speed']['size'] );
		}
		if ( ! empty( $settings['promo_slide_effect'] ) ) {
			$atts['promo_slide_effect'] = $settings['promo_slide_effect'];
		}

		$wrap_classes = array( 'wifl-member-form-wrap' );
		if ( 'yes' === ( $settings['hide_promo_tablet'] ?? 'yes' ) ) {
			$wrap_classes[] = 'wifl-member-form-wrap--hide-promo-tablet';
		}
		if ( 'yes' === ( $settings['hide_promo_mobile'] ?? 'yes' ) ) {
			$wrap_classes[] = 'wifl-member-form-wrap--hide-promo-mobile';
		}

		echo '<div class="' . esc_attr( implode( ' ', $wrap_classes ) ) . '">';
		echo Forms::instance()->render( $atts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
	}
}
