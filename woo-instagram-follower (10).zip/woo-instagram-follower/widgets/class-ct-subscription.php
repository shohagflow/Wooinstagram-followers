<?php
/**
 * Elementor widget: CT subscription.
 *
 * @package WIFL
 */

namespace WIFL\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Plugin as ElementorPlugin;
use Elementor\Repeater;
use Elementor\Widget_Base;
use WIFL\Member\Subscriptions;
use WIFL\Product_Subscription_Meta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CT_Subscription extends Widget_Base {

	public function get_name() {
		return 'ct-subscription';
	}

	public function get_title() {
		return esc_html__( 'CT subscription', 'woo-instagram-follower' );
	}

	public function get_icon() {
		return 'eicon-price-table';
	}

	public function get_categories() {
		return array( 'basic', 'wifl-member' );
	}

	public function get_keywords() {
		return array( 'subscription', 'pricing', 'plan', 'instagram', 'ct' );
	}

	public function get_style_depends() {
		return array( 'wifl-subscription' );
	}

	public function has_widget_inner_wrapper(): bool {
		return ! ElementorPlugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function get_html_wrapper_class() {
		return 'elementor-widget-ct-subscription';
	}

	/**
	 * @return array
	 */
	protected function default_plans() {
		$features = "Up to 4 posts per day\nReal likes from real users\nFree views on all videos\nSafe & secure\n24/7 customer support";

		return array(
			array(
				'name'        => 'Starter Likes',
				'kicker'      => 'INSTAGRAM • HIGH QUALITY',
				'badge'       => 'GREAT VALUE',
				'qty'         => '1,000',
				'qty_label'   => 'likes per post',
				'price'       => '99.99',
				'period'      => '/mo',
				'unit_price'  => '',
				'features'    => $features,
				'button_text' => 'get start',
				'button_url'  => array( 'url' => '#' ),
				'footer'      => '30-day money back guarantee',
				'featured'    => '',
			),
			array(
				'name'        => 'Growth Likes',
				'kicker'      => 'INSTAGRAM • HIGH QUALITY',
				'badge'       => '',
				'qty'         => '1,500',
				'qty_label'   => 'likes per post',
				'price'       => '139.99',
				'period'      => '/mo',
				'unit_price'  => '',
				'features'    => $features,
				'button_text' => 'get start',
				'button_url'  => array( 'url' => '#' ),
				'footer'      => '30-day money back guarantee',
				'featured'    => 'yes',
			),
			array(
				'name'        => 'Pro Likes',
				'kicker'      => 'INSTAGRAM • HIGH QUALITY',
				'badge'       => 'BEST RATE',
				'qty'         => '2,500',
				'qty_label'   => 'likes per post',
				'price'       => '199.99',
				'period'      => '/mo',
				'unit_price'  => '',
				'features'    => $features,
				'button_text' => 'get start',
				'button_url'  => array( 'url' => '#' ),
				'footer'      => '30-day money back guarantee',
				'featured'    => '',
			),
		);
	}

	/**
	 * @return array
	 */
	protected function product_options() {
		$options = array();
		if ( ! function_exists( 'wc_get_products' ) ) {
			return $options;
		}

		$products = wc_get_products(
			array(
				'limit'   => 200,
				'status'  => 'publish',
				'return'  => 'ids',
				'orderby' => 'title',
				'order'   => 'ASC',
			)
		);

		foreach ( $products as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}
			$options[ (string) $product_id ] = $product->get_name();
		}

		return $options;
	}

	/**
	 * @return array
	 */
	protected function category_options() {
		$options = array();
		$terms   = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return $options;
		}

		foreach ( $terms as $term ) {
			$options[ (string) (int) $term->term_id ] = $term->name;
		}

		return $options;
	}

	/**
	 * Plan source dropdown: every WooCommerce product category + extras.
	 *
	 * @return array
	 */
	protected function plan_source_options() {
		$options = array(
			'all' => esc_html__( 'All subscription products (dynamic)', 'woo-instagram-follower' ),
		);

		foreach ( $this->category_options() as $term_id => $name ) {
			$options[ 'cat_' . $term_id ] = sprintf(
				/* translators: %s: category name */
				esc_html__( 'Category: %s', 'woo-instagram-follower' ),
				$name
			);
		}

		$options['product'] = esc_html__( 'Single product → Subscription tab', 'woo-instagram-follower' );
		$options['admin']   = esc_html__( 'Membership → Subscriptions', 'woo-instagram-follower' );
		$options['custom']  = esc_html__( 'Custom plans in this widget', 'woo-instagram-follower' );

		return $options;
	}

	/**
	 * Default plan source = all subscription products dynamically.
	 *
	 * @return string
	 */
	protected function default_plan_source() {
		return 'all';
	}

	protected function register_controls() {
		$this->register_plans_controls();
		$this->register_layout_controls();
		$this->register_content_visibility_controls();
		$this->register_style_layout_controls();
		$this->register_style_card_controls();
		$this->register_style_featured_controls();
		$this->register_style_kicker_controls();
		$this->register_style_badge_controls();
		$this->register_style_qty_controls();
		$this->register_style_price_controls();
		$this->register_style_features_controls();
		$this->register_style_button_controls();
		$this->register_style_footer_controls();
	}

	protected function register_plans_controls() {
		$this->start_controls_section(
			'section_plans',
			array(
				'label' => esc_html__( 'Plans', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'plan_source',
			array(
				'label'       => esc_html__( 'Plan source', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::SELECT2,
				'default'     => 'all',
				'options'     => $this->plan_source_options(),
				'label_block' => true,
				'description' => esc_html__( 'Subscription cards load dynamically from WooCommerce products that have the Subscription tab filled in.', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'product_id',
			array(
				'label'       => esc_html__( 'Product', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::SELECT2,
				'options'     => $this->product_options(),
				'label_block' => true,
				'condition'   => array(
					'plan_source' => 'product',
				),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'kicker',
			array(
				'label'   => esc_html__( 'Label', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => 'INSTAGRAM • HIGH QUALITY',
			)
		);

		$repeater->add_control(
			'badge',
			array(
				'label'       => esc_html__( 'Badge', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => 'GREAT VALUE',
			)
		);

		$repeater->add_control(
			'qty',
			array(
				'label'   => esc_html__( 'Quantity', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '1,000',
			)
		);

		$repeater->add_control(
			'qty_label',
			array(
				'label'   => esc_html__( 'Quantity label', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => 'likes per post',
			)
		);

		$repeater->add_control(
			'price',
			array(
				'label'   => esc_html__( 'Price', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '99.99',
			)
		);

		$repeater->add_control(
			'period',
			array(
				'label'   => esc_html__( 'Period', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '/mo',
			)
		);

		$repeater->add_control(
			'features',
			array(
				'label'       => esc_html__( 'Features', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXTAREA,
				'description' => esc_html__( 'One feature per line.', 'woo-instagram-follower' ),
				'default'     => "Up to 4 posts per day\nReal likes from real users\nFree views on all videos\nSafe & secure\n24/7 customer support",
			)
		);

		$repeater->add_control(
			'button_text',
			array(
				'label'   => esc_html__( 'Button text', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => 'get start',
			)
		);

		$repeater->add_control(
			'button_url',
			array(
				'label'       => esc_html__( 'Button link', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'https://',
				'default'     => array( 'url' => '#' ),
			)
		);

		$repeater->add_control(
			'footer',
			array(
				'label'   => esc_html__( 'Footer', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '30-day money back guarantee',
			)
		);

		$repeater->add_control(
			'featured',
			array(
				'label'        => esc_html__( 'Featured plan', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'plans',
			array(
				'label'       => esc_html__( 'Subscription plans', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => $this->default_plans(),
				'title_field' => '{{{ qty }}} {{{ qty_label }}}',
				'condition'   => array(
					'plan_source' => 'custom',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_layout_controls() {
		$this->start_controls_section(
			'section_layout',
			array(
				'label' => esc_html__( 'Layout', 'woo-instagram-follower' ),
			)
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'          => esc_html__( 'Columns', 'woo-instagram-follower' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '3',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'selectors'      => array(
					'{{WRAPPER}} .wifl-sub' => '--wifl-sub-cols: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'columns_gap',
			array(
				'label'      => esc_html__( 'Columns gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 80,
					),
				),
				'default'    => array(
					'size' => 22,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub__grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'content_align',
			array(
				'label'     => esc_html__( 'Alignment', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card' => 'text-align: {{VALUE}};',
					'{{WRAPPER}} .wifl-sub-card__top' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .wifl-sub-card__kicker' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .wifl-sub-card__price' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .wifl-sub-card__features li' => 'justify-content: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'show_currency',
			array(
				'label'        => esc_html__( 'Show currency symbol', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'currency_symbol',
			array(
				'label'       => esc_html__( 'Custom currency', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => '$',
				'condition'   => array(
					'show_currency' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_text_override',
			array(
				'label'       => esc_html__( 'Button text override', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Leave empty to use plan button text', 'woo-instagram-follower' ),
				'label_block' => true,
			)
		);

		$this->end_controls_section();
	}

	protected function register_content_visibility_controls() {
		$this->start_controls_section(
			'section_visibility',
			array(
				'label' => esc_html__( 'Show / Hide', 'woo-instagram-follower' ),
			)
		);

		$toggles = array(
			'show_kicker'   => array( 'Subscription plan name', 'yes' ),
			'show_icon'     => array( 'Platform icon', 'yes' ),
			'show_badge'    => array( 'Badge', 'yes' ),
			'show_qty'      => array( 'Quantity', 'yes' ),
			'show_qty_label'=> array( 'Quantity label', 'yes' ),
			'show_price'    => array( 'Price', 'yes' ),
			'show_period'   => array( 'Period', 'yes' ),
			'show_features' => array( 'Features', 'yes' ),
			'show_button'   => array( 'Button', 'yes' ),
			'show_footer'   => array( 'Footer', 'yes' ),
		);

		foreach ( $toggles as $key => $meta ) {
			$this->add_control(
				$key,
				array(
					'label'        => esc_html( $meta[0] ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
					'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
					'return_value' => 'yes',
					'default'      => $meta[1],
				)
			);
		}

		$this->end_controls_section();
	}

	protected function register_style_layout_controls() {
		$this->start_controls_section(
			'section_style_layout',
			array(
				'label' => esc_html__( 'Layout', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'accent',
			array(
				'label'     => esc_html__( 'Accent color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ff5a43',
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub' => '--wifl-sub-accent: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'grid_max_width',
			array(
				'label'      => esc_html__( 'Max width', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 320,
						'max' => 1600,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub__grid' => 'max-width: {{SIZE}}{{UNIT}}; margin-left: auto; margin-right: auto;',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_card_controls() {
		$this->start_controls_section(
			'section_style_card',
			array(
				'label' => esc_html__( 'Card', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'card_bg',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .wifl-sub-card',
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'card_border',
				'selector' => '{{WRAPPER}} .wifl-sub-card',
			)
		);

		$this->add_responsive_control(
			'card_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow',
				'selector' => '{{WRAPPER}} .wifl-sub-card',
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_hover_heading',
			array(
				'label'     => esc_html__( 'Hover', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'card_hover_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_hover_shadow',
				'selector' => '{{WRAPPER}} .wifl-sub-card:hover',
			)
		);

		$this->add_control(
			'card_hover_transform',
			array(
				'label'      => esc_html__( 'Lift on hover', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 20,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card:hover' => 'transform: translateY(-{{SIZE}}{{UNIT}});',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_featured_controls() {
		$this->start_controls_section(
			'section_style_featured',
			array(
				'label' => esc_html__( 'Featured card', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'featured_border_color',
			array(
				'label'     => esc_html__( 'Border color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'featured_border_width',
			array(
				'label'      => esc_html__( 'Border width', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 8,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured' => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'featured_bg',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .wifl-sub-card.is-featured',
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'featured_shadow',
				'selector' => '{{WRAPPER}} .wifl-sub-card.is-featured',
			)
		);

		$this->add_control(
			'featured_scale',
			array(
				'label'     => esc_html__( 'Scale', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 1,
						'max'  => 1.15,
						'step' => 0.01,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured' => 'transform: scale({{SIZE}});',
				),
			)
		);

		$this->add_control(
			'featured_qty_color',
			array(
				'label'     => esc_html__( 'Quantity color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured .wifl-sub-card__qty' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_kicker_controls() {
		$this->start_controls_section(
			'section_style_kicker',
			array(
				'label'     => esc_html__( 'Subscription plan name', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_kicker' => 'yes',
				),
			)
		);

		$this->add_control(
			'plan_name_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__plan-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'plan_name_bg',
			array(
				'label'     => esc_html__( 'Badge background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card:not(.is-featured) .wifl-sub-card__plan-name' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'plan_name_border',
			array(
				'label'     => esc_html__( 'Badge border', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card:not(.is-featured) .wifl-sub-card__plan-name' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'plan_name_featured_bg',
			array(
				'label'     => esc_html__( 'Featured badge background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured .wifl-sub-card__plan-name' => 'background-color: {{VALUE}}; border-color: transparent;',
				),
			)
		);

		$this->add_control(
			'plan_name_featured_color',
			array(
				'label'     => esc_html__( 'Featured badge text', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured .wifl-sub-card__plan-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'plan_name_typo',
				'selector' => '{{WRAPPER}} .wifl-sub-card__plan-name',
			)
		);

		$this->add_responsive_control(
			'plan_name_radius',
			array(
				'label'      => esc_html__( 'Badge radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__plan-name' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'plan_name_spacing',
			array(
				'label'      => esc_html__( 'Bottom spacing', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__plan-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_badge_controls() {
		$this->start_controls_section(
			'section_style_badge',
			array(
				'label'     => esc_html__( 'Badge', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_badge' => 'yes',
				),
			)
		);

		$this->add_control(
			'badge_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__badge' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'badge_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__badge' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'badge_typo',
				'selector' => '{{WRAPPER}} .wifl-sub-card__badge',
			)
		);

		$this->add_responsive_control(
			'badge_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__badge' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'badge_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_qty_controls() {
		$this->start_controls_section(
			'section_style_qty',
			array(
				'label' => esc_html__( 'Quantity', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'qty_color',
			array(
				'label'     => esc_html__( 'Quantity color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__qty' => 'color: {{VALUE}};',
				),
				'condition' => array(
					'show_qty' => 'yes',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'qty_typo',
				'selector'  => '{{WRAPPER}} .wifl-sub-card__qty',
				'condition' => array(
					'show_qty' => 'yes',
				),
			)
		);

		$this->add_control(
			'qty_label_color',
			array(
				'label'     => esc_html__( 'Label color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__qty-label' => 'color: {{VALUE}};',
				),
				'condition' => array(
					'show_qty_label' => 'yes',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'qty_label_typo',
				'selector'  => '{{WRAPPER}} .wifl-sub-card__qty-label',
				'condition' => array(
					'show_qty_label' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'qty_label_spacing',
			array(
				'label'      => esc_html__( 'Label bottom spacing', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__qty-label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'show_qty_label' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_price_controls() {
		$this->start_controls_section(
			'section_style_price',
			array(
				'label'     => esc_html__( 'Price', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_price' => 'yes',
				),
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => esc_html__( 'Price color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__amount' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_typo',
				'selector' => '{{WRAPPER}} .wifl-sub-card__amount',
			)
		);

		$this->add_control(
			'period_color',
			array(
				'label'     => esc_html__( 'Period color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__period' => 'color: {{VALUE}};',
				),
				'condition' => array(
					'show_period' => 'yes',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'period_typo',
				'selector'  => '{{WRAPPER}} .wifl-sub-card__period',
				'condition' => array(
					'show_period' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_features_controls() {
		$this->start_controls_section(
			'section_style_features',
			array(
				'label'     => esc_html__( 'Features', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_features' => 'yes',
				),
			)
		);

		$this->add_control(
			'features_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__features li' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'check_color',
			array(
				'label'     => esc_html__( 'Check color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__check' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'features_divider',
			array(
				'label'     => esc_html__( 'Divider color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__features' => 'border-top-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'features_typo',
				'selector' => '{{WRAPPER}} .wifl-sub-card__features li',
			)
		);

		$this->add_responsive_control(
			'features_gap',
			array(
				'label'      => esc_html__( 'Item gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__features' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'features_spacing',
			array(
				'label'      => esc_html__( 'Section spacing', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__features' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important; padding-top: {{TOP}}{{UNIT}} !important;',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_button_controls() {
		$this->start_controls_section(
			'section_style_button',
			array(
				'label'     => esc_html__( 'Button', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_button' => 'yes',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typo',
				'selector' => '{{WRAPPER}} .wifl-sub-card__btn',
			)
		);

		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_min_height',
			array(
				'label'      => esc_html__( 'Min height', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 30,
						'max' => 80,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__btn' => 'min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs( 'button_tabs' );

		$this->start_controls_tab(
			'button_tab_normal',
			array(
				'label' => esc_html__( 'Normal', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__btn' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_control(
			'button_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card:not(.is-featured) .wifl-sub-card__btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_featured_bg',
			array(
				'label'     => esc_html__( 'Featured background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured .wifl-sub-card__btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .wifl-sub-card__btn',
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'button_shadow',
				'selector' => '{{WRAPPER}} .wifl-sub-card__btn',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_tab_hover',
			array(
				'label' => esc_html__( 'Hover', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'button_hover_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__btn:hover' => 'color: {{VALUE}} !important;',
				),
			)
		);

		$this->add_control(
			'button_hover_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card:not(.is-featured) .wifl-sub-card__btn:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_featured_hover_bg',
			array(
				'label'     => esc_html__( 'Featured background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card.is-featured .wifl-sub-card__btn:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_hover_border',
			array(
				'label'     => esc_html__( 'Border color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__btn:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_style_footer_controls() {
		$this->start_controls_section(
			'section_style_footer',
			array(
				'label'     => esc_html__( 'Footer', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_footer' => 'yes',
				),
			)
		);

		$this->add_control(
			'footer_color',
			array(
				'label'     => esc_html__( 'Color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__footer' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'footer_typo',
				'selector' => '{{WRAPPER}} .wifl-sub-card__footer',
			)
		);

		$this->add_responsive_control(
			'footer_align',
			array(
				'label'     => esc_html__( 'Alignment', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .wifl-sub-card__footer' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'footer_spacing',
			array(
				'label'      => esc_html__( 'Top spacing', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-sub-card__footer' => 'margin-top: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * @param array  $settings Settings.
	 * @param string $key      Key.
	 * @return bool
	 */
	protected function is_shown( $settings, $key ) {
		return ! isset( $settings[ $key ] ) || 'yes' === $settings[ $key ];
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$source   = ! empty( $settings['plan_source'] ) ? (string) $settings['plan_source'] : 'all';
		$plans    = array();
		$dynamic  = false;

		// Legacy: plan_source=category + product_cat control.
		if ( 'category' === $source && ! empty( $settings['product_cat'] ) ) {
			$source = 'cat_' . absint( $settings['product_cat'] );
		}

		if ( 'all' === $source && class_exists( '\WIFL\Product_Subscription_Meta' ) ) {
			$plans   = Product_Subscription_Meta::get_all_widget_plans();
			$dynamic = true;
		} elseif ( 0 === strpos( $source, 'cat_' ) && class_exists( '\WIFL\Product_Subscription_Meta' ) ) {
			$term_id = absint( substr( $source, 4 ) );
			$plans   = Product_Subscription_Meta::get_widget_plans_for_category( $term_id );
			$dynamic = true;
		} elseif ( 'admin' === $source && class_exists( '\WIFL\Member\Subscriptions' ) ) {
			$plans = Subscriptions::get_widget_plans();
			$dynamic = true;
		} elseif ( 'product' === $source && class_exists( '\WIFL\Product_Subscription_Meta' ) ) {
			$product_id = ! empty( $settings['product_id'] ) ? absint( $settings['product_id'] ) : 0;
			$plans      = Product_Subscription_Meta::get_widget_plans( $product_id );
			$dynamic    = true;
		} elseif ( 'custom' === $source && ! empty( $settings['plans'] ) && is_array( $settings['plans'] ) ) {
			$plans = $settings['plans'];
		}

		if ( empty( $plans ) && ! $dynamic ) {
			$plans = $this->default_plans();
		}
		?>
		<div class="wifl-sub">
			<?php if ( empty( $plans ) ) : ?>
				<div class="wifl-sub__empty">
					<?php
					$is_edit = class_exists( '\Elementor\Plugin' )
						&& isset( \Elementor\Plugin::$instance->editor )
						&& \Elementor\Plugin::$instance->editor->is_edit_mode();
					if ( $is_edit ) :
						?>
						<p><?php esc_html_e( 'No subscription plans found. Open a WooCommerce product → Subscription tab, add plan details, and update the product.', 'woo-instagram-follower' ); ?></p>
					<?php endif; ?>
				</div>
			<?php else : ?>
				<div class="wifl-sub__grid">
					<?php foreach ( $plans as $plan ) : ?>
						<?php $this->render_card( $plan, $settings ); ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * @param array $plan     Plan.
	 * @param array $settings Widget settings.
	 */
	protected function render_card( $plan, $settings = array() ) {
		$featured = ! empty( $plan['featured'] ) && 'yes' === $plan['featured'];
		$features = array();
		if ( ! empty( $plan['features'] ) ) {
			$features = preg_split( '/\r\n|\r|\n/', $plan['features'] );
			$features = array_values( array_filter( array_map( 'trim', $features ) ) );
		}

		$url    = ! empty( $plan['button_url']['url'] ) ? $plan['button_url']['url'] : '';
		$target = ! empty( $plan['button_url']['is_external'] ) ? ' target="_blank" rel="noopener noreferrer"' : '';

		if ( ! empty( $plan['product_id'] ) ) {
			$url    = Product_Subscription_Meta::buy_url( (int) $plan['product_id'], isset( $plan['id'] ) ? $plan['id'] : '' );
			$target = '';
		} elseif ( ! $url || '#' === $url ) {
			$url    = Product_Subscription_Meta::cart_redirect_url();
			$target = '';
		}
		$price  = isset( $plan['price'] ) ? $plan['price'] : '';

		$symbol = '';
		if ( $this->is_shown( $settings, 'show_currency' ) ) {
			if ( ! empty( $settings['currency_symbol'] ) ) {
				$symbol = $settings['currency_symbol'];
			} else {
				$symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$';
			}
		}

		$btn_text = ! empty( $settings['button_text_override'] )
			? $settings['button_text_override']
			: ( ! empty( $plan['button_text'] ) ? $plan['button_text'] : '' );

		if ( '' === $btn_text || 'Create account' === $btn_text ) {
			$btn_text = __( 'get start', 'woo-instagram-follower' );
		}

		$class = 'wifl-sub-card' . ( $featured ? ' is-featured' : '' );

		$subscription_plan_name = '';
		if ( ! empty( $plan['name'] ) ) {
			$subscription_plan_name = $plan['name'];
		} elseif ( ! empty( $plan['kicker'] ) ) {
			$subscription_plan_name = $plan['kicker'];
		}
		?>
		<article class="<?php echo esc_attr( $class ); ?>">
			<?php if ( $this->is_shown( $settings, 'show_kicker' ) && '' !== $subscription_plan_name ) : ?>
				<div class="wifl-sub-card__plan-wrap">
					<span class="wifl-sub-card__plan-name"><?php echo esc_html( $subscription_plan_name ); ?></span>
				</div>
			<?php endif; ?>

			<?php if ( $this->is_shown( $settings, 'show_qty' ) ) : ?>
				<div class="wifl-sub-card__qty"><?php echo esc_html( isset( $plan['qty'] ) ? $plan['qty'] : '' ); ?></div>
			<?php endif; ?>

			<?php if ( $this->is_shown( $settings, 'show_qty_label' ) ) : ?>
				<div class="wifl-sub-card__qty-label"><?php echo esc_html( isset( $plan['qty_label'] ) ? $plan['qty_label'] : '' ); ?></div>
			<?php endif; ?>

			<?php if ( $this->is_shown( $settings, 'show_price' ) ) : ?>
				<div class="wifl-sub-card__price">
					<span class="wifl-sub-card__amount"><?php echo esc_html( $symbol . $price ); ?></span>
					<?php if ( $this->is_shown( $settings, 'show_period' ) && ! empty( $plan['period'] ) ) : ?>
						<span class="wifl-sub-card__period"><?php echo esc_html( $plan['period'] ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( $this->is_shown( $settings, 'show_features' ) && ! empty( $features ) ) : ?>
				<ul class="wifl-sub-card__features">
					<?php foreach ( $features as $feature ) : ?>
						<li>
							<span class="wifl-sub-card__check" aria-hidden="true">
								<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
							</span>
							<?php echo esc_html( $feature ); ?>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<?php if ( $this->is_shown( $settings, 'show_button' ) ) : ?>
				<a class="wifl-sub-card__btn" href="<?php echo esc_url( $url ); ?>"<?php echo $target; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
					<?php echo esc_html( $btn_text ); ?>
				</a>
			<?php endif; ?>

			<?php if ( $this->is_shown( $settings, 'show_footer' ) && ! empty( $plan['footer'] ) ) : ?>
				<p class="wifl-sub-card__footer"><?php echo esc_html( $plan['footer'] ); ?></p>
			<?php endif; ?>
		</article>
		<?php
	}
}
