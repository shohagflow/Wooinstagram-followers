<?php
/**
 * Elementor widget: CT- follower.
 *
 * @package WIFL
 */

namespace WIFL\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Plugin as ElementorPlugin;
use Elementor\Widget_Base;
use WIFL\Frontend;
use WIFL\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CT_Follower extends Widget_Base {

	public function get_name() {
		return 'ct-follower';
	}

	public function get_title() {
		return esc_html__( 'CT- follower', 'woo-instagram-follower' );
	}

	public function get_icon() {
		return 'eicon-instagram-post';
	}

	public function get_categories() {
		return array( 'basic' );
	}

	public function get_keywords() {
		return array( 'instagram', 'follower', 'likes', 'woocommerce', 'package', 'price', 'ct' );
	}

	public function get_style_depends() {
		return array( 'wifl-frontend' );
	}

	public function get_script_depends() {
		return array( 'wifl-frontend' );
	}

	public function has_widget_inner_wrapper(): bool {
		return ! ElementorPlugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function get_html_wrapper_class() {
		return 'elementor-widget-ct-follower';
	}

	/**
	 * Dropdown lists WooCommerce product categories only.
	 *
	 * @return array
	 */
	protected function get_product_options() {
		$options = array(
			''        => esc_html__( '— Select a category —', 'woo-instagram-follower' ),
			'all'     => esc_html__( 'All categories', 'woo-instagram-follower' ),
			'current' => esc_html__( 'Current product', 'woo-instagram-follower' ),
		);

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return $options;
		}

		foreach ( $terms as $term ) {
			$options[ 'cat_' . (int) $term->term_id ] = $term->name;
		}

		return $options;
	}

	protected function register_controls() {
		$this->register_content_controls();
		$this->register_layout_controls();
		$this->register_button_content_controls();
		$this->register_style_general_controls();
		$this->register_style_service_controls();
		$this->register_style_feature_controls();
		$this->register_style_package_controls();
		$this->register_style_price_controls();
		$this->register_style_button_controls();
	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Category', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'product_id',
			array(
				'label'       => esc_html__( 'WooCommerce category', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::SELECT2,
				'options'     => $this->get_product_options(),
				'label_block' => true,
				'description' => esc_html__( 'All categories shows every matching product as a card in the grid (columns / rows). No category tabs.', 'woo-instagram-follower' ),
			)
		);

		$this->end_controls_section();
	}

	protected function register_layout_controls() {
		$this->start_controls_section(
			'section_layout',
			array(
				'label' => esc_html__( 'Layout', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'show_services',
			array(
				'label'        => esc_html__( 'Service cards', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_features',
			array(
				'label'        => esc_html__( 'Features (from WooCommerce)', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_packages',
			array(
				'label'        => esc_html__( 'Quantity packages', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_price',
			array(
				'label'        => esc_html__( 'Price', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_regular_price',
			array(
				'label'        => esc_html__( 'Original price', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'show_price' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_savings',
			array(
				'label'        => esc_html__( 'Savings', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'show_price' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_cart',
			array(
				'label'        => esc_html__( 'Add to cart button', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_responsive_control(
			'service_columns',
			array(
				'label'          => esc_html__( 'Service columns', 'woo-instagram-follower' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
				),
				'default'        => '2',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'separator'      => 'before',
				'condition'      => array(
					'show_services' => 'yes',
				),
				'selectors'      => array(
					'{{WRAPPER}} .wifl' => '--wifl-service-cols: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'service_rows',
			array(
				'label'          => esc_html__( 'Service rows', 'woo-instagram-follower' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
				),
				'default'        => '5',
				'tablet_default' => '5',
				'mobile_default' => '5',
				'condition'      => array(
					'show_services' => 'yes',
				),
				'selectors'      => array(
					'{{WRAPPER}} .wifl' => '--wifl-service-rows: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_button_content_controls() {
		$this->start_controls_section(
			'section_button',
			array(
				'label' => esc_html__( 'Cart button', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button text', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Add to Cart', 'woo-instagram-follower' ),
				'label_block' => true,
				'dynamic'     => array( 'active' => true ),
			)
		);

		$this->add_control(
			'button_icon',
			array(
				'label'            => esc_html__( 'Icon', 'woo-instagram-follower' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'skin'             => 'inline',
				'label_block'      => false,
			)
		);

		$this->add_control(
			'button_icon_position',
			array(
				'label'     => esc_html__( 'Icon position', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'woo-instagram-follower' ),
						'icon'  => 'eicon-h-align-left',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'woo-instagram-follower' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'left',
				'toggle'    => false,
				'condition' => array(
					'button_icon[value]!' => '',
				),
			)
		);

		$this->add_control(
			'savings_text',
			array(
				'label'     => esc_html__( 'Savings label', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( "You're saving", 'woo-instagram-follower' ),
				'separator' => 'before',
				'dynamic'   => array( 'active' => true ),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_general_controls() {
		$this->start_controls_section(
			'section_style_general',
			array(
				'label' => esc_html__( 'General', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'accent_color',
			array(
				'label'     => esc_html__( 'Accent color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#FF5C3A',
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-accent: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'accent_hover_color',
			array(
				'label'     => esc_html__( 'Accent hover', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#E84E2F',
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-accent-hover: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'text_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-text: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'widget_gap',
			array(
				'label'      => esc_html__( 'Section gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 8,
						'max' => 48,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl' => '--wifl-gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'widget_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'footer_gap',
			array(
				'label'      => esc_html__( 'Price / button gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 8,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-footer' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_service_controls() {
		$this->start_controls_section(
			'section_style_services',
			array(
				'label' => esc_html__( 'Service cards', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-card-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_border_color',
			array(
				'label'     => esc_html__( 'Border color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-card-border: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl' => '--wifl-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow',
				'selector' => '{{WRAPPER}} .wifl-service',
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_selected_border',
			array(
				'label'     => esc_html__( 'Selected border color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service.is-active' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_icon_size',
			array(
				'label'      => esc_html__( 'Icon size', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 12,
						'max' => 64,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-service__icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_icon_color',
			array(
				'label'     => esc_html__( 'Icon color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service:not(.wifl-service--premium) .wifl-service__icon' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'check_idle_color',
			array(
				'label'     => esc_html__( 'Check (idle)', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-check-idle: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'check_active_color',
			array(
				'label'     => esc_html__( 'Check (selected)', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service.is-active .wifl-service__check' => 'background: {{VALUE}}; border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'service_title_typo',
				'label'    => esc_html__( 'Title typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-service__title',
			)
		);

		$this->add_control(
			'service_title_color',
			array(
				'label'     => esc_html__( 'Title color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service:not(.wifl-service--premium) .wifl-service__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'premium_header_color',
			array(
				'label'     => esc_html__( 'Premium header background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service--premium .wifl-service__head' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'premium_title_color',
			array(
				'label'     => esc_html__( 'Premium title color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service--premium .wifl-service__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_feature_controls() {
		$this->start_controls_section(
			'section_style_features',
			array(
				'label' => esc_html__( 'Features', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'features_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Feature text comes from the WooCommerce product (Instagram Follower → Features). Style them here.', 'woo-instagram-follower' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'feature_typo',
				'label'    => esc_html__( 'Typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-service__features li',
			)
		);

		$this->add_control(
			'feature_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-feature: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'feature_gap',
			array(
				'label'      => esc_html__( 'Item gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 24,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-service__features' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'feature_check_color',
			array(
				'label'     => esc_html__( 'Standard check color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service:not(.wifl-service--premium) .wifl-service__features li::before' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'premium_check_color',
			array(
				'label'     => esc_html__( 'Premium check color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-service--premium .wifl-service__features li::before' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_package_controls() {
		$this->start_controls_section(
			'section_style_packages',
			array(
				'label' => esc_html__( 'Quantity packages', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'package_columns',
			array(
				'label'          => esc_html__( 'Columns', 'woo-instagram-follower' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => array(
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'default'        => '4',
				'tablet_default' => '4',
				'mobile_default' => '2',
				'selectors'      => array(
					'{{WRAPPER}} .wifl' => '--wifl-pkg-cols: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'package_gap',
			array(
				'label'      => esc_html__( 'Gap', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 4,
						'max' => 32,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl' => '--wifl-pkg-gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'package_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 32,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl' => '--wifl-pkg-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'package_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-pkg-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'package_qty_color',
			array(
				'label'     => esc_html__( 'Quantity color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-pkg:not(.is-active) .wifl-pkg__qty' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'package_qty_typo',
				'label'    => esc_html__( 'Quantity typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-pkg__qty',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'package_off_typo',
				'label'    => esc_html__( 'Price typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-pkg__off',
			)
		);

		$this->add_control(
			'package_off_color',
			array(
				'label'     => esc_html__( 'Price color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-pkg:not(.is-active) .wifl-pkg__off' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'package_active_heading',
			array(
				'label'     => esc_html__( 'Selected package', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'package_active_bg',
			array(
				'label'     => esc_html__( 'Selected background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-pkg.is-active' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'package_active_qty_color',
			array(
				'label'     => esc_html__( 'Selected quantity color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-pkg.is-active .wifl-pkg__qty' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'package_active_off_color',
			array(
				'label'     => esc_html__( 'Selected price color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-pkg.is-active .wifl-pkg__off' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'package_active_off_bg',
			array(
				'label'     => esc_html__( 'Selected price pill', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-pkg.is-active .wifl-pkg__off' => 'background: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_price_controls() {
		$this->start_controls_section(
			'section_style_price',
			array(
				'label' => esc_html__( 'Price & savings', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'sale_typo',
				'label'    => esc_html__( 'Sale price typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-price__sale, {{WRAPPER}} .wifl-price__sale .woocommerce-Price-amount, {{WRAPPER}} .wifl-price__sale .amount, {{WRAPPER}} .wifl-price__sale bdi',
			)
		);

		$this->add_control(
			'sale_color',
			array(
				'label'     => esc_html__( 'Sale price color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-price__sale, {{WRAPPER}} .wifl-price__sale .woocommerce-Price-amount, {{WRAPPER}} .wifl-price__sale .amount, {{WRAPPER}} .wifl-price__sale bdi' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'regular_typo',
				'label'    => esc_html__( 'Original price typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-price__regular, {{WRAPPER}} .wifl-price__regular .woocommerce-Price-amount, {{WRAPPER}} .wifl-price__regular .amount, {{WRAPPER}} .wifl-price__regular bdi',
			)
		);

		$this->add_control(
			'regular_color',
			array(
				'label'     => esc_html__( 'Original price color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-price__regular, {{WRAPPER}} .wifl-price__regular .woocommerce-Price-amount, {{WRAPPER}} .wifl-price__regular .amount, {{WRAPPER}} .wifl-price__regular bdi' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'savings_label_color',
			array(
				'label'     => esc_html__( 'Savings label color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-savings__label' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'savings_tag_bg',
			array(
				'label'     => esc_html__( 'Savings tag background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-save-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'savings_tag_color',
			array(
				'label'     => esc_html__( 'Savings tag color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl' => '--wifl-save-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'savings_typo',
				'label'    => esc_html__( 'Savings typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-savings',
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_button_controls() {
		$this->start_controls_section(
			'section_style_button',
			array(
				'label' => esc_html__( 'Add to cart button', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typo',
				'selector' => '{{WRAPPER}} .wifl-cart',
			)
		);

		$this->start_controls_tabs( 'button_tabs' );

		$this->start_controls_tab(
			'button_tab_normal',
			array(
				'label' => esc_html__( 'Normal', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'button_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_tab_hover',
			array(
				'label' => esc_html__( 'Hover', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'button_bg_hover',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart:hover, {{WRAPPER}} .wifl-cart:focus-visible' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_color_hover',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart:hover, {{WRAPPER}} .wifl-cart:focus-visible' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'button_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .wifl' => '--wifl-btn-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', 'rem' ),
				'default'    => array(
					'top'      => '14',
					'right'    => '28',
					'bottom'   => '14',
					'left'     => '28',
					'unit'     => 'px',
					'isLinked' => false,
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .wifl-cart',
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'button_shadow',
				'selector' => '{{WRAPPER}} .wifl-cart',
			)
		);

		$this->add_responsive_control(
			'button_icon_size',
			array(
				'label'      => esc_html__( 'Icon size', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 10,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart__icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wifl-cart__icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_icon_spacing',
			array(
				'label'      => esc_html__( 'Icon spacing', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 24,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Published products in a category that have Instagram Follower packages.
	 *
	 * @param int $term_id Product category term ID.
	 * @return int[]
	 */
	protected function get_follower_product_ids_for_category( $term_id ) {
		$term_id = (int) $term_id;
		if ( $term_id < 1 ) {
			return array();
		}

		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'numberposts'    => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'fields'         => 'ids',
				'tax_query'      => array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'term_id',
						'terms'    => $term_id,
					),
				),
			)
		);

		$out = array();
		foreach ( (array) $ids as $id ) {
			if ( ! empty( Helpers::get_services( (int) $id ) ) ) {
				$out[] = (int) $id;
			}
		}

		return $out;
	}

	/**
	 * All published products that have Instagram Follower packages.
	 *
	 * @return int[]
	 */
	protected function get_all_follower_product_ids() {
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'numberposts'    => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'fields'         => 'ids',
			)
		);

		$out = array();
		foreach ( (array) $ids as $id ) {
			if ( ! empty( Helpers::get_services( (int) $id ) ) ) {
				$out[] = (int) $id;
			}
		}

		return $out;
	}

	/**
	 * One card per product for the services grid.
	 *
	 * @param array $blocks Product blocks.
	 * @return array{0:int,1:array}
	 */
	protected function flatten_product_cards( $blocks ) {
		$services = array();
		$first_id = 0;

		foreach ( $blocks as $block ) {
			$pid = isset( $block['id'] ) ? (int) $block['id'] : 0;
			if ( ! $first_id && $pid ) {
				$first_id = $pid;
			}
			if ( empty( $block['services'] ) || ! is_array( $block['services'] ) ) {
				continue;
			}

			$list = count( $blocks ) > 1 ? array_slice( $block['services'], 0, 1 ) : $block['services'];
			foreach ( $list as $s_index => $service ) {
				if ( ! is_array( $service ) ) {
					continue;
				}
				$service['productId']    = $pid;
				$service['serviceIndex'] = (int) $s_index;
				$services[]              = $service;
			}
		}

		return array( $first_id, $services );
	}

	/**
	 * @param int    $product_id Product ID.
	 * @param string $label      Unused label kept for compatibility.
	 * @return array|null
	 */
	protected function block_from_product( $product_id, $label = '' ) {
		$product_id = (int) $product_id;
		$raw        = Helpers::get_services( $product_id );
		if ( empty( $raw ) ) {
			return null;
		}

		return array(
			'id'       => $product_id,
			'services' => Helpers::services_payload( $raw, $product_id ),
			'label'    => $label,
		);
	}

	/**
	 * @param array $settings Settings.
	 * @return array<int, array{id:int, services:array, label:string}>
	 */
	protected function get_render_blocks( $settings ) {
		$raw    = isset( $settings['product_id'] ) ? (string) $settings['product_id'] : '';
		$blocks = array();

		if ( 'all' === $raw ) {
			foreach ( $this->get_all_follower_product_ids() as $id ) {
				$block = $this->block_from_product( $id );
				if ( $block ) {
					$blocks[] = $block;
				}
			}

			return $blocks;
		}

		if ( 0 === strpos( $raw, 'cat_' ) ) {
			foreach ( $this->get_follower_product_ids_for_category( absint( substr( $raw, 4 ) ) ) as $id ) {
				$block = $this->block_from_product( $id );
				if ( $block ) {
					$blocks[] = $block;
				}
			}

			return $blocks;
		}

		$id = $this->resolve_product_id( $settings );
		if ( ! $id ) {
			return array();
		}

		$block = $this->block_from_product( $id );
		return $block ? array( $block ) : array();
	}

	/**
	 * @param array $settings Settings.
	 * @return int
	 */
	protected function resolve_product_id( $settings ) {
		$raw = isset( $settings['product_id'] ) ? $settings['product_id'] : '';

		if ( 'all' === $raw ) {
			return 0;
		}

		if ( is_string( $raw ) && 0 === strpos( $raw, 'cat_' ) ) {
			$ids = $this->get_follower_product_ids_for_category( absint( substr( $raw, 4 ) ) );
			return empty( $ids ) ? 0 : (int) $ids[0];
		}

		if ( 'current' === $raw ) {
			if ( function_exists( 'wc_get_product' ) ) {
				global $product;
				if ( $product && is_a( $product, 'WC_Product' ) ) {
					return (int) $product->get_id();
				}
			}
			$id = get_the_ID();
			if ( $id && 'product' === get_post_type( $id ) ) {
				return (int) $id;
			}
			return 0;
		}

		return absint( $raw );
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$is_edit  = ElementorPlugin::$instance->editor->is_edit_mode();
		if ( ! $is_edit && isset( ElementorPlugin::$instance->preview ) && method_exists( ElementorPlugin::$instance->preview, 'is_preview_mode' ) ) {
			$is_edit = ElementorPlugin::$instance->preview->is_preview_mode();
		}

		$raw    = isset( $settings['product_id'] ) ? (string) $settings['product_id'] : '';
		$is_all = ( 'all' === $raw );
		$is_cat = ( 0 === strpos( $raw, 'cat_' ) );
		$blocks = $this->get_render_blocks( $settings );

		if ( empty( $blocks ) && $is_edit && ! $is_all && ! $is_cat ) {
			$blocks[] = array(
				'id'       => 0,
				'services' => Helpers::services_payload( Helpers::demo_services() ),
				'label'    => '',
			);
		}

		if ( empty( $blocks ) ) {
			if ( $is_edit ) {
				echo '<div class="wifl-empty">';
				if ( $is_all ) {
					echo esc_html__( 'No products have Instagram Follower packages yet.', 'woo-instagram-follower' );
				} elseif ( $is_cat ) {
					echo esc_html__( 'No products in this category have Instagram Follower packages yet.', 'woo-instagram-follower' );
				} else {
					echo esc_html__( 'Select a WooCommerce category, or choose All categories.', 'woo-instagram-follower' );
				}
				echo '</div>';
			}
			return;
		}

		list( $product_id, $services ) = $this->flatten_product_cards( $blocks );
		if ( empty( $services ) ) {
			return;
		}

		echo '<div class="wifl-stack">';
		Frontend::render( $product_id, $settings, $services );
		echo '</div>';
	}
}
