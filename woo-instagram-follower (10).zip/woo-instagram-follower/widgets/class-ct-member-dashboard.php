<?php
/**
 * Elementor widget: CT member dashboard.
 *
 * @package WIFL
 */

namespace WIFL\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Plugin as ElementorPlugin;
use Elementor\Widget_Base;
use WIFL\Member\Dashboard;
use WIFL\Member\Member;
use WIFL\Member\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CT_Member_Dashboard extends Widget_Base {

	public function get_name() {
		return 'ct-member-dashboard';
	}

	public function get_title() {
		return esc_html__( 'CT member dashboard', 'woo-instagram-follower' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return array( 'basic' );
	}

	public function get_keywords() {
		return array( 'dashboard', 'account', 'member', 'orders', 'profile', 'ct' );
	}

	public function get_style_depends() {
		return array( 'wifl-member' );
	}

	public function get_script_depends() {
		return array( 'wifl-member' );
	}

	public function has_widget_inner_wrapper(): bool {
		return ! ElementorPlugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function get_html_wrapper_class() {
		return 'elementor-widget-ct-member-dashboard';
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Dashboard', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'dashboard_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Custom member dashboard with sidebar, orders, activity, and account panels. Set this page URL under Membership → Settings → Member dashboard URL.', 'woo-instagram-follower' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Dashboard', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Title typography', 'woo-instagram-follower' ),
				'selector' => '{{WRAPPER}} .wifl-profile__title',
			)
		);

		$this->add_control(
			'brand_color',
			array(
				'label'     => esc_html__( 'Brand color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => Settings::get()['brand_color'],
				'selectors' => array(
					'{{WRAPPER}} .wifl-profile' => '--wifl-member-brand: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		Member::enqueue_assets();

		if ( is_user_logged_in() ) {
			echo Dashboard::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		if ( Member::is_elementor_preview() ) {
			echo Dashboard::render( true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
