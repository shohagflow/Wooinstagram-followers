<?php
/**
 * Elementor widget: CT cart menu — header/icon trigger for the floating Your Cart drawer.
 *
 * @package WIFL
 */

namespace WIFL\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Plugin as ElementorPlugin;
use Elementor\Widget_Base;
use WIFL\Float_Cart;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CT_Cart_Menu extends Widget_Base {

	public function get_name() {
		return 'ct-cart-menu';
	}

	public function get_title() {
		return esc_html__( 'CT cart menu', 'woo-instagram-follower' );
	}

	public function get_icon() {
		return 'eicon-cart';
	}

	public function get_categories() {
		return array( 'basic' );
	}

	public function get_keywords() {
		return array( 'cart', 'menu', 'woocommerce', 'icon', 'header', 'ct', 'view cart' );
	}

	public function get_style_depends() {
		return array( 'wifl-cart-menu', 'wifl-float-cart' );
	}

	public function get_script_depends() {
		return array( 'wifl-float-cart', 'wifl-cart-menu' );
	}

	public function has_widget_inner_wrapper(): bool {
		return ! ElementorPlugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function get_html_wrapper_class() {
		return 'elementor-widget-ct-cart-menu';
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Cart menu', 'woo-instagram-follower' ),
			)
		);

		$this->add_control(
			'icons_heading',
			array(
				'label' => esc_html__( 'Icons', 'woo-instagram-follower' ),
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'show_library_icon',
			array(
				'label'        => esc_html__( 'Icon library', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'menu_icon',
			array(
				'label'            => esc_html__( 'Select icon', 'woo-instagram-follower' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => array(
					'value'   => 'fas fa-shopping-cart',
					'library' => 'fa-solid',
				),
				'skin'             => 'inline',
				'label_block'      => false,
				'condition'        => array(
					'show_library_icon' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_custom_svg',
			array(
				'label'        => esc_html__( 'Custom SVG', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'no',
			)
		);

		$this->add_control(
			'custom_svg',
			array(
				'label'       => esc_html__( 'Upload SVG', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => array( 'svg' ),
				'description' => esc_html__( 'Shows next to the icon library icon. You can use both together.', 'woo-instagram-follower' ),
				'condition'   => array(
					'show_custom_svg' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'icons_gap',
			array(
				'label'      => esc_html__( 'Gap between icons', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 24,
					),
				),
				'default'    => array(
					'size' => 6,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu__icons' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'show_badge',
			array(
				'label'        => esc_html__( 'Cart count badge', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'Hide', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'hide_badge_zero',
			array(
				'label'        => esc_html__( 'Hide badge when empty', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'woo-instagram-follower' ),
				'label_off'    => esc_html__( 'No', 'woo-instagram-follower' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => array(
					'show_badge' => 'yes',
				),
			)
		);

		$this->add_control(
			'badge_position',
			array(
				'label'        => esc_html__( 'Badge position', 'woo-instagram-follower' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'top-right',
				'prefix_class' => 'wifl-cart-menu--badge-',
				'options'      => array(
					'top-right'    => esc_html__( 'Top right', 'woo-instagram-follower' ),
					'top-left'     => esc_html__( 'Top left', 'woo-instagram-follower' ),
					'bottom-right' => esc_html__( 'Bottom right', 'woo-instagram-follower' ),
					'bottom-left'  => esc_html__( 'Bottom left', 'woo-instagram-follower' ),
					'inline'       => esc_html__( 'Inline (beside icon)', 'woo-instagram-follower' ),
				),
				'condition'    => array(
					'show_badge' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'badge_offset',
			array(
				'label'      => esc_html__( 'Badge offset', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'default'    => array(
					'top'    => '2',
					'right'  => '2',
					'bottom' => '',
					'left'   => '',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu__badge' => 'top: {{TOP}}{{UNIT}}; right: {{RIGHT}}{{UNIT}}; bottom: {{BOTTOM}}{{UNIT}}; left: {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'show_badge'      => 'yes',
					'badge_position!' => 'inline',
				),
			)
		);

		$this->add_responsive_control(
			'badge_inline_gap',
			array(
				'label'      => esc_html__( 'Gap from icon', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 24,
					),
				),
				'default'    => array(
					'size' => 6,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu' => 'gap: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'show_badge'     => 'yes',
					'badge_position' => 'inline',
				),
			)
		);

		$this->add_control(
			'aria_label',
			array(
				'label'       => esc_html__( 'Accessibility label', 'woo-instagram-follower' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Open cart', 'woo-instagram-follower' ),
				'label_block' => true,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Button', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'     => esc_html__( 'Alignment', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'woo-instagram-follower' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart-menu-wrap' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Icon size', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 14,
						'max' => 48,
					),
				),
				'default'    => array(
					'size' => 22,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu__icon' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wifl-cart-menu__icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wifl-cart-menu__icon img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart-menu' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'btn_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart-menu' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'btn_border',
				'selector' => '{{WRAPPER}} .wifl-cart-menu',
			)
		);

		$this->add_responsive_control(
			'btn_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'btn_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'btn_shadow',
				'selector' => '{{WRAPPER}} .wifl-cart-menu',
			)
		);

		$this->add_control(
			'hover_heading',
			array(
				'label'     => esc_html__( 'Hover', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'icon_color_hover',
			array(
				'label'     => esc_html__( 'Icon color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart-menu:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .wifl-cart-menu:focus-visible' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'btn_bg_hover',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart-menu:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .wifl-cart-menu:focus-visible' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'hover_animation',
			array(
				'label'   => esc_html__( 'Hover animation', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'lift',
				'options' => array(
					'none'   => esc_html__( 'None', 'woo-instagram-follower' ),
					'lift'   => esc_html__( 'Lift up', 'woo-instagram-follower' ),
					'scale'  => esc_html__( 'Scale', 'woo-instagram-follower' ),
					'pulse'  => esc_html__( 'Pulse', 'woo-instagram-follower' ),
					'bounce' => esc_html__( 'Bounce', 'woo-instagram-follower' ),
					'rotate' => esc_html__( 'Rotate', 'woo-instagram-follower' ),
				),
			)
		);

		$this->add_control(
			'hover_duration',
			array(
				'label'      => esc_html__( 'Animation speed (ms)', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 100,
						'max' => 800,
					),
				),
				'default'    => array(
					'size' => 220,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu' => 'transition-duration: {{SIZE}}ms;',
				),
				'condition'  => array(
					'hover_animation!' => 'none',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => 'btn_shadow_hover',
				'label'     => esc_html__( 'Hover shadow', 'woo-instagram-follower' ),
				'selector'  => '{{WRAPPER}} .wifl-cart-menu:hover, {{WRAPPER}} .wifl-cart-menu:focus-visible',
				'condition' => array(
					'hover_animation!' => 'none',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon_animation',
			array(
				'label' => esc_html__( 'Icon animation', 'woo-instagram-follower' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'icon_animation',
			array(
				'label'   => esc_html__( 'Animation', 'woo-instagram-follower' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => array(
					'none'   => esc_html__( 'None', 'woo-instagram-follower' ),
					'swing'  => esc_html__( 'Swing', 'woo-instagram-follower' ),
					'shake'  => esc_html__( 'Shake', 'woo-instagram-follower' ),
					'bounce' => esc_html__( 'Bounce', 'woo-instagram-follower' ),
					'pulse'  => esc_html__( 'Pulse', 'woo-instagram-follower' ),
					'spin'   => esc_html__( 'Spin', 'woo-instagram-follower' ),
					'float'  => esc_html__( 'Float', 'woo-instagram-follower' ),
					'wiggle' => esc_html__( 'Wiggle', 'woo-instagram-follower' ),
				),
			)
		);

		$this->add_control(
			'icon_animation_trigger',
			array(
				'label'     => esc_html__( 'Play', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'always',
				'options'   => array(
					'always' => esc_html__( 'Always (loop)', 'woo-instagram-follower' ),
					'hover'  => esc_html__( 'On hover', 'woo-instagram-follower' ),
				),
				'condition' => array(
					'icon_animation!' => 'none',
				),
			)
		);

		$this->add_control(
			'icon_animation_duration',
			array(
				'label'      => esc_html__( 'Duration (ms)', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 400,
						'max' => 4000,
					),
				),
				'default'    => array(
					'size' => 1200,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu__icons' => 'animation-duration: {{SIZE}}ms;',
				),
				'condition'  => array(
					'icon_animation!' => 'none',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_badge_style',
			array(
				'label'     => esc_html__( 'Count badge', 'woo-instagram-follower' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_badge' => 'yes',
				),
			)
		);

		$this->add_control(
			'badge_bg',
			array(
				'label'     => esc_html__( 'Background', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#e11d48',
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart-menu__badge' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'badge_color',
			array(
				'label'     => esc_html__( 'Text color', 'woo-instagram-follower' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .wifl-cart-menu__badge' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'badge_typo',
				'selector' => '{{WRAPPER}} .wifl-cart-menu__badge',
			)
		);

		$this->add_responsive_control(
			'badge_size',
			array(
				'label'      => esc_html__( 'Min size', 'woo-instagram-follower' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 14,
						'max' => 32,
					),
				),
				'default'    => array(
					'size' => 18,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .wifl-cart-menu__badge' => 'min-width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * @param array $settings Widget settings.
	 * @return bool
	 */
	protected function has_custom_svg( $settings ) {
		return ( 'yes' === ( $settings['show_custom_svg'] ?? 'no' ) ) && ! empty( $settings['custom_svg']['url'] );
	}

	/**
	 * @param array $settings Widget settings.
	 * @return bool
	 */
	protected function has_library_icon( $settings ) {
		return ( 'yes' === ( $settings['show_library_icon'] ?? 'yes' ) ) && ! empty( $settings['menu_icon']['value'] );
	}

	/**
	 * @param array $settings Widget settings.
	 * @return string
	 */
	protected function hover_class( $settings ) {
		$anim = isset( $settings['hover_animation'] ) ? $settings['hover_animation'] : 'lift';
		if ( 'none' === $anim ) {
			return '';
		}
		return ' wifl-cart-menu--hover-' . sanitize_html_class( $anim );
	}

	/**
	 * @param array $settings Widget settings.
	 * @return string
	 */
	protected function icon_animation_class( $settings ) {
		$anim = isset( $settings['icon_animation'] ) ? $settings['icon_animation'] : 'none';
		if ( 'none' === $anim || empty( $anim ) ) {
			return '';
		}

		$trigger = isset( $settings['icon_animation_trigger'] ) ? $settings['icon_animation_trigger'] : 'always';
		$classes = array(
			'wifl-cart-menu--icon-' . sanitize_html_class( $anim ),
			'wifl-cart-menu--icon-play-' . sanitize_html_class( $trigger ),
		);

		return ' ' . implode( ' ', $classes );
	}

	protected function render_icon_library( $settings ) {
		if ( $this->has_library_icon( $settings ) ) {
			Icons_Manager::render_icon( $settings['menu_icon'], array( 'aria-hidden' => 'true' ) );
			return;
		}
		if ( 'yes' === ( $settings['show_library_icon'] ?? 'yes' ) ) {
			Icons_Manager::render_icon(
				array(
					'value'   => 'fas fa-shopping-cart',
					'library' => 'fa-solid',
				),
				array( 'aria-hidden' => 'true' )
			);
		}
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		Float_Cart::instance()->ensure_frontend_assets();

		$count = 0;
		if ( function_exists( 'WC' ) && WC()->cart ) {
			$count = (int) WC()->cart->get_cart_contents_count();
		}

		$show_badge   = ( 'yes' === $settings['show_badge'] );
		$hide_zero    = ( 'yes' === $settings['hide_badge_zero'] );
		$badge_hidden = ( ! $show_badge || ( $hide_zero && $count < 1 ) );
		$aria         = ! empty( $settings['aria_label'] ) ? $settings['aria_label'] : __( 'Open cart', 'woo-instagram-follower' );
		$show_lib     = ( 'yes' === ( $settings['show_library_icon'] ?? 'yes' ) );
		$show_svg     = $this->has_custom_svg( $settings );
		?>
		<div class="wifl-cart-menu-wrap">
			<button
				type="button"
				class="wifl-cart-menu wifl-js-cart-menu-open<?php echo esc_attr( $this->hover_class( $settings ) . $this->icon_animation_class( $settings ) ); ?>"
				data-hide-zero="<?php echo $hide_zero ? '1' : '0'; ?>"
				aria-label="<?php echo esc_attr( $aria ); ?>"
			>
				<span class="wifl-cart-menu__icons" aria-hidden="true">
					<?php if ( $show_lib ) : ?>
						<span class="wifl-cart-menu__icon wifl-cart-menu__icon--library">
							<?php $this->render_icon_library( $settings ); ?>
						</span>
					<?php endif; ?>
					<?php if ( $show_svg ) : ?>
						<span class="wifl-cart-menu__icon wifl-cart-menu__icon--svg">
							<img src="<?php echo esc_url( $settings['custom_svg']['url'] ); ?>" alt="" />
						</span>
					<?php endif; ?>
				</span>
				<?php if ( $show_badge ) : ?>
					<span class="wifl-cart-menu__badge"<?php echo $badge_hidden ? ' hidden' : ''; ?>><?php echo esc_html( (string) max( 0, $count ) ); ?></span>
				<?php endif; ?>
			</button>
		</div>
		<?php
	}
}
