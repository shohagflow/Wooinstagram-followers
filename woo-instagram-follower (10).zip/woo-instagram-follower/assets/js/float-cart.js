(function () {
	'use strict';

	function qs(sel, root) {
		return (root || document).querySelector(sel);
	}

	function esc(str) {
		return String(str || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function post(action, extra) {
		var cfg = window.wiflFloat || {};
		var body = new URLSearchParams();
		body.set('action', action);
		body.set('nonce', cfg.nonce || '');
		if (extra) {
			Object.keys(extra).forEach(function (key) {
				body.set(key, extra[key]);
			});
		}
		return fetch(cfg.ajaxUrl || '/wp-admin/admin-ajax.php', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (res) {
			return res.json();
		});
	}

	function platIcon(name) {
		var key = String(name || 'instagram');
		if (key === 'tiktok') {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.76 0 2.89 2.89 0 012.88-2.88c.28 0 .54.04.79.1v-3.5a6.26 6.26 0 00-.79-.05 6.34 6.34 0 106.34 6.34V8.77a8.23 8.23 0 004.76 1.52V6.9a4.85 4.85 0 01-1-.21z"/></svg>';
		}
		if (key === 'youtube') {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M23 12.2s0-3.2-.4-4.6c-.2-.9-.9-1.6-1.8-1.8C18.9 5.4 12 5.4 12 5.4s-6.9 0-8.8.4c-.9.2-1.6.9-1.8 1.8C1 9 1 12.2 1 12.2s0 3.2.4 4.6c.2.9.9 1.6 1.8 1.8 1.9.4 8.8.4 8.8.4s6.9 0 8.8-.4c.9-.2 1.6-.9 1.8-1.8.4-1.4.4-4.6.4-4.6zM9.8 15.6V8.8l6.4 3.4-6.4 3.4z"/></svg>';
		}
		if (key === 'facebook') {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M14 9h3V6h-3c-2.2 0-4 1.8-4 4v2H7v3h3v7h3v-7h3l1-3h-4v-2c0-.6.4-1 1-1z"/></svg>';
		}
		if (key === 'twitter') {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2H21.5l-7.5 8.57L22.5 22h-6.56l-5.14-6.71L5.2 22H1.94l8.03-9.17L1.5 2h6.72l4.64 6.18L18.244 2zm-1.15 18h1.81L7.03 3.94H5.09L17.094 20z"/></svg>';
		}
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M7 3h10a4 4 0 014 4v10a4 4 0 01-4 4H7a4 4 0 01-4-4V7a4 4 0 014-4zm5 4.5A4.5 4.5 0 1016.5 12 4.5 4.5 0 0012 7.5zm0 7.4A2.9 2.9 0 1114.9 12 2.9 2.9 0 0112 14.9zM17.4 6.2a1.1 1.1 0 11-1.1 1.1 1.1 1.1 0 011.1-1.1z"/></svg>';
	}

	function iconKind(name) {
		var n = String(name || '').toLowerCase();
		if (n.indexOf('like') !== -1) {
			return 'likes';
		}
		if (n.indexOf('view') !== -1) {
			return 'views';
		}
		if (n.indexOf('comment') !== -1) {
			return 'comments';
		}
		if (n.indexOf('follow') !== -1) {
			return 'followers';
		}
		return 'likes';
	}

	function formatBadge(pkg) {
		var raw = String(pkg || '').replace(/,/g, '').trim();
		if (/^\d+$/.test(raw)) {
			var n = parseInt(raw, 10);
			if (n >= 1000) {
				var k = n / 1000;
				return (k % 1 === 0 ? String(k) : String(Math.round(k * 10) / 10)) + 'K';
			}
			return String(n);
		}
		return raw ? raw.toUpperCase() : '';
	}

	function serviceGlyph(kind) {
		if (kind === 'followers') {
			return '<svg class="wifl-line__glyph" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12a4.2 4.2 0 100-8.4A4.2 4.2 0 0012 12zm0 2.1c-3.6 0-10.5 1.8-10.5 5.4V22h21v-2.5c0-3.6-6.9-5.4-10.5-5.4z"/></svg>';
		}
		if (kind === 'views') {
			return '<svg class="wifl-line__glyph" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
		}
		if (kind === 'comments') {
			return '<svg class="wifl-line__glyph" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a8 8 0 01-8 8H7l-4 3V12a8 8 0 018-8h2a8 8 0 018 8z"/></svg>';
		}
		return '<svg class="wifl-line__glyph" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-7-4.6-9.5-8.8C.8 9.4 2.2 5.6 5.8 4.6c2-.6 4.1.2 6.2 2.4 2.1-2.2 4.2-3 6.2-2.4 3.6 1 5 4.8 3.3 7.6C19 16.4 12 21 12 21z"/></svg>';
	}

	function accountAvatar() {
		return (
			'<span class="wifl-account__avatar" aria-hidden="true">' +
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">' +
			'<path fill="#22c55e" d="M22 56c-14-9-18-24-10-38 5 11 14 17 22 19C20 33 14 22 18 10 6 21 6 42 22 56z"/>' +
			'<path fill="#16a34a" d="M42 56c14-9 18-24 10-38-5 11-14 17-22 19 14-4 20-15 16-27 12 11 12 32-4 46z"/>' +
			'<ellipse fill="#4ade80" cx="14" cy="18" rx="5" ry="8" transform="rotate(-32 14 18)"/>' +
			'<ellipse fill="#22c55e" cx="11" cy="28" rx="4.6" ry="7.2" transform="rotate(-18 11 28)"/>' +
			'<ellipse fill="#16a34a" cx="13" cy="38" rx="4.4" ry="6.8" transform="rotate(-6 13 38)"/>' +
			'<ellipse fill="#15803d" cx="17" cy="47" rx="4" ry="6" transform="rotate(10 17 47)"/>' +
			'<ellipse fill="#4ade80" cx="50" cy="18" rx="5" ry="8" transform="rotate(32 50 18)"/>' +
			'<ellipse fill="#22c55e" cx="53" cy="28" rx="4.6" ry="7.2" transform="rotate(18 53 28)"/>' +
			'<ellipse fill="#16a34a" cx="51" cy="38" rx="4.4" ry="6.8" transform="rotate(6 51 38)"/>' +
			'<ellipse fill="#15803d" cx="47" cy="47" rx="4" ry="6" transform="rotate(-10 47 47)"/>' +
			'<circle cx="32" cy="28" r="13.5" fill="#eceff1"/>' +
			'<path fill="#9aa0a6" d="M32 30.8c3.3 0 6-2.7 6-6s-2.7-6-6-6-6 2.7-6 6 2.7 6 6 6zm0 2.4c-4 0-12 2-12 6v2.6h24V39.2c0-4-8-6-12-6z"/>' +
			'</svg></span>'
		);
	}

	function thumb(item) {
		var kind = item.icon || iconKind(item.name);
		var badge = item.badge || formatBadge(item.package);
		var platform = String(item.platform || 'instagram');
		var html =
			'<span class="wifl-line__thumb wifl-line__thumb--' +
			esc(platform) +
			'" data-platform="' +
			esc(platform) +
			'" aria-hidden="true">' +
			serviceGlyph(kind);
		if (badge) {
			html +=
				'<span class="wifl-line__chip"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>' +
				esc(badge) +
				'</span>';
		}
		return html + '</span>';
	}

	function setCount(root, count) {
		count = parseInt(count, 10) || 0;
		root.setAttribute('data-count', String(count));
		if (!root.classList.contains('wifl-float--drawer-only')) {
			root.removeAttribute('hidden');
			root.hidden = false;
		}
		root.querySelectorAll('.wifl-dock__badge').forEach(function (el) {
			el.textContent = String(count);
		});
		var sync = root.querySelector('.wifl-float-sync');
		if (sync) {
			sync.setAttribute('data-count', String(count));
		}
	}

	function updateDockPlatforms(root, data) {
		if (!data) {
			return;
		}
		if (typeof data.dockIconsHtml === 'string') {
			var mini = root.querySelector('.wifl-dock__plats-mini');
			if (mini) {
				var wrap = document.createElement('div');
				wrap.innerHTML = data.dockIconsHtml;
				var next = wrap.firstElementChild;
				if (next) {
					mini.replaceWith(next);
				}
			}
		}
		if (typeof data.platformsHtml === 'string') {
			var plats = root.querySelector('.wifl-dock__plats');
			if (plats) {
				var box = document.createElement('div');
				box.innerHTML = data.platformsHtml;
				var nextPlats = box.firstElementChild;
				if (nextPlats) {
					plats.replaceWith(nextPlats);
				}
			}
		}
	}

	function countFromDom(root) {
		var sync = root.querySelector('.wifl-float-sync');
		var fromSync = sync ? parseInt(sync.getAttribute('data-count'), 10) : 0;
		var badge = root.querySelector('.wifl-dock__badge');
		var fromBadge = badge ? parseInt(badge.textContent, 10) : 0;
		var fromAttr = parseInt(root.getAttribute('data-count'), 10) || 0;
		return Math.max(fromSync || 0, fromBadge || 0, fromAttr || 0);
	}

	function mountToBody(root) {
		if (root.parentNode !== document.body) {
			document.body.appendChild(root);
		}
	}

	function refreshFromServer(root) {
		return post('wifl_float_cart').then(function (json) {
			if (json && json.success) {
				applyCart(root, json.data || {});
			}
		});
	}

	function renderDrawer(root, data) {
		var body = qs('#wifl-drawer-body', root);
		var foot = qs('#wifl-drawer-foot', root);
		if (!body || !foot) {
			return;
		}

		var items = data.items || [];
		var html = '';
		if (!items.length) {
			body.innerHTML = '<p class="wifl-empty-cart">Your cart is empty.</p>';
			foot.innerHTML = '';
			return;
		}

		html += '<div class="wifl-card">';
		html += '<div class="wifl-account">' + accountAvatar() + '<div class="wifl-account__meta">';
		html +=
			'<div class="wifl-account__name">Your Account <span class="wifl-account__ig">' +
			platIcon('instagram') +
			'</span></div>';
		if (data.savedHtml) {
			html +=
				'<span class="wifl-account__saved"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.4 11.6l-9-9A1.5 1.5 0 0011.4 2H4.5A1.5 1.5 0 003 3.5v6.9c0 .4.2.8.4 1.1l9 9a1.5 1.5 0 002.1 0l6.9-6.9a1.5 1.5 0 000-2zM7.1 8.4A1.6 1.6 0 117.1 5a1.6 1.6 0 010 3.4z"/></svg>' +
				data.savedHtml +
				' saved!</span>';
		}
		html +=
			'</div><span class="wifl-account__count">' +
			items.length +
			(items.length === 1 ? ' item' : ' items') +
			'</span></div>';

		items.forEach(function (item) {
			html += '<div class="wifl-line" data-platform="' + esc(item.platform || 'instagram') + '">';
			html += thumb(item);
			html += '<div><div class="wifl-line__name">' + esc(item.name) + '</div><div class="wifl-line__price">' + (item.saleHtml || '');
			if (item.regularHtml) {
				html += '<span class="wifl-line__regular">' + item.regularHtml + '</span>';
			}
			html += '</div></div>';
			html += '<div class="wifl-line__ctrl">';
			html += '<button type="button" class="wifl-js-remove" data-key="' + esc(item.key) + '" aria-label="Remove">✕</button>';
			html += '<span>' + esc(item.package) + '</span>';
			html += '<button type="button" class="wifl-line__plus" aria-hidden="true">+</button>';
			html += '</div></div>';
		});
		html += '</div>';

		html += '<h3 class="wifl-section-title">Add more items</h3>';
		html += '<div class="wifl-tabs">';
		(data.tabs || []).forEach(function (tab, i) {
			html += '<button type="button" class="wifl-tab' + (i === 0 ? ' is-active' : '') + '" data-tab="' + esc(tab.id) + '">' + esc(tab.label) + '</button>';
		});
		html += '</div><div class="wifl-card" data-suggest>';

		(data.suggestions || []).forEach(function (item) {
			html += '<div class="wifl-line" data-platform="' + esc(item.platform) + '">';
			html += thumb(item);
			html += '<div><div class="wifl-line__name">' + esc(item.name) + '</div>';
			html += '<div class="wifl-line__price">' + (item.saleHtml || '');
			if (item.regularHtml) {
				html += '<span class="wifl-line__regular">' + item.regularHtml + '</span>';
			}
			html += '</div></div>';
			html += '<button type="button" class="wifl-suggest__add" data-id="' + esc(item.id) + '">+ Add</button>';
			html += '</div>';
		});
		html += '</div>';

		body.innerHTML = html;

		var checkout =
			data.checkoutUrl ||
			(window.wiflFloat && window.wiflFloat.checkoutUrl) ||
			'/cart/';
		foot.innerHTML =
			'<div><div class="wifl-total-label">Your Total</div><div class="wifl-total-row"><span class="wifl-total-sale">' +
			(data.saleHtml || '') +
			'</span>' +
			(data.regularHtml ? '<span class="wifl-total-regular">' + data.regularHtml + '</span>' : '') +
			'</div></div><button type="button" class="wifl-checkout wifl-js-go-cart" data-url="' +
			esc(checkout) +
			'">Checkout</button>';
	}

	function cacheCart(data) {
		if (!window.wiflFloat) {
			window.wiflFloat = {};
		}
		window.wiflFloat.cart = data || {};
	}

	function applyCart(root, data) {
		cacheCart(data);
		setCount(root, data && data.count);
		updateDockPlatforms(root, data || {});
		var drawer = qs('#wifl-drawer', root);
		if (drawer && !drawer.hidden) {
			renderDrawer(root, data || {});
		}
	}

	function openDrawer(root) {
		var drawer = qs('#wifl-drawer', root);
		if (!drawer) {
			return;
		}
		drawer.hidden = false;
		document.documentElement.style.overflow = 'hidden';
		if (window.wiflFloat && window.wiflFloat.cart) {
			renderDrawer(root, window.wiflFloat.cart);
		}
		post('wifl_float_cart').then(function (json) {
			if (json && json.success) {
				applyCart(root, json.data || {});
			}
		});
	}

	function closeDrawer(root) {
		var drawer = qs('#wifl-drawer', root);
		if (drawer) {
			drawer.hidden = true;
		}
		document.documentElement.style.overflow = '';
	}

	function bind(root) {
		if (!root || root.getAttribute('data-ready') === '1') {
			return;
		}
		root.setAttribute('data-ready', '1');

		root.addEventListener('click', function (e) {
			if (e.target.closest('.wifl-js-open-cart')) {
				e.preventDefault();
				openDrawer(root);
				return;
			}
			if (e.target.closest('.wifl-js-close-cart')) {
				e.preventDefault();
				closeDrawer(root);
				return;
			}
			var goCart = e.target.closest('.wifl-js-go-cart, a.wifl-checkout');
			if (goCart) {
				e.preventDefault();
				e.stopPropagation();
				var url =
					goCart.getAttribute('data-url') ||
					goCart.getAttribute('href') ||
					(window.wiflFloat && window.wiflFloat.checkoutUrl) ||
					'';
				url = String(url || '').replace(/&amp;/g, '&').trim();
				// Guard: never treat bare homepage as the cart page.
				try {
					var parsed = new URL(url, window.location.origin);
					var path = (parsed.pathname || '/').replace(/\/+$/, '') || '/';
					if (!url || path === '' || path === '/') {
						url = (window.wiflFloat && window.wiflFloat.checkoutUrl) || (window.location.origin + '/cart/');
						parsed = new URL(url, window.location.origin);
						path = (parsed.pathname || '/').replace(/\/+$/, '') || '/';
						if (path === '' || path === '/') {
							url = window.location.origin + '/cart/';
						}
					}
				} catch (err) {
					url = window.location.origin + '/cart/';
				}
				window.location.assign(url);
				return;
			}
			var remove = e.target.closest('.wifl-js-remove');
			if (remove) {
				e.preventDefault();
				post('wifl_float_remove', { key: remove.getAttribute('data-key') || '' }).then(function (json) {
					if (json && json.success) {
						applyCart(root, json.data || {});
						if (window.jQuery) {
							window.jQuery(document.body).trigger('wc_fragment_refresh');
						}
					}
				});
				return;
			}
			var add = e.target.closest('.wifl-suggest__add');
			if (add) {
				e.preventDefault();
				add.disabled = true;
				post('wifl_float_add', { product_id: add.getAttribute('data-id') || '0' })
					.then(function (json) {
						if (json && json.success) {
							applyCart(root, json.data || {});
							if (window.jQuery) {
								window.jQuery(document.body).trigger('added_to_cart', [{}, '', null]);
								window.jQuery(document.body).trigger('wc_fragment_refresh');
							}
						}
					})
					.finally(function () {
						add.disabled = false;
					});
				return;
			}
			var tab = e.target.closest('.wifl-tab');
			if (tab) {
				e.preventDefault();
				root.querySelectorAll('.wifl-tab').forEach(function (el) {
					el.classList.toggle('is-active', el === tab);
				});
				var id = tab.getAttribute('data-tab');
				root.querySelectorAll('[data-suggest] .wifl-line').forEach(function (row) {
					row.hidden = id !== 'all' && row.getAttribute('data-platform') !== id;
				});
			}
		});

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') {
				closeDrawer(root);
			}
		});
	}

	function init() {
		var root = qs('.wifl-float');
		if (!root) {
			return;
		}
		mountToBody(root);
		bind(root);
		setCount(root, countFromDom(root));
		refreshFromServer(root);
	}

	function onCartChanged() {
		var root = qs('.wifl-float');
		if (!root) {
			return;
		}
		setCount(root, countFromDom(root));
		refreshFromServer(root);
	}

	function hookJquery() {
		if (!window.jQuery || !window.jQuery.fn || hookJquery.done) {
			return !!hookJquery.done;
		}
		hookJquery.done = true;
		window.jQuery(document.body).on(
			'added_to_cart removed_from_cart wc_fragments_refreshed wc_fragments_loaded',
			onCartChanged
		);
		return true;
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	if (!hookJquery()) {
		var tries = 0;
		var timer = setInterval(function () {
			tries += 1;
			if (hookJquery() || tries > 40) {
				clearInterval(timer);
			}
		}, 250);
	}

	window.wiflFloatOpenCart = function () {
		var root = qs('.wifl-float');
		if (root) {
			openDrawer(root);
		}
	};
})();
