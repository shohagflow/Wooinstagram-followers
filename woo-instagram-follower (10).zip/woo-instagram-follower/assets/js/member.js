(function () {
	'use strict';

	var HIDE_MS = 380;
	var SHOW_MS = 420;

	function setPanel(root, panel) {
		if (!root || !panel) {
			return;
		}
		root.setAttribute('data-active-panel', panel);
		root.querySelectorAll('.wifl-member-panel').forEach(function (el) {
			el.hidden = el.getAttribute('data-panel') !== panel;
		});
	}

	function prefersReducedMotion() {
		return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	}

	function setPromoViewportHeight(slider) {
		var viewport = slider.querySelector('.wifl-member-promo__viewport');
		var active = slider.querySelector('.wifl-member-promo__slide.is-active');
		if (!viewport || !active) {
			return;
		}
		viewport.style.height = active.offsetHeight + 'px';
	}

	function initPromoSlider(slider) {
		if (!slider || slider.getAttribute('data-wifl-promo-init') === '1') {
			return;
		}

		var slides = slider.querySelectorAll('.wifl-member-promo__slide');
		if (!slides.length) {
			return;
		}

		var viewport = slider.querySelector('.wifl-member-promo__viewport');
		if (!viewport) {
			return;
		}

		slider.setAttribute('data-wifl-promo-init', '1');

		if (slides.length === 1) {
			setPromoViewportHeight(slider);
			return;
		}

		var dots = slider.querySelectorAll('.wifl-member-promo__dot');
		var current = 0;
		var timer = null;
		var animating = false;
		var autoplay = slider.getAttribute('data-autoplay') === 'yes';
		var speed = parseInt(slider.getAttribute('data-autoplay-speed') || '2000', 10);

		function updateDots(index) {
			dots.forEach(function (dot, i) {
				var active = i === index;
				dot.classList.toggle('is-active', active);
				dot.setAttribute('aria-selected', active ? 'true' : 'false');
			});
		}

		function stopAutoplay() {
			if (timer) {
				window.clearTimeout(timer);
				timer = null;
			}
		}

		function scheduleAutoplay() {
			stopAutoplay();
			if (!autoplay || prefersReducedMotion()) {
				return;
			}
			timer = window.setTimeout(function () {
				goTo((current + 1) % slides.length);
			}, Math.max(1500, speed));
		}

		function swapSlide(prev, next) {
			slides[prev].classList.remove('is-active');
			slides[next].classList.add('is-active');
			current = next;
			updateDots(current);
			setPromoViewportHeight(slider);
		}

		function revealViewport(done) {
			viewport.classList.remove('is-hiding');
			viewport.classList.add('is-revealing');
			void viewport.offsetWidth;
			viewport.classList.add('is-visible');

			window.setTimeout(function () {
				viewport.classList.remove('is-revealing', 'is-visible');
				if (done) {
					done();
				}
			}, SHOW_MS);
		}

		function goTo(index) {
			if (animating || index === current || index < 0 || index >= slides.length) {
				return;
			}

			var prev = current;
			animating = true;
			stopAutoplay();

			if (prefersReducedMotion()) {
				swapSlide(prev, index);
				animating = false;
				scheduleAutoplay();
				return;
			}

			viewport.classList.add('is-hiding');

			window.setTimeout(function () {
				swapSlide(prev, index);
				revealViewport(function () {
					animating = false;
					scheduleAutoplay();
				});
			}, HIDE_MS);
		}

		dots.forEach(function (dot) {
			dot.addEventListener('click', function () {
				var index = parseInt(dot.getAttribute('data-index') || '0', 10);
				goTo(index);
			});
		});

		slider.addEventListener('mouseenter', stopAutoplay);
		slider.addEventListener('mouseleave', scheduleAutoplay);
		slider.addEventListener('focusin', stopAutoplay);
		slider.addEventListener('focusout', scheduleAutoplay);

		window.addEventListener('resize', function () {
			setPromoViewportHeight(slider);
		});

		setPromoViewportHeight(slider);
		scheduleAutoplay();
	}

	function initPromoSliders(context) {
		var root = context || document;
		root.querySelectorAll('.wifl-member-promo__slider').forEach(initPromoSlider);
	}

	document.addEventListener('click', function (e) {
		var toggle = e.target.closest('.wifl-member-field__toggle');
		if (toggle) {
			var field = toggle.closest('.wifl-member-field');
			if (!field) {
				return;
			}
			var input = field.querySelector('.wifl-member-field__input');
			if (!input) {
				return;
			}
			var show = input.type === 'password';
			input.type = show ? 'text' : 'password';
			toggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
			return;
		}

		var sw = e.target.closest('.wifl-member-switch');
		if (sw) {
			e.preventDefault();
			var formRoot = sw.closest('.wifl-member-form');
			setPanel(formRoot, sw.getAttribute('data-target'));
		}
	});

	function initProfileDashboard(root) {
		if (!root || root.getAttribute('data-wifl-profile-init') === '1') {
			return;
		}
		root.setAttribute('data-wifl-profile-init', '1');

		var navItems = root.querySelectorAll('.wifl-profile__nav-item');
		var panels = root.querySelectorAll('.wifl-profile__panel');
		var tabs = root.querySelectorAll('.wifl-profile__tab');
		var orders = root.querySelectorAll('.wifl-profile__order');
		var ordersWrap = root.querySelector('.wifl-profile__orders-wrap');
		var emptyState = root.querySelector('.wifl-profile__orders-empty');
		var searchInput = root.querySelector('.wifl-profile__search-input');
		var clearBtn = root.querySelector('[data-clear-filters]');
		var activeFilter = 'all';
		var activeView = root.getAttribute('data-active-view') || 'home';

		function setView(view) {
			activeView = view;
			root.setAttribute('data-active-view', view);
			navItems.forEach(function (item) {
				item.classList.toggle('is-active', item.getAttribute('data-view') === view);
			});
			panels.forEach(function (panel) {
				var isActive = panel.getAttribute('data-panel') === view;
				panel.classList.toggle('is-active', isActive);
				panel.hidden = !isActive;
			});
		}

		function updateOrdersVisibility() {
			if (!orders.length || !ordersWrap) {
				return;
			}

			var query = searchInput ? searchInput.value.trim().toLowerCase() : '';
			var visibleCount = 0;

			orders.forEach(function (order) {
				var group = order.getAttribute('data-status-group') || '';
				var search = order.getAttribute('data-search') || '';
				var matchesFilter = activeFilter === 'all' || group === activeFilter;
				var matchesSearch = !query || search.indexOf(query) !== -1;
				var visible = matchesFilter && matchesSearch;
				order.hidden = !visible;
				if (visible) {
					visibleCount += 1;
				}
			});

			if (emptyState) {
				var showEmpty = visibleCount === 0;
				emptyState.hidden = !showEmpty;
				emptyState.classList.toggle('is-visible', showEmpty);
			}

			var list = ordersWrap.querySelector('.wifl-profile__orders');
			if (list) {
				list.hidden = visibleCount === 0;
			}
		}

		navItems.forEach(function (item) {
			item.addEventListener('click', function () {
				setView(item.getAttribute('data-view') || 'home');
				if (window.matchMedia('(max-width: 1024px)').matches) {
					item.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
				}
			});
		});

		root.querySelectorAll('[data-view-jump]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				setView(btn.getAttribute('data-view-jump') || 'activity');
			});
		});

		var avatarInput = root.querySelector('.wifl-profile__avatar-input');
		var avatarBox = root.querySelector('[data-avatar-preview]');
		if (avatarInput && avatarBox) {
			avatarInput.addEventListener('change', function () {
				var file = avatarInput.files && avatarInput.files[0];
				if (!file) {
					return;
				}
				var url = window.URL.createObjectURL(file);
				var img = avatarBox.querySelector('.wifl-profile__avatar-img');
				if (!img) {
					img = document.createElement('img');
					img.className = 'wifl-profile__avatar-img';
					avatarBox.innerHTML = '';
					avatarBox.appendChild(img);
				}
				img.src = url;
				img.alt = file.name;
			});
		}

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				activeFilter = tab.getAttribute('data-filter') || 'all';
				tabs.forEach(function (el) {
					var active = el === tab;
					el.classList.toggle('is-active', active);
					el.setAttribute('aria-selected', active ? 'true' : 'false');
				});
				updateOrdersVisibility();
				if (window.matchMedia('(max-width: 1024px)').matches) {
					tab.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
				}
			});
		});

		if (searchInput) {
			searchInput.addEventListener('input', updateOrdersVisibility);
		}

		if (clearBtn) {
			clearBtn.addEventListener('click', function () {
				activeFilter = 'all';
				if (searchInput) {
					searchInput.value = '';
				}
				tabs.forEach(function (el) {
					var active = el.getAttribute('data-filter') === 'all';
					el.classList.toggle('is-active', active);
					el.setAttribute('aria-selected', active ? 'true' : 'false');
				});
				updateOrdersVisibility();
			});
		}

		setView(activeView);
		updateOrdersVisibility();
	}

	function initProfileDashboards(context) {
		var root = context || document;
		root.querySelectorAll('.wifl-profile').forEach(initProfileDashboard);
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('.wifl-member-form--combined').forEach(function (root) {
			var panel = root.getAttribute('data-active-panel') || 'login';
			if (window.location.hash === '#register') {
				panel = 'register';
			}
			setPanel(root, panel);
		});

		initPromoSliders(document);
		initProfileDashboards(document);
	});

	if (window.elementorFrontend && window.elementorFrontend.hooks) {
		window.elementorFrontend.hooks.addAction('frontend/element_ready/ct-member-login.default', function ($scope) {
			if ($scope && $scope[0]) {
				initPromoSliders($scope[0]);
			}
		});

		window.elementorFrontend.hooks.addAction('frontend/element_ready/ct-member-dashboard.default', function ($scope) {
			if ($scope && $scope[0]) {
				initProfileDashboards($scope[0]);
			}
		});
	}
})();
