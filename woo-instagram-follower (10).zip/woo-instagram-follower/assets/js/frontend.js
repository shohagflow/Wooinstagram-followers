(function () {
	'use strict';

	function parseData(root) {
		var node = root.querySelector('.wifl-json');
		if (!node) {
			return null;
		}
		try {
			return JSON.parse(node.textContent);
		} catch (e) {
			return null;
		}
	}

	function esc(str) {
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;');
	}

	function getActive(root) {
		var serviceBtn = root.querySelector('.wifl-service.is-active');
		var packageBtn = root.querySelector('.wifl-pkg.is-active');
		return {
			service: serviceBtn ? parseInt(serviceBtn.getAttribute('data-index'), 10) : 0,
			package: packageBtn ? parseInt(packageBtn.getAttribute('data-index'), 10) : 0
		};
	}

	function setPressed(list, activeEl) {
		list.forEach(function (el) {
			var on = el === activeEl;
			el.classList.toggle('is-active', on);
			el.setAttribute('aria-pressed', on ? 'true' : 'false');
		});
	}

	function renderPackages(root, service) {
		var grid = root.querySelector('.wifl-packages');
		if (!grid || !service) {
			return;
		}
		var packages = service.packages || [];
		grid.innerHTML = packages
			.map(function (pkg, i) {
				var off = pkg.discount
					? '<span class="wifl-pkg__off">' + esc(pkg.discount) + '</span>'
					: '';
				return (
					'<button type="button" class="wifl-pkg' +
					(i === 0 ? ' is-active' : '') +
					'" data-index="' +
					i +
					'" aria-pressed="' +
					(i === 0 ? 'true' : 'false') +
					'">' +
					'<span class="wifl-pkg__qty">' +
					esc(pkg.qty) +
					'</span>' +
					off +
					'</button>'
				);
			})
			.join('');
	}

	function updatePrice(root, pkg) {
		if (!pkg) {
			return;
		}
		var sale = root.querySelector('.wifl-price__sale');
		var regular = root.querySelector('.wifl-price__regular');
		var savings = root.querySelector('.wifl-savings');
		var saveAmt = root.querySelector('.wifl-savings__amount');

		if (sale) {
			sale.innerHTML = pkg.saleHtml || '';
		}
		if (regular) {
			if (pkg.regularHtml) {
				regular.innerHTML = pkg.regularHtml;
				regular.hidden = false;
			} else {
				regular.innerHTML = '';
				regular.hidden = true;
			}
		}
		if (savings) {
			if (pkg.saveHtml && saveAmt) {
				saveAmt.innerHTML = pkg.saveHtml;
				savings.hidden = false;
			} else {
				savings.hidden = true;
			}
		}
	}

	function currentPackage(root, data) {
		var active = getActive(root);
		var service = data.services[active.service];
		if (!service) {
			return null;
		}
		return service.packages[active.package] || service.packages[0] || null;
	}

	function showMessage(root, text, type) {
		var box = root.querySelector('.wifl-message');
		if (!box) {
			return;
		}
		box.hidden = !text;
		box.textContent = text || '';
		box.classList.toggle('is-error', type === 'error');
		box.classList.toggle('is-success', type === 'success');
	}

	function applyCartFragments(fragments, cartHash, btn) {
		if (fragments && typeof fragments === 'object') {
			Object.keys(fragments).forEach(function (selector) {
				try {
					document.querySelectorAll(selector).forEach(function (el) {
						var wrap = document.createElement('div');
						wrap.innerHTML = fragments[selector];
						if (wrap.children.length === 1) {
							el.replaceWith(wrap.firstElementChild);
						} else {
							el.outerHTML = fragments[selector];
						}
					});
				} catch (e) {
					/* ignore bad selectors */
				}
			});
		}

		try {
			if (cartHash) {
				sessionStorage.setItem('wc_cart_hash', cartHash);
				sessionStorage.setItem('woocommerce_cart_hash', cartHash);
			}
		} catch (e) {
			/* ignore */
		}

		if (window.jQuery) {
			window.jQuery(document.body).trigger('added_to_cart', [
				fragments || {},
				cartHash || '',
				null
			]);
			window.jQuery(document.body).trigger('wc_fragment_refresh');
		}
	}

	function addToCart(root, data) {
		var btn = root.querySelector('.wifl-cart');
		if (!btn || btn.disabled || btn.classList.contains('is-loading')) {
			return;
		}

		var settings = window.wiflSettings || {};
		var active = getActive(root);
		var service = data.services[active.service] || {};
		var activeCard = root.querySelector('.wifl-service.is-active');
		var productId =
			(activeCard && parseInt(activeCard.getAttribute('data-product'), 10)) ||
			service.productId ||
			data.productId ||
			parseInt(root.getAttribute('data-product'), 10) ||
			0;
		var serviceIndex = typeof service.serviceIndex === 'number' ? service.serviceIndex : active.service;
		var label = btn.querySelector('.wifl-cart__text');
		var original = label ? label.textContent : btn.textContent;

		if (!productId) {
			showMessage(root, (settings.i18n && settings.i18n.error) || 'Could not add to cart.', 'error');
			return;
		}

		btn.classList.add('is-loading');
		btn.disabled = true;
		if (label) {
			label.textContent = settings.i18n && settings.i18n.adding ? settings.i18n.adding : 'Adding…';
		}
		showMessage(root, '', '');

		var body = new URLSearchParams();
		body.set('action', 'wifl_add_to_cart');
		body.set('nonce', settings.nonce || '');
		body.set('product_id', String(productId));
		body.set('service', String(serviceIndex));
		body.set('package', String(active.package));

		fetch(settings.ajaxUrl || '/wp-admin/admin-ajax.php', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		})
			.then(function (res) {
				return res.json().then(function (json) {
					return { ok: res.ok, json: json };
				});
			})
			.then(function (result) {
				var json = result.json || {};
				if (!json.success) {
					var err =
						(json.data && json.data.message) ||
						(settings.i18n && settings.i18n.error) ||
						'Could not add to cart.';
					showMessage(root, err, 'error');
					return;
				}

				var payload = json.data || {};
				applyCartFragments(payload.fragments, payload.cart_hash, btn);

				if (label) {
					label.textContent = settings.i18n && settings.i18n.added ? settings.i18n.added : 'Added to cart';
				}
				showMessage(root, settings.i18n && settings.i18n.added ? settings.i18n.added : 'Added to cart', 'success');

				window.setTimeout(function () {
					if (label) {
						label.textContent = original;
					}
					showMessage(root, '', '');
				}, 1800);
			})
			.catch(function () {
				showMessage(root, (settings.i18n && settings.i18n.error) || 'Could not add to cart.', 'error');
			})
			.finally(function () {
				btn.classList.remove('is-loading');
				btn.disabled = false;
			});
	}

	function cssInt(el, name, fallback) {
		var n = parseInt(window.getComputedStyle(el).getPropertyValue(name).trim(), 10);
		return n > 0 ? n : fallback;
	}

	function limitServiceGrid(root) {
		var wrap = root.querySelector('.wifl-services');
		if (!wrap) {
			return;
		}
		var cols = cssInt(root, '--wifl-service-cols', 2);
		var rows = cssInt(root, '--wifl-service-rows', 5);
		var max = Math.max(1, cols * rows);
		var cards = Array.prototype.slice.call(wrap.querySelectorAll('.wifl-service'));
		var switchTo = null;
		cards.forEach(function (card, i) {
			var hide = i >= max;
			if (hide) {
				card.setAttribute('hidden', 'hidden');
				card.setAttribute('tabindex', '-1');
				if (card.classList.contains('is-active')) {
					switchTo = cards[0] || null;
				}
			} else {
				card.removeAttribute('hidden');
				card.removeAttribute('tabindex');
			}
		});
		if (switchTo && !switchTo.hasAttribute('hidden')) {
			switchTo.click();
		}
	}

	function bind(root) {
		if (root.getAttribute('data-wifl-ready') === '1') {
			return;
		}
		root.setAttribute('data-wifl-ready', '1');

		var data = parseData(root);
		if (!data || !data.services) {
			return;
		}

		root.addEventListener('click', function (e) {
			var serviceBtn = e.target.closest('.wifl-service');
			if (serviceBtn && root.contains(serviceBtn)) {
				e.preventDefault();
				setPressed(root.querySelectorAll('.wifl-service'), serviceBtn);
				var index = parseInt(serviceBtn.getAttribute('data-index'), 10) || 0;
				var service = data.services[index];
				if (service && service.productId) {
					data.productId = service.productId;
					root.setAttribute('data-product', String(service.productId));
				}
				var cart = root.querySelector('.wifl-cart');
				if (cart) {
					cart.disabled = !data.productId;
				}
				renderPackages(root, service);
				updatePrice(root, currentPackage(root, data));
				return;
			}

			var pkgBtn = e.target.closest('.wifl-pkg');
			if (pkgBtn && root.contains(pkgBtn)) {
				e.preventDefault();
				setPressed(root.querySelectorAll('.wifl-pkg'), pkgBtn);
				updatePrice(root, currentPackage(root, data));
				return;
			}

			var cartBtn = e.target.closest('.wifl-cart');
			if (cartBtn && root.contains(cartBtn)) {
				e.preventDefault();
				addToCart(root, data);
			}
		});
	}

	function bindCats(stack) {
		if (!stack || stack.getAttribute('data-wifl-cats') === '1') {
			return;
		}
		stack.setAttribute('data-wifl-cats', '1');

		stack.addEventListener('click', function (e) {
			var btn = e.target.closest('.wifl-cat');
			if (!btn || !stack.contains(btn)) {
				return;
			}
			e.preventDefault();
			var index = btn.getAttribute('data-wifl-cat');
			stack.querySelectorAll('.wifl-cat').forEach(function (el) {
				var on = el === btn;
				el.classList.toggle('is-active', on);
				el.setAttribute('aria-selected', on ? 'true' : 'false');
			});
			stack.querySelectorAll('.wifl-stack__item').forEach(function (panel) {
				panel.hidden = panel.getAttribute('data-wifl-panel') !== index;
			});
		});
	}

	function init(context) {
		var scope = context || document;
		if (!scope.querySelectorAll) {
			return;
		}
		scope.querySelectorAll('.wifl').forEach(function (root) {
			bind(root);
			limitServiceGrid(root);
		});
		var stacks = scope.classList && scope.classList.contains('wifl-stack--tabs')
			? [scope]
			: Array.prototype.slice.call(scope.querySelectorAll('.wifl-stack--tabs'));
		stacks.forEach(bindCats);
	}

	var resizeTimer;
	window.addEventListener('resize', function () {
		window.clearTimeout(resizeTimer);
		resizeTimer = window.setTimeout(function () {
			document.querySelectorAll('.wifl').forEach(limitServiceGrid);
		}, 120);
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () {
			init(document);
		});
	} else {
		init(document);
	}

	if (window.elementorFrontend && window.elementorFrontend.hooks) {
		window.elementorFrontend.hooks.addAction('frontend/element_ready/ct-follower.default', function ($scope) {
			var el = $scope && $scope[0] ? $scope[0] : $scope;
			init(el);
		});
	} else {
		window.addEventListener('elementor/frontend/init', function () {
			if (!window.elementorFrontend || !window.elementorFrontend.hooks) {
				return;
			}
			window.elementorFrontend.hooks.addAction('frontend/element_ready/ct-follower.default', function ($scope) {
				var el = $scope && $scope[0] ? $scope[0] : $scope;
				init(el);
			});
		});
	}

	window.addEventListener('elementor/popup/show', function () {
		document.querySelectorAll('.wifl').forEach(limitServiceGrid);
	});

	if (window.elementor && window.elementor.channels && window.elementor.channels.editor) {
		window.elementor.channels.editor.on('change', function () {
			window.setTimeout(function () {
				document.querySelectorAll('.wifl').forEach(limitServiceGrid);
			}, 50);
		});
	}
})();
