(function () {
	'use strict';

	function qs(sel, root) {
		return (root || document).querySelector(sel);
	}

	function qsa(sel, root) {
		return Array.prototype.slice.call((root || document).querySelectorAll(sel));
	}

	function cfg() {
		return window.wiflCartPage || {};
	}

	function collect(root) {
		var data = {
			instagram: '',
			tiktok: '',
			youtube: '',
			email: '',
			deals: '0',
			targets: {}
		};
		root.querySelectorAll('[name^="wifl_user_"]').forEach(function (input) {
			var key = input.getAttribute('name').replace('wifl_user_', '');
			data[key] = String(input.value || '').replace(/^@/, '').trim();
		});
		root.querySelectorAll('[name^="wifl_target"]').forEach(function (input) {
			var name = input.getAttribute('name') || '';
			var match = name.match(/^wifl_target\[([^\]]+)\]$/);
			if (match && match[1]) {
				data.targets[match[1]] = String(input.value || '').trim();
			}
		});
		var email = qs('#wifl_email', root) || qs('#billing_email', root) || qs('[name="billing_email"]', root) || qs('[name="wifl_email"]', root);
		if (email) {
			data.email = String(email.value || '').trim();
		}
		var deals = qs('[name="wifl_deals"]', root);
		data.deals = deals && deals.checked ? '1' : '0';
		return data;
	}

	function post(action, extra, root) {
		var body = new URLSearchParams();
		body.set('action', action);
		body.set('nonce', cfg().nonce || '');
		var accounts = collect(root);
		Object.keys(accounts).forEach(function (key) {
			if (key === 'email') {
				body.set('email', accounts[key]);
				body.set('wifl_email', accounts[key]);
				body.set('billing_email', accounts[key]);
			} else if (key === 'deals') {
				body.set('deals', accounts[key]);
			} else if (key === 'targets') {
				Object.keys(accounts.targets || {}).forEach(function (cartKey) {
					body.set('wifl_target[' + cartKey + ']', accounts.targets[cartKey]);
				});
			} else {
				body.set('wifl_user_' + key, accounts[key]);
			}
		});
		if (extra) {
			Object.keys(extra).forEach(function (key) {
				body.set(key, extra[key]);
			});
		}
		return fetch(cfg().ajaxUrl || '/wp-admin/admin-ajax.php', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (res) {
			return res.json();
		});
	}

	function showError(root, message) {
		var box = qs('.wifl-co-js-error', root);
		if (!box) {
			box = document.createElement('div');
			box.className = 'wifl-co__error wifl-co-js-error';
			var inner = qs('.wifl-co__main-inner', root);
			if (inner) {
				inner.insertBefore(box, inner.firstChild);
			}
		}
		box.hidden = !message;
		box.textContent = message || '';
	}

	function itemKeys(root) {
		return qsa('.wifl-co-item[data-key]', root).map(function (el) {
			return el.getAttribute('data-key') || '';
		}).filter(Boolean);
	}

	function flashNewItems(root, beforeKeys) {
		var keys = itemKeys(root);
		keys.forEach(function (key) {
			if (beforeKeys.indexOf(key) !== -1) {
				return;
			}
			var row = qs('.wifl-co-item[data-key="' + key + '"]', root);
			if (!row) {
				return;
			}
			row.classList.add('is-new');
			window.setTimeout(function () {
				row.classList.remove('is-new');
			}, 900);
		});
	}

	function applyState(root, state, opts) {
		if (!state) {
			return;
		}
		opts = opts || {};
		window.wiflCartPage = window.wiflCartPage || {};
		window.wiflCartPage.state = state;
		root.setAttribute('data-empty', state.empty ? '1' : '0');

		var beforeKeys = itemKeys(root);

		var total = qs('[data-total]', root);
		if (total && state.totalHeadline) {
			total.textContent = state.totalHeadline;
		}

		var items = qs('[data-items]', root);
		if (items && typeof state.itemsHtml === 'string') {
			items.classList.add('is-updating');
			items.innerHTML = state.itemsHtml;
			window.requestAnimationFrame(function () {
				items.classList.remove('is-updating');
				if (opts.flashNew) {
					flashNewItems(root, beforeKeys);
				}
			});
		}

		var sums = qs('[data-sums]', root);
		if (sums && typeof state.sumsHtml === 'string') {
			sums.innerHTML = state.sumsHtml;
		}

		// Keep username/email form in sync when cart packages change (e.g. likes need a post URL).
		if (opts.replaceAccounts !== false) {
			var accounts = qs('[data-accounts]', root);
			if (accounts && typeof state.accountsHtml === 'string') {
				accounts.innerHTML = state.accountsHtml;
			}
		}

		var upsells = qs('[data-upsells]', root);
		if (upsells && typeof state.upsellsHtml === 'string') {
			upsells.classList.add('is-updating');
			upsells.innerHTML = state.upsellsHtml;
			window.requestAnimationFrame(function () {
				upsells.classList.remove('is-updating');
			});
		}

		if (window.jQuery) {
			window.jQuery(document.body).trigger('wc_fragment_refresh');
		}

		var cta = qs('.wifl-js-continue', root);
		if (cta) {
			cta.disabled = !!state.empty;
			var i18n = cfg().i18n || {};
			cta.textContent = state.empty ? (i18n.addPackage || 'Add a package to continue') : (i18n.reviewPay || 'Review & Pay');
		}
	}

	function busy(root, on) {
		root.classList.toggle('is-busy', !!on);
	}

	function validate(root) {
		var i18n = cfg().i18n || {};
		var fields = root.querySelectorAll('[data-accounts] [name^="wifl_user_"][required]');
		for (var i = 0; i < fields.length; i++) {
			var user = String(fields[i].value || '').replace(/^@/, '').trim();
			if (!/^[A-Za-z0-9._-]{2,64}$/.test(user)) {
				fields[i].focus();
				return i18n.required || 'Enter a username for each platform in your order.';
			}
		}
		var links = root.querySelectorAll('[data-accounts] [name^="wifl_target"][required]');
		for (var j = 0; j < links.length; j++) {
			var val = String(links[j].value || '').trim();
			if (!val || !/^https:\/\//i.test(val)) {
				links[j].focus();
				return i18n.postLink || 'Paste the post/reel URL for each likes, views, or comments package.';
			}
		}
		var email = qs('#wifl_email', root) || qs('#billing_email', root);
		if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email.value || '').trim())) {
			email.focus();
			return i18n.email || 'Enter a valid email address.';
		}
		return '';
	}

	function addProduct(root, btn) {
		if (!btn || root.classList.contains('is-busy')) {
			return;
		}
		var row = btn.closest('.wifl-co-up');
		if (row) {
			row.classList.add('is-adding');
		}
		busy(root, true);
		post(
			'wifl_cart_page_add',
			{
				product_id: btn.getAttribute('data-id') || '',
				service: btn.getAttribute('data-service') || '0',
				package: btn.getAttribute('data-package') || '0'
			},
			root
		)
			.then(function (json) {
				if (json && json.success) {
					applyState(root, json.data || {}, { flashNew: true });
					showError(root, '');
				} else {
					showError(root, (json && json.data && json.data.message) || (cfg().i18n && cfg().i18n.error));
				}
			})
			.catch(function () {
				showError(root, cfg().i18n && cfg().i18n.error);
			})
			.finally(function () {
				busy(root, false);
				qsa('.wifl-co-up.is-adding', root).forEach(function (el) {
					el.classList.remove('is-adding');
				});
			});
	}

	function bind(root) {
		if (!root || root.getAttribute('data-ready') === '1') {
			return;
		}
		root.setAttribute('data-ready', '1');

		root.addEventListener('click', function (e) {
			var forget = e.target.closest('.wifl-js-forget');
			if (forget) {
				e.preventDefault();
				e.stopPropagation();
				busy(root, true);
				post(
					'wifl_cart_page_forget',
					{
						platform: forget.getAttribute('data-platform') || '',
						user: forget.getAttribute('data-user') || ''
					},
					root
				)
					.then(function (json) {
						if (json && json.success) {
							applyState(root, json.data || {}, { replaceAccounts: true });
							showError(root, '');
						}
					})
					.finally(function () {
						busy(root, false);
					});
				return;
			}

			var recent = e.target.closest('.wifl-js-recent');
			if (recent) {
				e.preventDefault();
				var platform = recent.getAttribute('data-platform') || '';
				var user = recent.getAttribute('data-user') || '';
				var input = qs('[name="wifl_user_' + platform + '"]', root);
				if (input) {
					input.value = user;
					input.focus();
				}
				return;
			}

			var remove = e.target.closest('.wifl-js-remove');
			if (remove) {
				e.preventDefault();
				busy(root, true);
				post('wifl_cart_page_remove', { key: remove.getAttribute('data-key') || '' }, root)
					.then(function (json) {
						if (json && json.success) {
							applyState(root, json.data || {});
							showError(root, '');
						} else {
							showError(root, (json && json.data && json.data.message) || (cfg().i18n && cfg().i18n.error));
						}
					})
					.catch(function () {
						showError(root, cfg().i18n && cfg().i18n.error);
					})
					.finally(function () {
						busy(root, false);
					});
				return;
			}

			var addBtn = e.target.closest('.wifl-js-add');
			if (addBtn) {
				e.preventDefault();
				addProduct(root, addBtn);
				return;
			}

			var upsellRow = e.target.closest('.wifl-co-up:not(.is-in)');
			if (upsellRow) {
				var rowBtn = qs('.wifl-js-add', upsellRow);
				if (rowBtn) {
					e.preventDefault();
					addProduct(root, rowBtn);
				}
				return;
			}

			var go = e.target.closest('.wifl-js-continue');
			if (go) {
				e.preventDefault();
				var err = validate(root);
				if (err) {
					showError(root, err);
					return;
				}
				busy(root, true);
				post('wifl_cart_page_save', {}, root)
					.then(function (json) {
						if (json && json.success) {
							var url = (json.data && json.data.checkoutUrl) || cfg().checkoutUrl;
							window.location.href = url || '/checkout';
							return;
						}
						showError(root, (json && json.data && json.data.message) || (cfg().i18n && cfg().i18n.error));
						busy(root, false);
					})
					.catch(function () {
						showError(root, cfg().i18n && cfg().i18n.error);
						busy(root, false);
					});
			}
		});
	}

	function init() {
		var root = qs('.wifl-co');
		if (root) {
			bind(root);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
