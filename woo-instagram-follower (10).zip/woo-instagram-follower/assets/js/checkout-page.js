(function () {
	'use strict';

	function qs(sel, root) {
		return (root || document).querySelector(sel);
	}

	function qsa(sel, root) {
		return Array.prototype.slice.call((root || document).querySelectorAll(sel));
	}

	function cfg() {
		return window.wiflCheckoutPage || {};
	}

	function post(action, extra) {
		var body = new URLSearchParams();
		body.set('action', action);
		body.set('nonce', cfg().nonce || '');
		if (extra) {
			Object.keys(extra).forEach(function (key) {
				body.set(key, extra[key]);
			});
		}
		return fetch(cfg().ajaxUrl || '/wp-admin/admin-ajax.php', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (res) {
			return res.json();
		});
	}

	function disableWcRadios(root) {
		qsa('ul.wc_payment_methods input[name="payment_method"]', root).forEach(function (el) {
			el.disabled = true;
			el.removeAttribute('name');
		});
	}

	function syncPayMethod(root) {
		qsa('.wifl-ck-method', root).forEach(function (row) {
			var radio = qs('.wifl-js-pay', row);
			var on = !!(radio && radio.checked);
			row.classList.toggle('is-on', on);
			var box = qs('.wifl-ck-method__box', row);
			if (box) {
				box.hidden = !on;
			}
		});
		if (window.jQuery) {
			window.jQuery(document.body).trigger('payment_method_selected');
		}
	}

	function applyState(root, state) {
		if (!state) {
			return;
		}
		var total = qs('[data-total]', root);
		if (total && state.totalAmount) {
			total.innerHTML = '';
			total.appendChild(document.createTextNode(state.totalAmount));
			if (state.currency) {
				total.appendChild(document.createTextNode(' '));
				var ccy = document.createElement('span');
				ccy.className = 'wifl-ck__ccy';
				ccy.textContent = state.currency;
				total.appendChild(ccy);
			}
		}
		var items = qs('[data-items]', root);
		if (items && state.itemsHtml) {
			items.innerHTML = state.itemsHtml;
		}
		var promo = qs('[data-promo]', root);
		if (promo && state.promoHtml) {
			promo.innerHTML = state.promoHtml;
		}
		var btn = qs('#place_order', root);
		if (btn && state.payLabel) {
			btn.textContent = state.payLabel;
			btn.value = state.payLabel;
			btn.setAttribute('data-value', state.payLabel);
		}
		if (window.jQuery) {
			window.jQuery(document.body).trigger('update_checkout');
		}
	}

	function busy(root, on) {
		root.classList.toggle('is-busy', !!on);
	}

	function bind(root) {
		if (!root || root.getAttribute('data-ready') === '1') {
			return;
		}
		root.setAttribute('data-ready', '1');
		disableWcRadios(root);
		syncPayMethod(root);

		root.addEventListener('click', function (e) {
			if (e.target.closest('.wifl-js-speed-more')) {
				e.preventDefault();
				var btn = e.target.closest('.wifl-js-speed-more');
				var extra = qs('.wifl-ck-speeds', root);
				if (extra) {
					var show = extra.hasAttribute('hidden');
					if (show) {
						extra.removeAttribute('hidden');
					} else {
						extra.setAttribute('hidden', 'hidden');
					}
					btn.setAttribute('aria-expanded', show ? 'true' : 'false');
				}
				return;
			}

			if (e.target.closest('.wifl-js-promo-toggle')) {
				e.preventDefault();
				var form = qs('.wifl-ck-promo__form', root);
				if (form) {
					form.hidden = !form.hidden;
				}
				return;
			}

			var apply = e.target.closest('.wifl-js-apply-coupon');
			if (apply) {
				e.preventDefault();
				var input = qs('.wifl-js-coupon', root);
				var code = input ? String(input.value || '').trim() : '';
				if (!code) {
					return;
				}
				busy(root, true);
				post('wifl_checkout_coupon', { code: code })
					.then(function (json) {
						if (json && json.success) {
							applyState(root, json.data || {});
						} else {
							window.alert((json && json.data && json.data.message) || (cfg().i18n && cfg().i18n.error));
						}
					})
					.finally(function () {
						busy(root, false);
					});
				return;
			}

			var remove = e.target.closest('.wifl-js-remove-coupon');
			if (remove) {
				e.preventDefault();
				busy(root, true);
				post('wifl_checkout_coupon', { code: remove.getAttribute('data-code') || '', remove: '1' })
					.then(function (json) {
						if (json && json.success) {
							applyState(root, json.data || {});
						}
					})
					.finally(function () {
						busy(root, false);
					});
			}
		});

		root.addEventListener('change', function (e) {
			if (e.target.closest('.wifl-js-pay')) {
				syncPayMethod(root);
				return;
			}

			var refill = e.target.closest('.wifl-js-refill');
			if (refill) {
				busy(root, true);
				post('wifl_checkout_option', { refill: refill.value })
					.then(function (json) {
						if (json && json.success) {
							applyState(root, json.data || {});
						}
					})
					.finally(function () {
						busy(root, false);
					});
				return;
			}

			var delivery = e.target.closest('.wifl-js-delivery');
			if (delivery) {
				busy(root, true);
				post('wifl_checkout_option', { delivery: delivery.value })
					.then(function (json) {
						if (json && json.success) {
							applyState(root, json.data || {});
						}
					})
					.finally(function () {
						busy(root, false);
					});
				return;
			}

			var upgrade = e.target.closest('.wifl-js-upgrade');
			if (upgrade) {
				busy(root, true);
				post('wifl_checkout_upgrade', { on: upgrade.checked ? '1' : '' })
					.then(function (json) {
						if (json && json.success) {
							window.location.reload();
							return;
						}
						upgrade.checked = !upgrade.checked;
					})
					.finally(function () {
						busy(root, false);
					});
			}
		});
	}

	function init() {
		var root = qs('.wifl-ck');
		if (root) {
			bind(root);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
