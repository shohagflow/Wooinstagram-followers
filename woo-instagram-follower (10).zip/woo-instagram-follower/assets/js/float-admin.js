(function ($) {
	'use strict';

	function bindPreview() {
		var $btn = $('#wifl-float-preview-btn');
		var $badge = $('#wifl-float-preview-badge');
		var $label = $('#wifl-float-preview-label');
		if (!$btn.length) {
			return;
		}

		function paint() {
			$btn.css({
				background: $('#wifl-float-dock-bg').val() || '#111',
				color: $('#wifl-float-text-color').val() || '#fff',
				borderRadius: ($('#wifl-float-radius').val() || 999) + 'px',
				fontSize: ($('#wifl-float-size').val() || 15) + 'px'
			});
			$badge.css('background', $('#wifl-float-badge').val() || '#e11d48');
			$label.text($('#wifl-float-text').val() || 'View cart');
		}

		$('.wifl-color').wpColorPicker({
			change: function (event, ui) {
				if (ui && ui.color) {
					$(this).val(ui.color.toString());
				}
				paint();
			},
			clear: paint
		});

		$('#wifl-float-text, #wifl-float-radius, #wifl-float-size').on('input change', paint);
		paint();
	}

	$(bindPreview);
})(jQuery);
