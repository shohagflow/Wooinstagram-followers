(function () {
	'use strict';

	function cartCount() {
		var badge = document.querySelector('.wifl-dock__badge');
		if (badge) {
			return parseInt(badge.textContent, 10) || 0;
		}
		if (window.wiflFloat && window.wiflFloat.cart) {
			return parseInt(window.wiflFloat.cart.count, 10) || 0;
		}
		var sync = document.querySelector('.wifl-float-sync');
		if (sync) {
			return parseInt(sync.getAttribute('data-count'), 10) || 0;
		}
		return 0;
	}

	function syncBadges() {
		var count = cartCount();
		document.querySelectorAll('.wifl-cart-menu').forEach(function (btn) {
			var badge = btn.querySelector('.wifl-cart-menu__badge');
			if (!badge) {
				return;
			}
			badge.textContent = String(count);
			var hideZero = btn.getAttribute('data-hide-zero') === '1';
			if (count < 1 && hideZero) {
				badge.setAttribute('hidden', '');
				badge.hidden = true;
			} else {
				badge.removeAttribute('hidden');
				badge.hidden = false;
			}
		});
	}

	function openCart() {
		if (typeof window.wiflFloatOpenCart === 'function') {
			window.wiflFloatOpenCart();
			return;
		}
		var trigger = document.querySelector('.wifl-js-open-cart');
		if (trigger) {
			trigger.click();
		}
	}

	function bind() {
		document.addEventListener('click', function (e) {
			if (!e.target.closest('.wifl-js-cart-menu-open')) {
				return;
			}
			e.preventDefault();
			openCart();
		});

		syncBadges();

		if (window.jQuery) {
			window.jQuery(document.body).on(
				'added_to_cart removed_from_cart wc_fragments_refreshed wc_fragments_loaded',
				syncBadges
			);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', bind);
	} else {
		bind();
	}
})();
