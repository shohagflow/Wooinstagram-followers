(function ($) {
	'use strict';

	function uid() {
		return Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);
	}

	$(document).on('click', '[data-wifl-add-sub]', function (e) {
		e.preventDefault();
		var html = $('#tmpl-wifl-sub-card').html() || '';
		var index = uid();
		html = html.replace(/__I__/g, index);
		$('#wifl-subs-list').append(html);
	});

	$(document).on('click', '[data-wifl-remove-sub]', function (e) {
		e.preventDefault();
		var $cards = $('#wifl-subs-list .wifl-sub-editor');
		if ($cards.length <= 1) {
			$(this).closest('.wifl-sub-editor').find('input[type="text"], input[type="url"], textarea').val('');
			return;
		}
		$(this).closest('.wifl-sub-editor').remove();
	});

	$(document).on('input', '.wifl-sub-editor input[name$="[name]"]', function () {
		var title = $(this).val() || 'New plan';
		$(this).closest('.wifl-sub-editor').find('.wifl-sub-editor__title').text(title);
	});

	function planPrefix($editor) {
		var name = $editor.find('input[name$="[id]"]').attr('name') || '';
		return name.replace(/\[id\]$/, '');
	}

	$(document).on('click', '[data-wifl-add-feature]', function (e) {
		e.preventDefault();
		var $editor = $(this).closest('.wifl-sub-editor');
		var html = $('#tmpl-wifl-sub-feature').html() || '';
		html = html.replace(/__PREFIX__/g, planPrefix($editor)).replace(/__F__/g, uid());
		$editor.find('.wifl-sub-features__list').append(html);
	});

	$(document).on('click', '[data-wifl-remove-feature]', function (e) {
		e.preventDefault();
		var $list = $(this).closest('.wifl-sub-features__list');
		if ($list.find('.wifl-sub-feature').length <= 1) {
			$(this).closest('.wifl-sub-feature').find('input').val('');
			return;
		}
		$(this).closest('.wifl-sub-feature').remove();
	});
})(jQuery);
