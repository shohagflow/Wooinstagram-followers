(function ($) {
	'use strict';

	var smmGroups = null;
	var smmLoading = null;

	function uid() {
		return Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);
	}

	function featureTemplate(serviceIndex, featureIndex) {
		var html = $('#tmpl-wifl-feature').html() || '';
		return html.replace(/__S__/g, serviceIndex).replace(/__F__/g, featureIndex);
	}

	function packageTemplate(serviceIndex, packageIndex) {
		var html = $('#tmpl-wifl-package').html() || '';
		return html.replace(/__S__/g, serviceIndex).replace(/__P__/g, packageIndex);
	}

	function parsePrice(val) {
		var n = parseFloat(String(val || '').replace(/,/g, '').trim());
		return isFinite(n) ? n : NaN;
	}

	function validatePriceRow($row, announce) {
		var $disc = $row.find('.wifl-price-discount');
		var $orig = $row.find('.wifl-price-original');
		var disc = parsePrice($disc.val());
		var orig = parsePrice($orig.val());
		$row.removeClass('wifl-package-row--price-error');
		$disc.removeClass('wifl-input-error');
		$orig.removeClass('wifl-input-error');
		if (!isFinite(disc) || !isFinite(orig) || orig <= 0) {
			return true;
		}
		if (disc > orig) {
			$row.addClass('wifl-package-row--price-error');
			$disc.addClass('wifl-input-error');
			if (announce && window.wiflAdmin && wiflAdmin.i18n && wiflAdmin.i18n.priceError) {
				window.alert(wiflAdmin.i18n.priceError);
			}
			return false;
		}
		return true;
	}

	function fillSmmSelect($select) {
		if (!$select || !$select.length || !smmGroups) {
			return;
		}
		var selected = String($select.attr('data-selected') || $select.val() || '');
		var name = $select.attr('name');
		var html = '<option value="">' + (window.wiflAdmin && wiflAdmin.i18n ? wiflAdmin.i18n.selectSmm : 'Select SMM service…') + '</option>';
		smmGroups.forEach(function (group) {
			html += '<optgroup label="' + $('<div>').text(group.category || '').html() + '">';
			(group.services || []).forEach(function (svc) {
				var id = String(svc.id);
				var sel = id === selected ? ' selected' : '';
				html +=
					'<option value="' +
					id +
					'"' +
					sel +
					'>' +
					$('<div>').text(svc.label || id).html() +
					'</option>';
			});
			html += '</optgroup>';
		});
		$select.html(html);
		if (selected) {
			$select.val(selected);
		}
		$select.attr('name', name);
	}

	function fillAllSmmSelects() {
		$('#wifl_product_data .wifl-smm-service-select').each(function () {
			fillSmmSelect($(this));
		});
	}

	function loadSmmServices(force) {
		if (smmGroups && !force) {
			fillAllSmmSelects();
			return $.Deferred().resolve(smmGroups).promise();
		}
		if (smmLoading && !force) {
			return smmLoading;
		}
		var cfg = window.wiflAdmin || {};
		$('#wifl_product_data').addClass('wifl-smm-loading');
		smmLoading = $.post(cfg.ajaxUrl || ajaxurl, {
			action: 'wifl_admin_smm_services',
			nonce: cfg.nonce || '',
			refresh: force ? '1' : ''
		})
			.done(function (json) {
				if (json && json.success && json.data && json.data.groups) {
					smmGroups = json.data.groups;
					fillAllSmmSelects();
					$('.wifl-smm-status').text(
						(cfg.i18n && cfg.i18n.smmLoaded
							? cfg.i18n.smmLoaded.replace('%d', json.data.count || smmGroups.length)
							: 'SMM services loaded.')
					);
				} else {
					var msg =
						(json && json.data && json.data.message) ||
						(cfg.i18n && cfg.i18n.smmError) ||
						'Could not load SMM services.';
					$('.wifl-smm-status').text(msg);
				}
			})
			.fail(function () {
				var cfg2 = window.wiflAdmin || {};
				$('.wifl-smm-status').text((cfg2.i18n && cfg2.i18n.smmError) || 'Could not load SMM services.');
			})
			.always(function () {
				$('#wifl_product_data').removeClass('wifl-smm-loading');
				smmLoading = null;
			});
		return smmLoading;
	}

	$(document).on('click', '.wifl-remove-service', function (e) {
		e.preventDefault();
		var $cards = $('#wifl-services-wrap .wifl-service-card');
		if ($cards.length <= 1) {
			return;
		}
		var msg = window.wiflAdmin && wiflAdmin.i18n ? wiflAdmin.i18n.confirm : 'Remove this service type?';
		if (window.confirm(msg)) {
			$(this).closest('.wifl-service-card').remove();
			if ($('#wifl-services-wrap .wifl-service-card').length <= 1) {
				$('#wifl-services-wrap .wifl-remove-service').remove();
			}
		}
	});

	$(document).on('click', '.wifl-add-feature', function (e) {
		e.preventDefault();
		var $card = $(this).closest('.wifl-service-card');
		var s = $card.attr('data-service');
		$card.find('.wifl-features-list').append(featureTemplate(s, uid()));
	});

	$(document).on('click', '.wifl-remove-feature', function (e) {
		e.preventDefault();
		var $list = $(this).closest('.wifl-features-list');
		if ($list.find('.wifl-feature-row').length <= 1) {
			$(this).closest('.wifl-feature-row').find('input').val('');
			return;
		}
		$(this).closest('.wifl-feature-row').remove();
	});

	$(document).on('click', '.wifl-add-package', function (e) {
		e.preventDefault();
		var $card = $(this).closest('.wifl-service-card');
		var s = $card.attr('data-service');
		var $row = $(packageTemplate(s, uid()));
		$card.find('.wifl-packages-table tbody').append($row);
		fillSmmSelect($row.find('.wifl-smm-service-select'));
	});

	$(document).on('click', '.wifl-remove-package', function (e) {
		e.preventDefault();
		var $tbody = $(this).closest('tbody');
		if ($tbody.find('tr').length <= 1) {
			$(this).closest('tr').find('input').val('');
			$(this).closest('tr').find('select').val('').attr('data-selected', '');
			return;
		}
		$(this).closest('tr').remove();
	});

	$(document).on('change blur', '.wifl-price-discount, .wifl-price-original', function () {
		var $row = $(this).closest('.wifl-package-row');
		var ok = validatePriceRow($row, false);
		if (!ok) {
			var $disc = $row.find('.wifl-price-discount');
			var $orig = $row.find('.wifl-price-original');
			var orig = parsePrice($orig.val());
			if (isFinite(orig)) {
				$disc.val(String(orig));
				validatePriceRow($row, true);
			}
		}
	});

	$(document).on('change', '.wifl-smm-service-select', function () {
		$(this).attr('data-selected', $(this).val() || '');
	});

	$(document).on('click', '.wifl-refresh-smm', function (e) {
		e.preventDefault();
		loadSmmServices(true);
	});

	$('#post').on('submit', function (e) {
		var bad = false;
		$('#wifl_product_data .wifl-package-row').each(function () {
			if (!validatePriceRow($(this), false)) {
				bad = true;
			}
		});
		if (bad) {
			e.preventDefault();
			var msg =
				(window.wiflAdmin && wiflAdmin.i18n && wiflAdmin.i18n.priceError) ||
				'Discount price cannot be greater than original price.';
			window.alert(msg);
			return false;
		}
	});

	/* —— Product Subscription tab —— */
	$(document).on('click', '.wifl-remove-sub-plan', function (e) {
		e.preventDefault();
		var $list = $('#wifl-sub-product-plans .wifl-sub-editor');
		if ($list.length <= 1) {
			$(this)
				.closest('.wifl-sub-editor')
				.find('input[type="text"], input[type="url"], textarea')
				.val('');
			return;
		}
		$(this).closest('.wifl-sub-editor').remove();
	});

	$(document).on('input', '#wifl_subscription_data .wifl-sub-editor input[name$="[name]"]', function () {
		var title = $(this).val() || 'New plan';
		$(this).closest('.wifl-sub-editor').find('.wifl-sub-editor__title').text(title);
	});

	$(document).on('change', '#wifl_subscription_data .wifl-sub-editor input[name$="[featured]"]', function () {
		$(this).closest('.wifl-sub-editor').toggleClass('is-featured', this.checked);
	});

	$(document).on('click', '.wifl-add-sub-feature', function (e) {
		e.preventDefault();
		var $editor = $(this).closest('.wifl-sub-editor');
		var index = $editor.attr('data-sub-index') || '0';
		var html = $('#tmpl-wifl-sub-plan-feature').html() || '';
		html = html.replace(/__I__/g, index).replace(/__F__/g, uid());
		$editor.find('.wifl-sub-features__list').append(html);
	});

	$(document).on('click', '.wifl-remove-sub-feature', function (e) {
		e.preventDefault();
		var $list = $(this).closest('.wifl-sub-features__list');
		if ($list.find('.wifl-sub-feature').length <= 1) {
			$(this).closest('.wifl-sub-feature').find('input').val('');
			return;
		}
		$(this).closest('.wifl-sub-feature').remove();
	});

	$(function () {
		if ($('#wifl_product_data').length) {
			if (!$('.wifl-smm-toolbar').length) {
				$('.wifl-packages__head').first().after(
					'<p class="wifl-smm-toolbar"><button type="button" class="button wifl-refresh-smm">' +
						((window.wiflAdmin && wiflAdmin.i18n && wiflAdmin.i18n.refreshSmm) || 'Refresh SMM services') +
						'</button> <span class="wifl-smm-status description"></span></p>'
				);
			}
			loadSmmServices(false);
		}
	});
})(jQuery);
