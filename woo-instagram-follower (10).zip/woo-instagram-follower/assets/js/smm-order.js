(function () {
	'use strict';

	var cfg = window.wiflSmmOrder || {};
	if (!cfg.connected) {
		return;
	}

	var state = {
		services: [],
		categories: [],
		platforms: [],
		platform: 'all',
		selected: null
	};

	function qs(sel, root) {
		return (root || document).querySelector(sel);
	}

	function qsa(sel, root) {
		return Array.prototype.slice.call((root || document).querySelectorAll(sel));
	}

	function i18n(key) {
		return (cfg.i18n && cfg.i18n[key]) || key;
	}

	function post(action, extra) {
		var body = new URLSearchParams();
		body.set('action', action);
		body.set('nonce', cfg.nonce || '');
		if (extra) {
			Object.keys(extra).forEach(function (k) {
				body.set(k, extra[k]);
			});
		}
		return fetch(cfg.ajaxUrl || '/wp-admin/admin-ajax.php', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (res) {
			return res.json();
		});
	}

	function formatNum(n) {
		var x = Number(n);
		if (!isFinite(x)) {
			return String(n || '');
		}
		try {
			return x.toLocaleString();
		} catch (e) {
			return String(x);
		}
	}

	function setBalance(data) {
		var el = qs('[data-balance]');
		if (!el) {
			return;
		}
		if (!data || !data.ok) {
			el.textContent = (data && data.message) || '—';
			return;
		}
		el.textContent = (data.currency ? data.currency + ' ' : '$') + (data.balance || '0');
	}

	function showMsg(text, ok) {
		var el = qs('[data-msg]');
		if (!el) {
			return;
		}
		if (!text) {
			el.hidden = true;
			el.textContent = '';
			el.className = 'wifl-smm-msg';
			return;
		}
		el.hidden = false;
		el.textContent = text;
		el.className = 'wifl-smm-msg ' + (ok ? 'is-ok' : 'is-error');
	}

	function platformOf(category) {
		var c = String(category || '').toLowerCase();
		var map = [
			['instagram', 'instagram'],
			['facebook', 'facebook'],
			['youtube', 'youtube'],
			['twitter', 'twitter'],
			['spotify', 'spotify'],
			['tiktok', 'tiktok'],
			['telegram', 'telegram'],
			['linkedin', 'linkedin'],
			['discord', 'discord'],
			['traffic', 'traffic'],
			['website', 'traffic']
		];
		for (var i = 0; i < map.length; i++) {
			if (c.indexOf(map[i][0]) !== -1) {
				return map[i][1];
			}
		}
		return 'others';
	}

	function filteredCategories() {
		var seen = {};
		var out = [];
		state.services.forEach(function (svc) {
			var cat = svc.category || '';
			if (!cat || seen[cat]) {
				return;
			}
			if (state.platform !== 'all' && platformOf(cat) !== state.platform) {
				return;
			}
			seen[cat] = true;
			out.push(cat);
		});
		out.sort(function (a, b) {
			return a.localeCompare(b, undefined, { sensitivity: 'base' });
		});
		return out;
	}

	function servicesInCategory(cat) {
		return state.services.filter(function (svc) {
			return (svc.category || '') === cat;
		});
	}

	function renderPlatforms() {
		var nav = qs('[data-platforms]');
		if (!nav) {
			return;
		}
		nav.innerHTML = '';
		(state.platforms || []).forEach(function (tab) {
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.textContent = tab.label;
			btn.dataset.platform = tab.key;
			if (tab.key === state.platform) {
				btn.className = 'is-active';
			}
			btn.addEventListener('click', function () {
				state.platform = tab.key;
				renderPlatforms();
				renderCategories();
				clearService();
			});
			nav.appendChild(btn);
		});
	}

	function renderCategories() {
		var sel = qs('[data-category]');
		if (!sel) {
			return;
		}
		var cats = filteredCategories();
		var current = sel.value;
		sel.innerHTML = '';
		var opt0 = document.createElement('option');
		opt0.value = '';
		opt0.textContent = i18n('selectCat');
		sel.appendChild(opt0);
		cats.forEach(function (cat) {
			var opt = document.createElement('option');
			opt.value = cat;
			opt.textContent = cat;
			sel.appendChild(opt);
		});
		if (current && cats.indexOf(current) !== -1) {
			sel.value = current;
			renderServices(current);
		} else {
			sel.value = '';
			clearService();
		}
	}

	function clearService() {
		state.selected = null;
		var svc = qs('[data-service]');
		if (svc) {
			svc.innerHTML = '';
			var opt0 = document.createElement('option');
			opt0.value = '';
			opt0.textContent = i18n('selectSvc');
			svc.appendChild(opt0);
			svc.disabled = true;
		}
		updateServiceUi(null);
	}

	function renderServices(cat) {
		var svc = qs('[data-service]');
		if (!svc) {
			return;
		}
		svc.innerHTML = '';
		var opt0 = document.createElement('option');
		opt0.value = '';
		opt0.textContent = i18n('selectSvc');
		svc.appendChild(opt0);

		if (!cat) {
			svc.disabled = true;
			updateServiceUi(null);
			return;
		}

		var list = servicesInCategory(cat);
		list.forEach(function (row) {
			var opt = document.createElement('option');
			opt.value = String(row.id);
			opt.textContent = row.id + ' - ' + (row.name || '');
			svc.appendChild(opt);
		});
		svc.disabled = list.length === 0;
		state.selected = null;
		updateServiceUi(null);
	}

	function findService(id) {
		id = Number(id);
		for (var i = 0; i < state.services.length; i++) {
			if (Number(state.services[i].id) === id) {
				return state.services[i];
			}
		}
		return null;
	}

	function updateServiceUi(svc) {
		state.selected = svc;
		var minmax = qs('[data-minmax]');
		var avg = qs('[data-avg-time]');
		var charge = qs('[data-charge]');
		var qty = qs('[data-quantity]');
		var title = qs('[data-desc-title]');
		var rateEl = qs('[data-desc-rate]');
		var body = qs('[data-desc-body]');

		if (!svc) {
			if (minmax) {
				minmax.textContent = '';
			}
			if (avg) {
				avg.value = '—';
			}
			if (charge) {
				charge.value = '—';
			}
			if (qty) {
				qty.removeAttribute('min');
				qty.removeAttribute('max');
			}
			if (title) {
				title.textContent = 'Service details';
			}
			if (rateEl) {
				rateEl.textContent = '';
			}
			if (body) {
				body.innerHTML = '<p class="wifl-smm-desc-empty">' + escapeHtml(i18n('noDesc')) + '</p>';
			}
			return;
		}

		var min = String(svc.min || '1');
		var max = String(svc.max || '0');
		if (minmax) {
			minmax.textContent = i18n('minMax')
				.replace('%1$s', formatNum(min))
				.replace('%2$s', formatNum(max));
		}
		if (qty) {
			qty.min = min;
			if (max && Number(max) > 0) {
				qty.max = max;
			} else {
				qty.removeAttribute('max');
			}
		}
		if (avg) {
			avg.value = '—';
		}
		if (title) {
			title.textContent = svc.id + ' - ' + (svc.name || '');
		}
		if (rateEl) {
			rateEl.textContent = i18n('perThousand').replace('%s', '$' + svc.rate);
		}
		if (body) {
			var refill = svc.refill ? 'Yes' : 'No';
			var html = '<ul class="wifl-smm-desc-list">';
			html += '<li><strong>Category</strong><span>' + escapeHtml(svc.category || '') + '</span></li>';
			html += '<li><strong>Type</strong><span>' + escapeHtml(svc.type || 'Default') + '</span></li>';
			html += '<li><strong>Min / Max</strong><span>' + escapeHtml(formatNum(min) + ' — ' + formatNum(max)) + '</span></li>';
			html += '<li><strong>Refill</strong><span>' + refill + '</span></li>';
			html += '<li><strong>Cancel</strong><span>' + (svc.cancel ? 'Yes' : 'No') + '</span></li>';
			html += '</ul>';
			if (svc.desc) {
				html += '<div class="wifl-smm-desc-html">' + sanitizeDesc(svc.desc) + '</div>';
			}
			body.innerHTML = html;
		}
		updateCharge();
	}

	function escapeHtml(str) {
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function sanitizeDesc(html) {
		var tmp = document.createElement('div');
		tmp.innerHTML = String(html || '');
		qsa('script,iframe,object,embed', tmp).forEach(function (n) {
			n.remove();
		});
		qsa('*', tmp).forEach(function (n) {
			Array.prototype.slice.call(n.attributes || []).forEach(function (attr) {
				if (/^on/i.test(attr.name) || (attr.name === 'href' && /^javascript:/i.test(attr.value))) {
					n.removeAttribute(attr.name);
				}
			});
		});
		return tmp.innerHTML;
	}

	function updateCharge() {
		var charge = qs('[data-charge]');
		var qtyEl = qs('[data-quantity]');
		if (!charge) {
			return;
		}
		if (!state.selected || !qtyEl) {
			charge.value = '—';
			return;
		}
		var qty = Number(String(qtyEl.value || '').replace(/[^0-9]/g, ''));
		var rate = Number(state.selected.rate);
		if (!qty || !isFinite(rate)) {
			charge.value = '—';
			return;
		}
		var cost = (rate / 1000) * qty;
		charge.value = '$' + cost.toFixed(6);
	}

	function applyPayload(data) {
		state.services = data.services || [];
		state.categories = data.categories || [];
		state.platforms = data.platforms || [];
		renderPlatforms();
		renderCategories();
	}

	function loadServices(refresh) {
		showMsg(i18n('loading'), true);
		return post(refresh ? 'wifl_smm_refresh_services' : 'wifl_smm_services').then(function (json) {
			if (!json || !json.success) {
				showMsg((json && json.data && json.data.message) || i18n('error'), false);
				return;
			}
			applyPayload(json.data || {});
			showMsg('');
		}).catch(function () {
			showMsg(i18n('error'), false);
		});
	}

	function bind() {
		var form = qs('[data-smm-form]');
		if (!form) {
			return;
		}

		var cat = qs('[data-category]', form);
		var svc = qs('[data-service]', form);
		var qty = qs('[data-quantity]', form);
		var refresh = qs('[data-refresh-services]');

		if (cat) {
			cat.addEventListener('change', function () {
				renderServices(cat.value);
			});
		}
		if (svc) {
			svc.addEventListener('change', function () {
				updateServiceUi(findService(svc.value));
			});
		}
		if (qty) {
			qty.addEventListener('input', updateCharge);
		}
		if (refresh) {
			refresh.addEventListener('click', function () {
				refresh.disabled = true;
				loadServices(true).finally(function () {
					refresh.disabled = false;
					showMsg(i18n('refreshOk'), true);
					setTimeout(function () {
						showMsg('');
					}, 1500);
				});
			});
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			showMsg('');
			var serviceId = svc ? svc.value : '';
			var link = qs('[data-link]', form);
			var note = qs('[data-note]', form);
			var submit = qs('[data-submit]', form);
			var selected = findService(serviceId);

			if (!serviceId || !link || !String(link.value || '').trim() || !qty || !String(qty.value || '').trim()) {
				showMsg(i18n('required'), false);
				return;
			}

			var q = Number(String(qty.value || '').replace(/[^0-9]/g, ''));
			if (selected) {
				var min = Number(selected.min) || 0;
				var max = Number(selected.max) || 0;
				if ((min && q < min) || (max && q > max)) {
					showMsg(
						i18n('qtyRange')
							.replace('%1$s', formatNum(min))
							.replace('%2$s', formatNum(max)),
						false
					);
					return;
				}
			}

			if (submit) {
				submit.disabled = true;
				submit.textContent = i18n('submitting');
			}

			post('wifl_smm_place_order', {
				service: serviceId,
				link: String(link.value || '').trim(),
				quantity: String(q),
				note: note ? String(note.value || '').trim() : ''
			}).then(function (json) {
				if (!json || !json.success) {
					showMsg((json && json.data && json.data.message) || i18n('error'), false);
					return;
				}
				var msg = (json.data && json.data.message) || i18n('success').replace('%s', json.data.order || '');
				showMsg(msg, true);
				if (json.data && json.data.balance) {
					setBalance(json.data.balance);
				}
				if (link) {
					link.value = '';
				}
				if (qty) {
					qty.value = '';
				}
				updateCharge();
			}).catch(function () {
				showMsg(i18n('error'), false);
			}).finally(function () {
				if (submit) {
					submit.disabled = false;
					submit.textContent = i18n('submit');
				}
			});
		});
	}

	document.addEventListener('DOMContentLoaded', function () {
		setBalance(cfg.balance || {});
		bind();
		loadServices(false);
		post('wifl_smm_balance').then(function (json) {
			if (json && json.success) {
				setBalance(json.data);
			}
		});
	});
})();
