<?php
/**
 * Login and registration forms (combined on one page).
 *
 * @package WIFL
 */

namespace WIFL\Member;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Forms {

	/**
	 * @var Forms|null
	 */
	private static $instance = null;

	/**
	 * @var string
	 */
	private $notice = '';

	/**
	 * @var string
	 */
	private $notice_type = 'error';

	/**
	 * @var string login|register
	 */
	private $active_panel = 'login';

	/**
	 * @return Forms
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'handle_submissions' ), 20 );
	}

	/**
	 * @return array
	 */
	public static function default_settings() {
		return array(
			'layout'      => 'split',
			'show_logo'   => 'yes',
			'view'        => 'login',
			'full_height' => 'yes',
		);
	}

	/**
	 * Content keys the widget (or shortcode) may override.
	 *
	 * @return array
	 */
	public static function overridable_content_keys() {
		return array(
			'membership_name',
			'brand_color',
			'enable_registration',
			'login_title',
			'login_subtitle',
			'login_email_placeholder',
			'login_password_placeholder',
			'login_remember_text',
			'login_button',
			'login_footer_text',
			'login_footer_link',
			'register_title',
			'register_subtitle',
			'register_email_placeholder',
			'register_password_placeholder',
			'register_confirm_placeholder',
			'register_button',
			'register_footer_text',
			'register_footer_link',
			'promo_quote',
			'promo_author',
			'promo_author_name',
			'promo_author_subtitle',
			'promo_avatar_badge',
			'promo_social_proof',
			'promo_status',
			'promo_footer_label',
			'promo_you_label',
		);
	}

	/**
	 * @param array $settings Base settings.
	 * @param array $atts     Widget / shortcode attributes.
	 * @return array
	 */
	public static function merge_content_settings( $settings, $atts ) {
		foreach ( self::overridable_content_keys() as $key ) {
			if ( isset( $atts[ $key ] ) && '' !== $atts[ $key ] ) {
				$settings[ $key ] = $atts[ $key ];
			}
		}

		if ( isset( $atts['show_remember'] ) ) {
			$settings['show_remember'] = $atts['show_remember'];
		}

		if ( array_key_exists( 'enable_registration', $atts ) ) {
			$settings['enable_registration'] = ( 'yes' === $atts['enable_registration'] ) ? 'yes' : 'no';
		}

		foreach ( array( 'login_redirect_url', 'register_redirect_url' ) as $redirect_key ) {
			if ( ! empty( $atts[ $redirect_key ] ) ) {
				$settings[ $redirect_key ] = esc_url_raw( $atts[ $redirect_key ] );
			}
		}

		// Subscription buy / other gated flows: ?wifl_redirect=...
		if ( ! empty( $_GET['wifl_redirect'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$pending = esc_url_raw( wp_unslash( $_GET['wifl_redirect'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( $pending && wp_validate_redirect( $pending, false ) ) {
				$settings['login_redirect_url']    = $pending;
				$settings['register_redirect_url'] = $pending;
			}
		}

		return $settings;
	}

	/**
	 * @param array $settings Base settings.
	 * @param array $atts     Widget / shortcode attributes.
	 * @return array
	 */
	public static function merge_promo_runtime_settings( $settings, $atts ) {
		if ( ! empty( $atts['promo_slides'] ) && is_array( $atts['promo_slides'] ) ) {
			$settings['promo_slides'] = $atts['promo_slides'];
		}

		foreach ( array( 'promo_autoplay', 'promo_autoplay_speed', 'promo_slide_effect' ) as $key ) {
			if ( isset( $atts[ $key ] ) && '' !== $atts[ $key ] ) {
				$settings[ $key ] = $atts[ $key ];
			}
		}

		if ( ! empty( $atts['promo_faces'] ) && is_array( $atts['promo_faces'] ) ) {
			$settings['promo_faces'] = $atts['promo_faces'];
		}

		for ( $i = 1; $i <= 4; $i++ ) {
			$key = 'promo_face_' . $i;
			if ( ! empty( $atts[ $key ] ) ) {
				$settings[ $key ] = $atts[ $key ];
			}
		}

		return $settings;
	}

	public function handle_submissions() {
		if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			return;
		}

		if ( isset( $_POST['wifl_member_login'] ) ) {
			$this->active_panel = 'login';
			$this->process_login();
		}

		if ( isset( $_POST['wifl_member_register'] ) ) {
			$this->active_panel = 'register';
			$this->process_register();
		}
	}

	private function process_login() {
		if ( ! isset( $_POST['wifl_member_login_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_member_login_nonce'] ) ), 'wifl_member_login' ) ) {
			$this->set_notice( __( 'Security check failed. Please try again.', 'woo-instagram-follower' ) );
			return;
		}

		$email    = isset( $_POST['wifl_email'] ) ? sanitize_email( wp_unslash( $_POST['wifl_email'] ) ) : '';
		$password = isset( $_POST['wifl_password'] ) ? (string) wp_unslash( $_POST['wifl_password'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( ! is_email( $email ) || '' === $password ) {
			$this->set_notice( __( 'Please enter a valid email and password.', 'woo-instagram-follower' ) );
			return;
		}

		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			$this->set_notice( __( 'Invalid email or password.', 'woo-instagram-follower' ) );
			return;
		}

		$signon = wp_signon(
			array(
				'user_login'    => $user->user_login,
				'user_password' => $password,
				'remember'      => ! empty( $_POST['wifl_remember'] ),
			),
			is_ssl()
		);

		if ( is_wp_error( $signon ) ) {
			$this->set_notice( $signon->get_error_message() );
			return;
		}

		wp_safe_redirect( self::safe_auth_redirect( 'login' ) );
		exit;
	}

	private function process_register() {
		if ( 'yes' !== Settings::get()['enable_registration'] ) {
			$this->set_notice( __( 'Registration is currently disabled.', 'woo-instagram-follower' ) );
			return;
		}

		if ( ! isset( $_POST['wifl_member_register_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_member_register_nonce'] ) ), 'wifl_member_register' ) ) {
			$this->set_notice( __( 'Security check failed. Please try again.', 'woo-instagram-follower' ) );
			return;
		}

		$email    = isset( $_POST['wifl_email'] ) ? sanitize_email( wp_unslash( $_POST['wifl_email'] ) ) : '';
		$password = isset( $_POST['wifl_password'] ) ? (string) wp_unslash( $_POST['wifl_password'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$confirm  = isset( $_POST['wifl_password_confirm'] ) ? (string) wp_unslash( $_POST['wifl_password_confirm'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( ! is_email( $email ) ) {
			$this->set_notice( __( 'Please enter a valid email address.', 'woo-instagram-follower' ) );
			return;
		}

		if ( email_exists( $email ) ) {
			$this->set_notice( __( 'An account with this email already exists.', 'woo-instagram-follower' ) );
			return;
		}

		if ( strlen( $password ) < 8 ) {
			$this->set_notice( __( 'Password must be at least 8 characters.', 'woo-instagram-follower' ) );
			return;
		}

		if ( $password !== $confirm ) {
			$this->set_notice( __( 'Passwords do not match.', 'woo-instagram-follower' ) );
			return;
		}

		$username = sanitize_user( current( explode( '@', $email ) ), true );
		if ( username_exists( $username ) ) {
			$username = sanitize_user( $username . wp_rand( 100, 999 ), true );
		}

		$user_id = wp_create_user( $username, $password, $email );
		if ( is_wp_error( $user_id ) ) {
			$this->set_notice( $user_id->get_error_message() );
			return;
		}

		wp_update_user(
			array(
				'ID'   => $user_id,
				'role' => 'customer',
			)
		);

		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, true );

		wp_safe_redirect( self::safe_auth_redirect( 'register' ) );
		exit;
	}

	/**
	 * @param string $message Message.
	 * @param string $type    Type.
	 */
	private function set_notice( $message, $type = 'error' ) {
		$this->notice      = $message;
		$this->notice_type = $type;
	}

	/**
	 * Resolve a safe post-auth redirect URL.
	 *
	 * @param string $context login|register.
	 * @return string
	 */
	private static function safe_auth_redirect( $context ) {
		$post_key = 'login' === $context ? 'wifl_login_redirect' : 'wifl_register_redirect';
		if ( isset( $_POST[ $post_key ] ) ) {
			$post_url = esc_url_raw( wp_unslash( $_POST[ $post_key ] ) );
			if ( $post_url ) {
				return self::finalize_redirect_url( $post_url, $context );
			}
		}

		$url = Settings::redirect_url( $context );
		$url = apply_filters( 'wifl_member_' . $context . '_redirect', $url );

		if ( empty( $url ) ) {
			$url = Settings::dashboard_url();
		}

		return self::finalize_redirect_url( $url, $context );
	}

	/**
	 * @param string $url     Candidate URL.
	 * @param string $context login|register.
	 * @return string
	 */
	private static function finalize_redirect_url( $url, $context ) {
		unset( $context );

		if ( empty( $url ) ) {
			$url = Settings::dashboard_url();
		}

		// Allow returning to subscription buy / cart after auth.
		if ( $url && false !== strpos( $url, 'wifl_sub_buy=' ) ) {
			$validated = wp_validate_redirect( $url, false );
			if ( $validated ) {
				return $validated;
			}
		}

		$login_url = Settings::login_url();
		if ( untrailingslashit( $url ) === untrailingslashit( $login_url ) ) {
			$url = Settings::dashboard_url();
		}

		if ( empty( $url ) || untrailingslashit( $url ) === untrailingslashit( home_url( '/' ) ) ) {
			$detected = Settings::detect_dashboard_page_url();
			if ( $detected ) {
				$url = $detected;
			}
		}

		$auth_urls = array(
			Settings::login_url(),
			Settings::register_url(),
		);
		foreach ( $auth_urls as $auth_url ) {
			if ( $auth_url && untrailingslashit( $auth_url ) === untrailingslashit( $url ) ) {
				$detected = Settings::detect_dashboard_page_url();
				$url      = $detected ? $detected : $url;
				break;
			}
		}

		return $url ? $url : home_url( '/' );
	}

	/**
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function render( $atts ) {
		if ( ! Member::can_show_login_form() ) {
			return '';
		}

		$atts = wp_parse_args( $atts, self::default_settings() );
		if ( ! empty( $atts['view'] ) && 'register' === $atts['view'] ) {
			$this->active_panel = 'register';
		}

		return $this->render_combined( $atts );
	}

	/**
	 * @param array $atts Attributes.
	 * @return string
	 */
	private function render_combined( $atts ) {
		$settings = self::merge_content_settings( Settings::get(), $atts );
		$settings = self::merge_promo_runtime_settings( $settings, $atts );
		$layout   = ( 'split' === ( $atts['layout'] ?? 'split' ) ) ? 'split' : 'default';
		$active   = in_array( $this->active_panel, array( 'login', 'register' ), true ) ? $this->active_panel : 'login';

		if ( ! empty( $_GET['wifl_auth'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$auth = sanitize_key( wp_unslash( $_GET['wifl_auth'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( in_array( $auth, array( 'login', 'register' ), true ) ) {
				$active = $auth;
			}
		}

		$classes = array(
			'wifl-member-form',
			'wifl-member-form--combined',
			'wifl-member-form--' . sanitize_html_class( $layout ),
		);

		if ( 'yes' === ( $atts['full_height'] ?? 'no' ) ) {
			$classes[] = 'wifl-member-form--full-height';
		}

		$style = '--wifl-member-brand:' . esc_attr( $settings['brand_color'] ) . ';';

		ob_start();
		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-active-panel="<?php echo esc_attr( $active ); ?>" style="<?php echo esc_attr( $style ); ?>">
			<div class="wifl-member-form__layout">
				<div class="wifl-member-form__main">
					<div class="wifl-member-form__card">
						<?php echo $this->render_brand( $settings, $atts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

						<div class="wifl-member-panel wifl-member-panel--login" data-panel="login">
							<h2 class="wifl-member-form__title"><?php echo esc_html( $settings['login_title'] ); ?></h2>
							<p class="wifl-member-form__subtitle"><?php echo esc_html( $settings['login_subtitle'] ); ?></p>
							<?php echo $this->render_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php $this->render_login_fields( $settings ); ?>
							<p class="wifl-member-form__footer">
								<?php echo esc_html( $settings['login_footer_text'] ); ?>
								<button type="button" class="wifl-member-switch" data-target="register"><?php echo esc_html( $settings['login_footer_link'] ); ?></button>
							</p>
						</div>

						<div class="wifl-member-panel wifl-member-panel--register" data-panel="register">
							<h2 class="wifl-member-form__title"><?php echo esc_html( $settings['register_title'] ); ?></h2>
							<p class="wifl-member-form__subtitle"><?php echo esc_html( $settings['register_subtitle'] ); ?></p>
							<?php echo 'register' === $active ? $this->render_notice() : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php
							if ( 'yes' === $settings['enable_registration'] ) {
								$this->render_register_fields( $settings );
							} else {
								echo '<p class="wifl-member-notice wifl-member-notice--error">' . esc_html__( 'Registration is currently disabled.', 'woo-instagram-follower' ) . '</p>';
							}
							?>
							<p class="wifl-member-form__footer">
								<?php echo esc_html( $settings['register_footer_text'] ); ?>
								<button type="button" class="wifl-member-switch" data-target="login"><?php echo esc_html( $settings['register_footer_link'] ); ?></button>
							</p>
						</div>
					</div>
				</div>

				<?php if ( 'split' === $layout ) : ?>
					<?php echo $this->render_promo_panel( $settings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * @param array $settings Settings.
	 * @param array $atts     Attributes.
	 * @return string
	 */
	private function render_brand( $settings, $atts ) {
		if ( 'yes' !== ( $atts['show_logo'] ?? 'yes' ) ) {
			return '';
		}

		$logo_url = ! empty( $atts['logo_url'] ) ? $atts['logo_url'] : ( $settings['logo_url'] ?? '' );
		if ( $logo_url ) {
			return '<div class="wifl-member-form__logo"><img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( $settings['membership_name'] ) . '" /></div>';
		}

		return '<div class="wifl-member-form__brand">' . esc_html( $settings['membership_name'] ) . '</div>';
	}

	/**
	 * @return string
	 */
	private function render_notice() {
		if ( ! $this->notice ) {
			return '';
		}
		return '<div class="wifl-member-notice wifl-member-notice--' . esc_attr( $this->notice_type ) . '">' . esc_html( $this->notice ) . '</div>';
	}

	/**
	 * @param array $settings Settings.
	 */
	private function render_login_fields( $settings ) {
		$email_ph = ! empty( $settings['login_email_placeholder'] ) ? $settings['login_email_placeholder'] : __( 'Email address', 'woo-instagram-follower' );
		$pass_ph  = ! empty( $settings['login_password_placeholder'] ) ? $settings['login_password_placeholder'] : __( 'Password', 'woo-instagram-follower' );
		$remember = ! empty( $settings['login_remember_text'] ) ? $settings['login_remember_text'] : __( 'Remember me', 'woo-instagram-follower' );
		$show_remember = ! isset( $settings['show_remember'] ) || 'yes' === $settings['show_remember'];
		?>
		<form class="wifl-member-form__fields" method="post" novalidate>
			<?php wp_nonce_field( 'wifl_member_login', 'wifl_member_login_nonce' ); ?>
			<input type="hidden" name="wifl_member_login" value="1" />
			<?php if ( ! empty( $settings['login_redirect_url'] ) ) : ?>
				<input type="hidden" name="wifl_login_redirect" value="<?php echo esc_url( $settings['login_redirect_url'] ); ?>" />
			<?php endif; ?>

			<label class="wifl-member-field">
				<span class="wifl-member-field__icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="M4 8l8 5 8-5"/></svg>
				</span>
				<span class="screen-reader-text"><?php echo esc_html( $email_ph ); ?></span>
				<input type="email" name="wifl_email" class="wifl-member-field__input" placeholder="<?php echo esc_attr( $email_ph ); ?>" required autocomplete="email" />
			</label>

			<label class="wifl-member-field wifl-member-field--password">
				<span class="wifl-member-field__icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
				</span>
				<span class="screen-reader-text"><?php echo esc_html( $pass_ph ); ?></span>
				<input type="password" name="wifl_password" class="wifl-member-field__input" placeholder="<?php echo esc_attr( $pass_ph ); ?>" required autocomplete="current-password" />
				<button type="button" class="wifl-member-field__toggle" aria-label="<?php esc_attr_e( 'Show password', 'woo-instagram-follower' ); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
				</button>
			</label>

			<?php if ( $show_remember ) : ?>
			<label class="wifl-member-remember">
				<input type="checkbox" name="wifl_remember" value="1" />
				<?php echo esc_html( $remember ); ?>
			</label>
			<?php endif; ?>

			<button type="submit" class="wifl-member-btn"><?php echo esc_html( $settings['login_button'] ); ?></button>
		</form>
		<?php
	}

	/**
	 * @param array $settings Settings.
	 */
	private function render_register_fields( $settings ) {
		$email_ph   = ! empty( $settings['register_email_placeholder'] ) ? $settings['register_email_placeholder'] : __( 'Email address', 'woo-instagram-follower' );
		$pass_ph    = ! empty( $settings['register_password_placeholder'] ) ? $settings['register_password_placeholder'] : __( 'Create a password', 'woo-instagram-follower' );
		$confirm_ph = ! empty( $settings['register_confirm_placeholder'] ) ? $settings['register_confirm_placeholder'] : __( 'Confirm password', 'woo-instagram-follower' );
		?>
		<form class="wifl-member-form__fields" method="post" novalidate>
			<?php wp_nonce_field( 'wifl_member_register', 'wifl_member_register_nonce' ); ?>
			<input type="hidden" name="wifl_member_register" value="1" />
			<?php if ( ! empty( $settings['register_redirect_url'] ) ) : ?>
				<input type="hidden" name="wifl_register_redirect" value="<?php echo esc_url( $settings['register_redirect_url'] ); ?>" />
			<?php endif; ?>

			<label class="wifl-member-field">
				<span class="wifl-member-field__icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="M4 8l8 5 8-5"/></svg>
				</span>
				<span class="screen-reader-text"><?php echo esc_html( $email_ph ); ?></span>
				<input type="email" name="wifl_email" class="wifl-member-field__input" placeholder="<?php echo esc_attr( $email_ph ); ?>" required autocomplete="email" />
			</label>

			<label class="wifl-member-field wifl-member-field--password">
				<span class="wifl-member-field__icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
				</span>
				<span class="screen-reader-text"><?php echo esc_html( $pass_ph ); ?></span>
				<input type="password" name="wifl_password" class="wifl-member-field__input" placeholder="<?php echo esc_attr( $pass_ph ); ?>" required autocomplete="new-password" minlength="8" />
				<button type="button" class="wifl-member-field__toggle" aria-label="<?php esc_attr_e( 'Show password', 'woo-instagram-follower' ); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
				</button>
			</label>

			<label class="wifl-member-field wifl-member-field--password">
				<span class="wifl-member-field__icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
				</span>
				<span class="screen-reader-text"><?php echo esc_html( $confirm_ph ); ?></span>
				<input type="password" name="wifl_password_confirm" class="wifl-member-field__input" placeholder="<?php echo esc_attr( $confirm_ph ); ?>" required autocomplete="new-password" minlength="8" />
				<button type="button" class="wifl-member-field__toggle" aria-label="<?php esc_attr_e( 'Show password', 'woo-instagram-follower' ); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
				</button>
			</label>

			<button type="submit" class="wifl-member-btn"><?php echo esc_html( $settings['register_button'] ); ?></button>
		</form>
		<?php
	}

	/**
	 * @param array $settings Settings.
	 * @return string
	 */
	private function render_promo_panel( $settings ) {
		$slides      = $this->promo_slides_data( $settings );
		$slide_count = count( $slides );
		$you_label   = ! empty( $settings['promo_you_label'] ) ? $settings['promo_you_label'] : 'you?';
		$faces       = $this->promo_face_urls( $settings );
		$autoplay    = ! isset( $settings['promo_autoplay'] ) || 'yes' === $settings['promo_autoplay'];
		$speed       = ! empty( $settings['promo_autoplay_speed'] ) ? absint( $settings['promo_autoplay_speed'] ) : 2000;
		$effect      = ! empty( $settings['promo_slide_effect'] ) ? sanitize_key( $settings['promo_slide_effect'] ) : 'reveal';
		if ( ! in_array( $effect, array( 'fade', 'slide', 'reveal' ), true ) ) {
			$effect = 'reveal';
		}

		ob_start();
		?>
		<aside class="wifl-member-form__promo" aria-label="<?php esc_attr_e( 'Social proof', 'woo-instagram-follower' ); ?>">
			<div class="wifl-member-promo__shell">
				<div
					class="wifl-member-promo__slider<?php echo $slide_count > 1 ? ' wifl-member-promo__slider--ready' : ''; ?>"
					data-effect="<?php echo esc_attr( $effect ); ?>"
					data-autoplay="<?php echo $autoplay && $slide_count > 1 ? 'yes' : 'no'; ?>"
					data-autoplay-speed="<?php echo esc_attr( max( 1500, $speed ) ); ?>"
				>
					<div class="wifl-member-promo__viewport">
						<div class="wifl-member-promo__track">
							<?php foreach ( $slides as $index => $slide ) : ?>
								<div class="wifl-member-promo__slide<?php echo 0 === $index ? ' is-active' : ''; ?>" data-index="<?php echo esc_attr( $index ); ?>">
									<?php echo $this->render_promo_slide_card( $slide ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
					<?php if ( $slide_count > 1 ) : ?>
						<div class="wifl-member-promo__dots" role="tablist" aria-label="<?php esc_attr_e( 'Testimonials', 'woo-instagram-follower' ); ?>">
							<?php foreach ( $slides as $index => $slide ) : ?>
								<button
									type="button"
									class="wifl-member-promo__dot<?php echo 0 === $index ? ' is-active' : ''; ?>"
									role="tab"
									aria-label="<?php echo esc_attr( sprintf( __( 'Slide %d', 'woo-instagram-follower' ), $index + 1 ) ); ?>"
									aria-selected="<?php echo 0 === $index ? 'true' : 'false'; ?>"
									data-index="<?php echo esc_attr( $index ); ?>"
								></button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>

				<div class="wifl-member-promo__community">
					<div class="wifl-member-promo__faces" aria-hidden="true">
						<?php
						$face_count = count( $faces );
						foreach ( $faces as $index => $face_url ) :
							$color_index = ( $index % 4 ) + 1;
							?>
							<span
								class="wifl-member-promo__face wifl-member-promo__face--<?php echo esc_attr( $color_index ); ?><?php echo $face_url ? '' : ' wifl-member-promo__face--placeholder'; ?>"
								style="z-index: <?php echo esc_attr( $face_count - $index ); ?>;"
							>
								<?php if ( $face_url ) : ?>
									<img class="wifl-member-promo__face-img" src="<?php echo esc_url( $face_url ); ?>" alt="" width="40" height="40" loading="lazy" decoding="async" />
								<?php endif; ?>
							</span>
						<?php endforeach; ?>
						<span class="wifl-member-promo__you" style="z-index: <?php echo esc_attr( $face_count + 1 ); ?>;">
							<span class="wifl-member-promo__you-text"><?php echo esc_html( $you_label ); ?></span>
						</span>
					</div>
					<?php if ( ! empty( $settings['promo_social_proof'] ) ) : ?>
						<p class="wifl-member-promo__social"><?php echo wp_kses( $settings['promo_social_proof'], $this->promo_social_allowed_html() ); ?></p>
					<?php endif; ?>
				</div>

				<?php if ( ! empty( $settings['promo_status'] ) ) : ?>
					<span class="wifl-member-promo__status">
						<span class="wifl-member-promo__status-dot" aria-hidden="true"></span>
						<?php echo esc_html( $settings['promo_status'] ); ?>
					</span>
				<?php endif; ?>

				<div class="wifl-member-promo__footer">
					<?php if ( ! empty( $settings['promo_footer_label'] ) ) : ?>
						<span class="wifl-member-promo__footer-label"><?php echo esc_html( $settings['promo_footer_label'] ); ?></span>
					<?php endif; ?>
					<div class="wifl-member-promo__platforms" aria-hidden="true">
						<?php echo $this->promo_platform_icons(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
				</div>
			</div>
		</aside>
		<?php
		return ob_get_clean();
	}

	/**
	 * @param array $slide Slide data.
	 * @return string
	 */
	private function render_promo_slide_card( $slide ) {
		ob_start();
		?>
		<article class="wifl-member-promo__card">
			<blockquote class="wifl-member-promo__quote">&ldquo;<?php echo esc_html( $slide['quote'] ); ?>&rdquo;</blockquote>
			<figcaption class="wifl-member-promo__caption">
				<span class="wifl-member-promo__author">
					<span class="wifl-member-promo__avatar" aria-hidden="true"><?php echo esc_html( $slide['avatar_badge'] ); ?></span>
					<span class="wifl-member-promo__author-copy">
						<span class="wifl-member-promo__author-name"><?php echo esc_html( $slide['author_name'] ); ?></span>
						<?php if ( ! empty( $slide['author_subtitle'] ) ) : ?>
							<span class="wifl-member-promo__author-role"><?php echo esc_html( $slide['author_subtitle'] ); ?></span>
						<?php endif; ?>
					</span>
				</span>
				<span class="wifl-member-promo__verified">
					<?php echo $this->promo_verified_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php esc_html_e( 'Verified', 'woo-instagram-follower' ); ?>
				</span>
			</figcaption>
		</article>
		<?php
		return ob_get_clean();
	}

	/**
	 * @param array $settings Settings.
	 * @return array
	 */
	private function promo_slides_data( $settings ) {
		if ( ! empty( $settings['promo_slides'] ) && is_array( $settings['promo_slides'] ) ) {
			$slides = array();
			foreach ( $settings['promo_slides'] as $slide ) {
				if ( ! is_array( $slide ) ) {
					continue;
				}
				$quote = isset( $slide['slide_quote'] ) ? trim( $slide['slide_quote'] ) : '';
				if ( '' === $quote ) {
					continue;
				}
				$slides[] = array(
					'quote'           => $quote,
					'author_name'     => isset( $slide['slide_author_name'] ) ? $slide['slide_author_name'] : '',
					'author_subtitle' => isset( $slide['slide_author_subtitle'] ) ? $slide['slide_author_subtitle'] : '',
					'avatar_badge'    => ! empty( $slide['slide_avatar_badge'] ) ? $slide['slide_avatar_badge'] : (string) ( count( $slides ) + 1 ),
				);
			}
			if ( ! empty( $slides ) ) {
				return $slides;
			}
		}

		return array(
			array(
				'quote'           => $settings['promo_quote'] ?? '',
				'author_name'     => ! empty( $settings['promo_author_name'] ) ? $settings['promo_author_name'] : $this->promo_author_name( $settings ),
				'author_subtitle' => ! empty( $settings['promo_author_subtitle'] ) ? $settings['promo_author_subtitle'] : $this->promo_author_subtitle( $settings ),
				'avatar_badge'    => ! empty( $settings['promo_avatar_badge'] ) ? $settings['promo_avatar_badge'] : '1',
			),
		);
	}

	/**
	 * @return string
	 */
	private function promo_verified_icon() {
		return '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 256 256" aria-hidden="true"><path d="M225.86,102.82c-3.77-3.94-7.67-8-9.14-11.57-1.36-3.27-1.44-8.69-1.52-13.94-.15-9.76-.31-20.82-8-28.51s-18.75-7.85-28.51-8c-5.25-.08-10.67-.16-13.94-1.52-3.56-1.47-7.63-5.37-11.57-9.14C146.28,23.51,138.44,16,128,16s-18.27,7.51-25.18,14.14c-3.94,3.77-8,7.67-11.57,9.14C88,40.64,82.56,40.72,77.31,40.8c-9.76.15-20.82.31-28.51,8S41,67.55,40.8,77.31c-.08,5.25-.16,10.67-1.52,13.94-1.47,3.56-5.37,7.63-9.14,11.57C23.51,109.72,16,117.56,16,128s7.51,18.27,14.14,25.18c3.77,3.94,7.67,8,9.14,11.57,1.36,3.27,1.44,8.69,1.52,13.94.15,9.76.31,20.82,8,28.51s18.75,7.85,28.51,8c5.25.08,10.67.16,13.94,1.52,3.56,1.47,7.63,5.37,11.57,9.14C109.72,232.49,117.56,240,128,240s18.27-7.51,25.18-14.14c3.94-3.77,8-7.67,11.57-9.14,3.27-1.36,8.69-1.44,13.94-1.52,9.76-.15,20.82-.31,28.51-8s7.85-18.75,8-28.51c.08-5.25.16-10.67,1.52-13.94,1.47-3.56,5.37-7.63,9.14-11.57C232.49,146.28,240,138.44,240,128S232.49,109.73,225.86,102.82Zm-52.2,6.84-56,56a8,8,0,0,1-11.32,0l-24-24a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35a8,8,0,0,1,11.32,11.32Z"></path></svg>';
	}

	/**
	 * @return string
	 */
	private function promo_platform_icons() {
		return '<span class="wifl-member-promo__platform-icon" aria-label="Instagram"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 256 256"><path d="M176,24H80A56.06,56.06,0,0,0,24,80v96a56.06,56.06,0,0,0,56,56h96a56.06,56.06,0,0,0,56-56V80A56.06,56.06,0,0,0,176,24ZM128,176a48,48,0,1,1,48-48A48.05,48.05,0,0,1,128,176Zm60-96a12,12,0,1,1,12-12A12,12,0,0,1,188,80Zm-28,48a32,32,0,1,1-32-32A32,32,0,0,1,160,128Z"></path></svg></span><span class="wifl-member-promo__platform-icon" aria-label="TikTok"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 256 256"><path d="M232,80v40a8,8,0,0,1-8,8,103.25,103.25,0,0,1-48-11.71V156a76,76,0,0,1-152,0c0-36.9,26.91-69.52,62.6-75.88A8,8,0,0,1,96,88v42.69a8,8,0,0,1-4.57,7.23A20,20,0,1,0,120,156V24a8,8,0,0,1,8-8h40a8,8,0,0,1,8,8,48.05,48.05,0,0,0,48,48A8,8,0,0,1,232,80Z"></path></svg></span><span class="wifl-member-promo__platform-icon" aria-label="YouTube"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 256 256"><path d="M234.33,69.52a24,24,0,0,0-14.49-16.4C185.56,39.88,131,40,128,40s-57.56-.12-91.84,13.12a24,24,0,0,0-14.49,16.4C19.08,79.5,16,97.74,16,128s3.08,48.5,5.67,58.48a24,24,0,0,0,14.49,16.41C69,215.56,120.4,216,127.34,216h1.32c6.94,0,58.37-.44,91.18-13.11a24,24,0,0,0,14.49-16.41c2.59-10,5.67-28.22,5.67-58.48S236.92,79.5,234.33,69.52Zm-73.74,65-40,28A8,8,0,0,1,108,156V100a8,8,0,0,1,12.59-6.55l40,28a8,8,0,0,1,0,13.1Z"></path></svg></span>';
	}

	/**
	 * @return array
	 */
	private function promo_social_allowed_html() {
		return array(
			'span'   => array( 'class' => true ),
			'strong' => array(),
			'b'      => array(),
			'em'     => array(),
		);
	}

	/**
	 * @param array $settings Settings.
	 * @return array
	 */
	private function promo_face_urls( $settings ) {
		if ( ! empty( $settings['promo_faces'] ) && is_array( $settings['promo_faces'] ) ) {
			$faces = array();
			foreach ( $settings['promo_faces'] as $face ) {
				if ( ! is_array( $face ) ) {
					continue;
				}
				$faces[] = $this->resolve_media_url( $face['face_image'] ?? '' );
			}
			if ( ! empty( $faces ) ) {
				return $faces;
			}
		}

		$faces = array();
		for ( $i = 1; $i <= 4; $i++ ) {
			$key = 'promo_face_' . $i;
			$faces[] = $this->resolve_media_url( $settings[ $key ] ?? '' );
		}
		return $faces;
	}

	/**
	 * @param array|string $media Media control value.
	 * @return string
	 */
	private function resolve_media_url( $media ) {
		$url = '';
		if ( ! empty( $media ) ) {
			if ( is_array( $media ) ) {
				if ( ! empty( $media['url'] ) ) {
					$url = $media['url'];
				} elseif ( ! empty( $media['id'] ) ) {
					$url = wp_get_attachment_image_url( (int) $media['id'], 'thumbnail' );
					if ( ! $url ) {
						$url = wp_get_attachment_url( (int) $media['id'] );
					}
				}
			} else {
				$url = (string) $media;
			}
		}
		return $url ? esc_url_raw( $url ) : '';
	}

	/**
	 * @param array $settings Settings.
	 * @return string
	 */
	private function promo_author_name( $settings ) {
		if ( ! empty( $settings['promo_author'] ) && false !== strpos( $settings['promo_author'], ' / ' ) ) {
			return trim( explode( ' / ', $settings['promo_author'], 2 )[0] );
		}
		return $settings['promo_author'] ?? '';
	}

	/**
	 * @param array $settings Settings.
	 * @return string
	 */
	private function promo_author_subtitle( $settings ) {
		if ( ! empty( $settings['promo_author'] ) && false !== strpos( $settings['promo_author'], ' / ' ) ) {
			return trim( explode( ' / ', $settings['promo_author'], 2 )[1] );
		}
		return '';
	}
}
