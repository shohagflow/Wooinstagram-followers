<?php
/**
 * Subscription plans storage (admin + frontend widget).
 *
 * @package WIFL
 */

namespace WIFL\Member;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Subscriptions {

	const OPTION = 'wifl_subscription_plans';

	/**
	 * @return array
	 */
	public static function defaults() {
		$features = "Up to 4 posts per day\nReal likes from real users\nFree views on all videos\nSafe & secure\n24/7 customer support";

		return array(
			array(
				'id'          => 'sub-1000',
				'name'        => 'Starter Likes',
				'kicker'      => 'INSTAGRAM • HIGH QUALITY',
				'badge'       => 'GREAT VALUE',
				'qty'         => '1,000',
				'qty_label'   => 'likes per post',
				'price'       => '99.99',
				'period'      => '/mo',
				'unit_price'  => '$0.0008 per like*',
				'features'    => $features,
				'button_text' => 'get start',
				'button_url'  => '',
				'footer'      => '30-day money back guarantee',
				'featured'    => 'no',
				'status'      => 'active',
			),
			array(
				'id'          => 'sub-1500',
				'name'        => 'Growth Likes',
				'kicker'      => 'INSTAGRAM • HIGH QUALITY',
				'badge'       => '',
				'qty'         => '1,500',
				'qty_label'   => 'likes per post',
				'price'       => '139.99',
				'period'      => '/mo',
				'unit_price'  => '$0.0008 per like*',
				'features'    => $features,
				'button_text' => 'get start',
				'button_url'  => '',
				'footer'      => '30-day money back guarantee',
				'featured'    => 'yes',
				'status'      => 'active',
			),
			array(
				'id'          => 'sub-2500',
				'name'        => 'Pro Likes',
				'kicker'      => 'INSTAGRAM • HIGH QUALITY',
				'badge'       => 'BEST RATE',
				'qty'         => '2,500',
				'qty_label'   => 'likes per post',
				'price'       => '199.99',
				'period'      => '/mo',
				'unit_price'  => '$0.0008 per like*',
				'features'    => $features,
				'button_text' => 'get start',
				'button_url'  => '',
				'footer'      => '30-day money back guarantee',
				'featured'    => 'no',
				'status'      => 'active',
			),
		);
	}

	/**
	 * @return array
	 */
	public static function get_plans() {
		$saved = get_option( self::OPTION, null );
		if ( ! is_array( $saved ) ) {
			return self::defaults();
		}

		$clean = array();
		foreach ( $saved as $plan ) {
			$normalized = self::normalize_plan( $plan );
			if ( $normalized ) {
				$clean[] = $normalized;
			}
		}

		return $clean;
	}

	/**
	 * Active plans formatted for the CT subscription widget.
	 *
	 * @return array
	 */
	public static function get_widget_plans() {
		$out = array();
		foreach ( self::get_plans() as $plan ) {
			if ( 'active' !== $plan['status'] ) {
				continue;
			}

			$out[] = array(
				'name'        => $plan['name'],
				'kicker'      => $plan['name'] ? $plan['name'] : $plan['kicker'],
				'badge'       => $plan['badge'],
				'qty'         => $plan['qty'],
				'qty_label'   => $plan['qty_label'],
				'price'       => $plan['price'],
				'period'      => $plan['period'],
				'unit_price'  => $plan['unit_price'],
				'features'    => $plan['features'],
				'button_text' => $plan['button_text'],
				'button_url'  => array( 'url' => $plan['button_url'] ? $plan['button_url'] : '#' ),
				'footer'      => $plan['footer'],
				'featured'    => $plan['featured'],
			);
		}

		return $out;
	}

	/**
	 * @return array
	 */
	public static function stats() {
		$plans    = self::get_plans();
		$featured = 0;
		$active   = 0;
		foreach ( $plans as $plan ) {
			if ( 'yes' === $plan['featured'] ) {
				$featured++;
			}
			if ( 'active' === $plan['status'] ) {
				$active++;
			}
		}

		return array(
			'total'    => count( $plans ),
			'active'   => $active,
			'featured' => $featured,
		);
	}

	/**
	 * @param mixed $plan Raw plan.
	 * @return array|null
	 */
	public static function normalize_plan( $plan ) {
		if ( ! is_array( $plan ) ) {
			return null;
		}

		$name = isset( $plan['name'] ) ? sanitize_text_field( $plan['name'] ) : '';
		$qty  = isset( $plan['qty'] ) ? sanitize_text_field( $plan['qty'] ) : '';
		if ( '' === $name && '' === $qty ) {
			return null;
		}

		$id = isset( $plan['id'] ) ? sanitize_key( $plan['id'] ) : '';
		if ( '' === $id ) {
			$id = 'sub-' . substr( md5( wp_json_encode( $plan ) . microtime() ), 0, 8 );
		}

		$features = isset( $plan['features'] ) ? $plan['features'] : '';
		if ( is_array( $features ) ) {
			$features = implode( "\n", array_map( 'sanitize_text_field', $features ) );
		} else {
			$features = sanitize_textarea_field( $features );
		}

		$status = isset( $plan['status'] ) ? sanitize_key( $plan['status'] ) : 'active';
		if ( ! in_array( $status, array( 'active', 'draft' ), true ) ) {
			$status = 'active';
		}

		return array(
			'id'          => $id,
			'name'        => $name ? $name : $qty,
			'kicker'      => isset( $plan['kicker'] ) ? sanitize_text_field( $plan['kicker'] ) : '',
			'badge'       => isset( $plan['badge'] ) ? sanitize_text_field( $plan['badge'] ) : '',
			'qty'         => $qty,
			'qty_label'   => isset( $plan['qty_label'] ) ? sanitize_text_field( $plan['qty_label'] ) : '',
			'price'       => isset( $plan['price'] ) ? sanitize_text_field( $plan['price'] ) : '',
			'period'      => isset( $plan['period'] ) ? sanitize_text_field( $plan['period'] ) : '/mo',
			'unit_price'  => isset( $plan['unit_price'] ) ? sanitize_text_field( $plan['unit_price'] ) : '',
			'features'    => $features,
			'button_text' => isset( $plan['button_text'] ) ? sanitize_text_field( $plan['button_text'] ) : 'get start',
			'button_url'  => isset( $plan['button_url'] ) ? esc_url_raw( $plan['button_url'] ) : '',
			'footer'      => isset( $plan['footer'] ) ? sanitize_text_field( $plan['footer'] ) : '',
			'featured'    => ( ! empty( $plan['featured'] ) && 'yes' === $plan['featured'] ) ? 'yes' : 'no',
			'status'      => $status,
		);
	}

	/**
	 * @param array $raw Raw plans.
	 * @return array
	 */
	public static function sanitize_plans( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $plan ) {
			$normalized = self::normalize_plan( $plan );
			if ( $normalized ) {
				$out[] = $normalized;
			}
		}

		return $out;
	}

	/**
	 * @return array
	 */
	public static function blank_plan() {
		return array(
			'id'          => '',
			'name'        => '',
			'kicker'      => 'INSTAGRAM • HIGH QUALITY',
			'badge'       => '',
			'qty'         => '',
			'qty_label'   => 'likes per post',
			'price'       => '',
			'period'      => '/mo',
			'unit_price'  => '',
			'features'    => '',
			'button_text' => 'get start',
			'button_url'  => '',
			'footer'      => '30-day money back guarantee',
			'featured'    => 'no',
			'status'      => 'active',
		);
	}
}
