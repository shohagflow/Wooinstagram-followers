<?php
/**
 * Membership settings storage.
 *
 * @package WIFL
 */

namespace WIFL\Member;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {

	const OPTION = 'wifl_member_settings';

	/**
	 * @return array
	 */
	public static function defaults() {
		return array(
			'membership_name'      => 'Membership',
			'enable_registration'  => 'yes',
			'login_page_url'       => '',
			'register_page_url'    => '',
			'dashboard_page_url'   => '',
			'login_redirect'       => '',
			'register_redirect'    => '',
			'logo_url'             => '',
			'brand_color'          => '#ff6b57',
			'promo_quote'          => 'Twicsy is a well-established and reputable site for buying Instagram followers and likes of the best quality.',
			'promo_author'         => '303 Magazine / Press review',
			'promo_author_name'    => '303 Magazine',
			'promo_author_subtitle'=> 'Press review',
			'promo_avatar_badge'   => '3',
			'promo_social_proof'   => 'Join <span class="wifl-member-promo__social-strong">1,000,000+ creators</span> today',
			'promo_status'         => 'All deliveries running',
			'promo_footer_label'   => "Grow on every platform you're on",
			'promo_you_label'      => 'you?',
			'login_title'          => 'Welcome back',
			'login_subtitle'       => 'Sign in to track your orders, subscriptions, and points.',
			'login_button'         => 'Sign in',
			'login_footer_text'    => "Don't have an account?",
			'login_footer_link'    => 'Create account',
			'register_title'       => 'Create your account',
			'register_subtitle'    => 'Track your orders, subscriptions, and points in one place.',
			'register_button'      => 'Create account',
			'register_footer_text' => 'Already have an account?',
			'register_footer_link' => 'Sign in',
		);
	}

	/**
	 * @return array
	 */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * @param array $raw Raw POST data.
	 * @return array
	 */
	public static function sanitize( $raw ) {
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		$out = array(
			'membership_name'      => isset( $raw['membership_name'] ) ? sanitize_text_field( $raw['membership_name'] ) : 'Membership',
			'enable_registration'  => ! empty( $raw['enable_registration'] ) ? 'yes' : 'no',
			'login_page_url'       => isset( $raw['login_page_url'] ) ? esc_url_raw( $raw['login_page_url'] ) : '',
			'register_page_url'    => isset( $raw['register_page_url'] ) ? esc_url_raw( $raw['register_page_url'] ) : '',
			'dashboard_page_url'   => isset( $raw['dashboard_page_url'] ) ? esc_url_raw( $raw['dashboard_page_url'] ) : '',
			'login_redirect'       => isset( $raw['login_redirect'] ) ? esc_url_raw( $raw['login_redirect'] ) : '',
			'register_redirect'    => isset( $raw['register_redirect'] ) ? esc_url_raw( $raw['register_redirect'] ) : '',
			'logo_url'             => isset( $raw['logo_url'] ) ? esc_url_raw( $raw['logo_url'] ) : '',
			'brand_color'          => self::hex( isset( $raw['brand_color'] ) ? $raw['brand_color'] : '#ff6b57' ),
			'promo_quote'          => isset( $raw['promo_quote'] ) ? sanitize_textarea_field( $raw['promo_quote'] ) : '',
			'promo_author'         => isset( $raw['promo_author'] ) ? sanitize_text_field( $raw['promo_author'] ) : '',
			'promo_author_name'    => isset( $raw['promo_author_name'] ) ? sanitize_text_field( $raw['promo_author_name'] ) : '',
			'promo_author_subtitle'=> isset( $raw['promo_author_subtitle'] ) ? sanitize_text_field( $raw['promo_author_subtitle'] ) : '',
			'promo_avatar_badge'   => isset( $raw['promo_avatar_badge'] ) ? sanitize_text_field( substr( $raw['promo_avatar_badge'], 0, 3 ) ) : '3',
			'promo_social_proof'   => isset( $raw['promo_social_proof'] ) ? wp_kses_post( $raw['promo_social_proof'] ) : '',
			'promo_status'         => isset( $raw['promo_status'] ) ? sanitize_text_field( $raw['promo_status'] ) : '',
			'promo_footer_label'   => isset( $raw['promo_footer_label'] ) ? sanitize_text_field( $raw['promo_footer_label'] ) : '',
			'promo_you_label'      => isset( $raw['promo_you_label'] ) ? sanitize_text_field( $raw['promo_you_label'] ) : 'you?',
			'login_title'          => isset( $raw['login_title'] ) ? sanitize_text_field( $raw['login_title'] ) : '',
			'login_subtitle'       => isset( $raw['login_subtitle'] ) ? sanitize_text_field( $raw['login_subtitle'] ) : '',
			'login_button'         => isset( $raw['login_button'] ) ? sanitize_text_field( $raw['login_button'] ) : '',
			'login_footer_text'    => isset( $raw['login_footer_text'] ) ? sanitize_text_field( $raw['login_footer_text'] ) : '',
			'login_footer_link'    => isset( $raw['login_footer_link'] ) ? sanitize_text_field( $raw['login_footer_link'] ) : '',
			'register_title'       => isset( $raw['register_title'] ) ? sanitize_text_field( $raw['register_title'] ) : '',
			'register_subtitle'    => isset( $raw['register_subtitle'] ) ? sanitize_text_field( $raw['register_subtitle'] ) : '',
			'register_button'      => isset( $raw['register_button'] ) ? sanitize_text_field( $raw['register_button'] ) : '',
			'register_footer_text' => isset( $raw['register_footer_text'] ) ? sanitize_text_field( $raw['register_footer_text'] ) : '',
			'register_footer_link' => isset( $raw['register_footer_link'] ) ? sanitize_text_field( $raw['register_footer_link'] ) : '',
		);

		if ( '' === $out['membership_name'] ) {
			$out['membership_name'] = 'Membership';
		}

		return $out;
	}

	/**
	 * @return string
	 */
	public static function login_url() {
		$s = self::get();
		if ( ! empty( $s['login_page_url'] ) ) {
			return $s['login_page_url'];
		}

		$detected = self::detect_login_page_url();
		if ( $detected ) {
			return $detected;
		}

		return home_url( '/' );
	}

	/**
	 * @return string
	 */
	public static function register_url() {
		$s = self::get();
		if ( ! empty( $s['register_page_url'] ) ) {
			return $s['register_page_url'];
		}

		$detected = self::detect_register_page_url();
		if ( $detected ) {
			return $detected;
		}

		return self::login_url();
	}

	/**
	 * @return string
	 */
	public static function dashboard_url() {
		$s = self::get();
		if ( ! empty( $s['dashboard_page_url'] ) ) {
			$page_id = url_to_postid( $s['dashboard_page_url'] );
			if ( $page_id && self::page_has_dashboard_marker( $page_id ) ) {
				return $s['dashboard_page_url'];
			}
		}

		$detected = self::detect_dashboard_page_url();
		if ( $detected ) {
			return $detected;
		}

		if ( ! empty( $s['register_redirect'] ) ) {
			return $s['register_redirect'];
		}
		if ( ! empty( $s['login_redirect'] ) ) {
			return $s['login_redirect'];
		}
		return home_url( '/' );
	}

	/**
	 * @param int $page_id Page ID.
	 * @return bool
	 */
	public static function page_has_dashboard_marker( $page_id ) {
		$page_id = absint( $page_id );
		if ( ! $page_id ) {
			return false;
		}

		$content = get_post_field( 'post_content', $page_id );
		if ( is_string( $content ) && has_shortcode( $content, 'wifl_dashboard' ) ) {
			return true;
		}

		return self::page_has_elementor_widget( $page_id, 'ct-member-dashboard' );
	}

	/**
	 * @param int $page_id Page ID.
	 * @return bool
	 */
	public static function page_has_auth_form_marker( $page_id ) {
		$page_id = absint( $page_id );
		if ( ! $page_id ) {
			return false;
		}

		if ( self::page_has_dashboard_marker( $page_id ) ) {
			return false;
		}

		$content = get_post_field( 'post_content', $page_id );
		if ( is_string( $content ) ) {
			if ( has_shortcode( $content, 'wifl_login' ) || has_shortcode( $content, 'wifl_register' ) ) {
				return true;
			}
		}

		return self::page_has_elementor_widget( $page_id, 'ct-member-login' );
	}

	/**
	 * @param int    $page_id     Page ID.
	 * @param string $widget_type Widget type.
	 * @return bool
	 */
	public static function page_has_elementor_widget( $page_id, $widget_type ) {
		$data = get_post_meta( $page_id, '_elementor_data', true );
		if ( ! is_string( $data ) || '' === $data ) {
			return false;
		}

		return false !== strpos( $data, '"widgetType":"' . $widget_type . '"' );
	}

	/**
	 * @param int    $page_id     Page ID.
	 * @param string $widget_type Widget type.
	 * @param string $setting_key Setting key.
	 * @param string $default     Default value.
	 * @return string
	 */
	public static function page_elementor_widget_setting( $page_id, $widget_type, $setting_key, $default = '' ) {
		$data = get_post_meta( $page_id, '_elementor_data', true );
		if ( ! is_string( $data ) || '' === $data ) {
			return $default;
		}

		$elements = json_decode( $data, true );
		if ( ! is_array( $elements ) ) {
			return $default;
		}

		$value = self::walk_elementor_elements_for_setting( $elements, $widget_type, $setting_key );
		return ( null === $value || '' === $value ) ? $default : (string) $value;
	}

	/**
	 * @param array  $elements    Elements tree.
	 * @param string $widget_type Widget type.
	 * @param string $setting_key Setting key.
	 * @return string|null
	 */
	private static function walk_elementor_elements_for_setting( $elements, $widget_type, $setting_key ) {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			if ( isset( $element['widgetType'] ) && $widget_type === $element['widgetType'] ) {
				if ( ! empty( $element['settings'][ $setting_key ] ) ) {
					return (string) $element['settings'][ $setting_key ];
				}
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$found = self::walk_elementor_elements_for_setting( $element['elements'], $widget_type, $setting_key );
				if ( null !== $found && '' !== $found ) {
					return $found;
				}
			}
		}

		return null;
	}

	/**
	 * @return string
	 */
	public static function detect_login_page_url() {
		static $cached = null;
		if ( null !== $cached ) {
			return $cached;
		}

		$cached = self::detect_auth_page_url_by_panel( 'login' );
		return $cached;
	}

	/**
	 * @return string
	 */
	public static function detect_register_page_url() {
		static $cached = null;
		if ( null !== $cached ) {
			return $cached;
		}

		$cached = self::detect_auth_page_url_by_panel( 'register' );
		return $cached;
	}

	/**
	 * @param string $panel login|register.
	 * @return string
	 */
	private static function detect_auth_page_url_by_panel( $panel ) {
		$slug = 'register' === $panel ? 'register' : 'login';
		$page = get_page_by_path( $slug );
		if ( $page && 'publish' === $page->post_status && self::page_has_auth_form_marker( $page->ID ) ) {
			return get_permalink( $page );
		}

		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'fields'         => 'ids',
			)
		);

		foreach ( $pages as $page_id ) {
			if ( ! self::page_has_auth_form_marker( $page_id ) ) {
				continue;
			}

			$default_panel = self::page_elementor_widget_setting( $page_id, 'ct-member-login', 'default_panel', 'login' );
			if ( $panel === $default_panel ) {
				return get_permalink( $page_id );
			}
		}

		if ( 'login' === $panel ) {
			foreach ( $pages as $page_id ) {
				if ( self::page_has_auth_form_marker( $page_id ) ) {
					return get_permalink( $page_id );
				}
			}
		}

		return '';
	}

	/**
	 * Find a published page that contains the member dashboard.
	 *
	 * @return string
	 */
	public static function detect_dashboard_page_url() {
		static $cached = null;

		if ( null !== $cached ) {
			return $cached;
		}

		$cached = '';

		$slug_pages = array( 'profile', 'member-dashboard', 'dashboard' );
		foreach ( $slug_pages as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page && 'publish' === $page->post_status && self::page_has_dashboard_marker( $page->ID ) ) {
				$cached = get_permalink( $page );
				return $cached;
			}
		}

		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'fields'         => 'ids',
			)
		);

		foreach ( $pages as $page_id ) {
			if ( ! self::page_has_dashboard_marker( $page_id ) ) {
				continue;
			}

			$cached = get_permalink( $page_id );
			return $cached;
		}

		return $cached;
	}

	/**
	 * @param string $context login|register.
	 * @return string
	 */
	public static function redirect_url( $context = 'login' ) {
		$s = self::get();
		if ( 'register' === $context && ! empty( $s['register_redirect'] ) ) {
			return $s['register_redirect'];
		}
		if ( 'login' === $context && ! empty( $s['login_redirect'] ) ) {
			return $s['login_redirect'];
		}
		return self::dashboard_url();
	}

	/**
	 * @param string $value Color.
	 * @return string
	 */
	private static function hex( $value ) {
		$color = sanitize_hex_color( $value );
		return $color ? $color : '#ff6b57';
	}
}
