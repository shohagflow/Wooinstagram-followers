<?php
/**
 * Customer subscription records from purchased subscription products.
 *
 * @package WIFL
 */

namespace WIFL\Member;

use WIFL\Product_Subscription_Meta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Customer_Subscriptions {

	const USER_META = '_wifl_customer_subscriptions';

	/**
	 * @var Customer_Subscriptions|null
	 */
	private static $instance = null;

	/**
	 * @return Customer_Subscriptions
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'woocommerce_payment_complete', array( $this, 'on_order' ), 30 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'on_order' ), 30 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'on_order' ), 30 );
	}

	/**
	 * @param int $order_id Order ID.
	 */
	public function on_order( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		if ( ! $order ) {
			return;
		}

		$user_id = (int) $order->get_user_id();
		if ( ! $user_id ) {
			$email = $order->get_billing_email();
			if ( $email ) {
				$user = get_user_by( 'email', $email );
				$user_id = $user ? (int) $user->ID : 0;
			}
		}
		if ( ! $user_id ) {
			return;
		}

		$changed = false;
		foreach ( $order->get_items() as $item_id => $item ) {
			$sub_meta = $item->get_meta( '_wifl_subscription', true );
			if ( empty( $sub_meta ) || ! is_array( $sub_meta ) ) {
				continue;
			}
			if ( $this->activate_from_order_item( $user_id, $order, $item_id, $item, $sub_meta ) ) {
				$changed = true;
			}
		}

		if ( $changed ) {
			$order->update_meta_data( '_wifl_subscription_synced', 'yes' );
			$order->save();
		}
	}

	/**
	 * @param int                  $user_id  User ID.
	 * @param \WC_Order            $order    Order.
	 * @param int                  $item_id  Item ID.
	 * @param \WC_Order_Item_Product $item    Item.
	 * @param array                $sub_meta Subscription meta.
	 * @return bool
	 */
	private function activate_from_order_item( $user_id, $order, $item_id, $item, $sub_meta ) {
		$product_id = (int) $item->get_product_id();
		$plan_id    = isset( $sub_meta['plan_id'] ) ? sanitize_key( $sub_meta['plan_id'] ) : '';
		$record_id  = 'SUB-' . (int) $order->get_id() . '-' . (int) $item_id;

		$paid = $order->get_date_paid();
		if ( ! $paid ) {
			$paid = $order->get_date_created();
		}
		$started_ts = $paid ? $paid->getTimestamp() : time();

		$existing = self::get_raw( $user_id );
		$current  = null;
		$key      = null;

		// Prefer extending an existing active sub for same product+plan.
		foreach ( $existing as $i => $row ) {
			if ( ! empty( $row['id'] ) && $row['id'] === $record_id ) {
				return false; // Already synced this line item.
			}
			if (
				(int) ( isset( $row['product_id'] ) ? $row['product_id'] : 0 ) === $product_id
				&& (string) ( isset( $row['plan_id'] ) ? $row['plan_id'] : '' ) === (string) $plan_id
				&& in_array( isset( $row['status'] ) ? $row['status'] : '', array( 'active', 'expired' ), true )
			) {
				$current = $row;
				$key     = $i;
			}
		}

		$period   = isset( $sub_meta['period'] ) ? $sub_meta['period'] : '/mo';
		$base_ts  = $started_ts;
		if ( $current && ! empty( $current['expires_ts'] ) && (int) $current['expires_ts'] > $started_ts ) {
			$base_ts = (int) $current['expires_ts'];
		}
		$expires_ts = self::add_period( $base_ts, $period );

		$qty       = isset( $sub_meta['qty'] ) ? $sub_meta['qty'] : '';
		$qty_label = isset( $sub_meta['qty_label'] ) ? $sub_meta['qty_label'] : '';
		$package   = trim( $qty . ' ' . $qty_label );
		$name      = isset( $sub_meta['name'] ) && $sub_meta['name'] ? $sub_meta['name'] : $item->get_name();
		$price     = isset( $sub_meta['price'] ) ? (float) $sub_meta['price'] : (float) $order->get_item_total( $item, false );

		$row = array(
			'id'              => $current && ! empty( $current['id'] ) ? $current['id'] : $record_id,
			'order_id'        => (int) $order->get_id(),
			'order_item_id'   => (int) $item_id,
			'product_id'      => $product_id,
			'plan_id'         => $plan_id,
			'name'            => sanitize_text_field( $name ),
			'package'         => sanitize_text_field( $package ? $package : $name ),
			'status'          => 'active',
			'price_raw'       => $price,
			'period'          => sanitize_text_field( $period ),
			'started_ts'      => $current && ! empty( $current['started_ts'] ) ? (int) $current['started_ts'] : $started_ts,
			'expires_ts'      => $expires_ts,
			'last_payment_ts' => $started_ts,
			'method'          => sanitize_text_field( $order->get_payment_method_title() ),
		);

		if ( null !== $key ) {
			$existing[ $key ] = $row;
		} else {
			array_unshift( $existing, $row );
		}

		update_user_meta( $user_id, self::USER_META, array_values( $existing ) );
		return true;
	}

	/**
	 * @param int    $timestamp Base timestamp.
	 * @param string $period    Period string.
	 * @return int
	 */
	public static function add_period( $timestamp, $period ) {
		$timestamp = (int) $timestamp;
		$period    = strtolower( trim( (string) $period ) );
		$dt        = new \DateTime( '@' . $timestamp );
		$dt->setTimezone( wp_timezone() );

		if ( preg_match( '/week|wk/', $period ) ) {
			$dt->modify( '+1 week' );
		} elseif ( preg_match( '/year|yr/', $period ) ) {
			$dt->modify( '+1 year' );
		} elseif ( preg_match( '/day|\/d\b/', $period ) ) {
			$dt->modify( '+1 day' );
		} else {
			$dt->modify( '+1 month' );
		}

		return $dt->getTimestamp();
	}

	/**
	 * @param string $period Period.
	 * @return string
	 */
	public static function cycle_label( $period ) {
		$period = strtolower( trim( (string) $period ) );
		if ( preg_match( '/week|wk/', $period ) ) {
			return __( 'Weekly', 'woo-instagram-follower' );
		}
		if ( preg_match( '/year|yr/', $period ) ) {
			return __( 'Yearly', 'woo-instagram-follower' );
		}
		if ( preg_match( '/day|\/d\b/', $period ) ) {
			return __( 'Daily', 'woo-instagram-follower' );
		}
		return __( 'Monthly', 'woo-instagram-follower' );
	}

	/**
	 * @param int $user_id User ID.
	 * @return array
	 */
	public static function get_raw( $user_id ) {
		$raw = get_user_meta( (int) $user_id, self::USER_META, true );
		return is_array( $raw ) ? $raw : array();
	}

	/**
	 * Backfill from past WooCommerce orders that contain subscription line items.
	 *
	 * @param int $user_id User ID.
	 */
	public static function sync_from_orders( $user_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
			return;
		}

		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'status'      => array( 'wc-processing', 'wc-completed' ),
				'limit'       => 50,
				'orderby'     => 'date',
				'order'       => 'ASC',
				'return'      => 'objects',
			)
		);

		$self = self::instance();
		foreach ( $orders as $order ) {
			$self->on_order( $order->get_id() );
		}
	}

	/**
	 * Profile-ready subscription cards for a customer.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	public static function for_profile( $user_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id ) {
			return array();
		}

		$rows = self::get_raw( $user_id );
		if ( empty( $rows ) ) {
			self::sync_from_orders( $user_id );
			$rows = self::get_raw( $user_id );
		}

		$out = array();
		$now = time();

		foreach ( $rows as $row ) {
			$expires = isset( $row['expires_ts'] ) ? (int) $row['expires_ts'] : 0;
			$status  = isset( $row['status'] ) ? $row['status'] : 'active';
			if ( 'cancelled' !== $status ) {
				$status = ( $expires > $now ) ? 'active' : 'expired';
			}

			$product_id = isset( $row['product_id'] ) ? (int) $row['product_id'] : 0;
			$plan_id    = isset( $row['plan_id'] ) ? $row['plan_id'] : '';
			$price_raw  = isset( $row['price_raw'] ) ? (float) $row['price_raw'] : 0;
			$period     = isset( $row['period'] ) ? $row['period'] : '/mo';

			$status_labels = array(
				'active'    => __( 'Active', 'woo-instagram-follower' ),
				'expired'   => __( 'Expired', 'woo-instagram-follower' ),
				'cancelled' => __( 'Cancelled', 'woo-instagram-follower' ),
				'paused'    => __( 'Paused', 'woo-instagram-follower' ),
			);

			$note = '';
			if ( 'active' === $status ) {
				$days = max( 0, (int) ceil( ( $expires - $now ) / DAY_IN_SECONDS ) );
				$note = sprintf(
					/* translators: %d: days remaining */
					_n( '%d day remaining until renewal.', '%d days remaining until renewal.', $days, 'woo-instagram-follower' ),
					$days
				);
			} elseif ( 'expired' === $status ) {
				$note = __( 'This plan has expired. Renew to continue delivery.', 'woo-instagram-follower' );
			} elseif ( 'cancelled' === $status ) {
				$note = __( 'This subscription was cancelled.', 'woo-instagram-follower' );
			}

			$renew_url = '';
			if ( $product_id && class_exists( '\WIFL\Product_Subscription_Meta' ) ) {
				$renew_url = Product_Subscription_Meta::buy_url( $product_id, $plan_id );
			}

			$order_url = '';
			if ( ! empty( $row['order_id'] ) && function_exists( 'wc_get_endpoint_url' ) ) {
				$order_url = wc_get_endpoint_url( 'view-order', (int) $row['order_id'], wc_get_page_permalink( 'myaccount' ) );
			}

			$out[] = array(
				'id'           => isset( $row['id'] ) ? $row['id'] : '',
				'name'         => isset( $row['name'] ) ? $row['name'] : '',
				'package'      => isset( $row['package'] ) ? $row['package'] : '',
				'status'       => $status,
				'status_label' => isset( $status_labels[ $status ] ) ? $status_labels[ $status ] : ucfirst( $status ),
				'price'        => function_exists( 'wc_price' ) ? wc_price( $price_raw ) : '$' . number_format( $price_raw, 2 ),
				'cycle'        => self::cycle_label( $period ),
				'started'      => self::format_date( isset( $row['started_ts'] ) ? (int) $row['started_ts'] : 0 ),
				'expires'      => self::format_date( $expires ),
				'renews'       => 'active' === $status ? self::format_date( $expires ) : ( 'expired' === $status ? __( 'Expired — renew to continue', 'woo-instagram-follower' ) : self::format_date( $expires ) ),
				'last_payment' => self::format_date( isset( $row['last_payment_ts'] ) ? (int) $row['last_payment_ts'] : 0 ),
				'method'       => ! empty( $row['method'] ) ? $row['method'] : __( '—', 'woo-instagram-follower' ),
				'note'         => $note,
				'renew_url'    => $renew_url,
				'order_url'    => $order_url,
				'order_id'     => isset( $row['order_id'] ) ? (int) $row['order_id'] : 0,
			);
		}

		return $out;
	}

	/**
	 * @param int $timestamp Timestamp.
	 * @return string
	 */
	private static function format_date( $timestamp ) {
		$timestamp = (int) $timestamp;
		if ( $timestamp <= 0 ) {
			return '—';
		}
		return date_i18n( get_option( 'date_format' ), $timestamp );
	}
}
