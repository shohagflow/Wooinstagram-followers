<?php
/**
 * Member dashboard (frontend).
 *
 * @package WIFL
 */

namespace WIFL\Member;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Dashboard {

	/**
	 * @var Dashboard|null
	 */
	private static $instance = null;

	/**
	 * @return Dashboard
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'wifl_dashboard', array( $this, 'shortcode' ) );
		add_action( 'init', array( $this, 'handle_profile_update' ), 25 );
		add_filter( 'get_avatar_url', array( $this, 'filter_avatar_url' ), 10, 2 );
	}

	/**
	 * @param bool $preview Preview mode for Elementor editor.
	 * @return string
	 */
	public static function render( $preview = false ) {
		if ( ! $preview && ! is_user_logged_in() ) {
			return '';
		}

		$profile = self::build_profile_data( $preview );
		if ( empty( $profile ) ) {
			return '';
		}

		ob_start();
		include WIFL_PATH . 'member/profile.php';
		return ob_get_clean();
	}

	/**
	 * @param bool $preview Preview mode.
	 * @return array
	 */
	public static function build_profile_data( $preview = false ) {
		$settings = Settings::get();
		$user     = wp_get_current_user();

		if ( ! $preview && ( ! $user || ! $user->exists() ) ) {
			return array();
		}

		if ( $preview && ( ! $user || ! $user->exists() ) ) {
			$user = self::demo_user();
		}

		$real_orders = self::orders_for_user( $preview ? 0 : (int) $user->ID );
		$use_demo    = $preview || empty( $real_orders );
		$orders      = $use_demo ? self::demo_orders() : $real_orders;
		$points      = $use_demo ? 1250 : self::user_points( $user->ID );
		$activity    = $use_demo ? self::demo_activity() : self::activity_from_orders( $orders );
		$subscriptions = $preview
			? self::demo_subscriptions()
			: Customer_Subscriptions::for_profile( (int) $user->ID );

		return array(
			'user'         => $user,
			'settings'     => $settings,
			'orders'       => $orders,
			'activity'      => $activity,
			'subscriptions' => $subscriptions,
			'stats'         => self::stats_from_orders( $orders, $points ),
			'account'      => self::account_details( $user, $points, $preview && empty( $user->ID ) ),
			'points'       => $points,
			'initials'     => self::user_initials( $user ),
			'avatar_url'   => self::user_avatar_url( $user ),
			'display_name' => self::user_display_label( $user, 28 ),
			'shop_url'     => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
			'logout_url'   => wp_logout_url( Settings::login_url() ),
			'status_text'  => ! empty( $settings['promo_status'] ) ? $settings['promo_status'] : __( 'All deliveries running', 'woo-instagram-follower' ),
			'logo_url'     => ! empty( $settings['logo_url'] ) ? $settings['logo_url'] : '',
			'brand_name'   => ! empty( $settings['membership_name'] ) ? $settings['membership_name'] : 'Membership',
			'is_preview'     => (bool) $preview,
			'is_demo'        => $use_demo,
			'can_edit'       => ! $preview && ! empty( $user->ID ),
			'profile_notice' => self::profile_notice(),
			'active_view'    => self::requested_view(),
		);
	}

	/**
	 * @return string
	 */
	private static function requested_view() {
		$view = isset( $_GET['wifl_view'] ) ? sanitize_key( wp_unslash( $_GET['wifl_view'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( in_array( $view, array( 'home', 'activity', 'orders', 'subscription', 'account' ), true ) ) {
			return $view;
		}

		return 'home';
	}

	/**
	 * @return array
	 */
	private static function profile_notice() {
		$code = isset( $_GET['wifl_profile'] ) ? sanitize_key( wp_unslash( $_GET['wifl_profile'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$map  = array(
			'updated' => array(
				'type'    => 'success',
				'message' => __( 'Profile saved.', 'woo-instagram-follower' ),
			),
			'email'   => array(
				'type'    => 'error',
				'message' => __( 'That email is already in use.', 'woo-instagram-follower' ),
			),
			'avatar'  => array(
				'type'    => 'error',
				'message' => __( 'Could not upload that image. Use JPG, PNG, or WebP under 2MB.', 'woo-instagram-follower' ),
			),
			'invalid' => array(
				'type'    => 'error',
				'message' => __( 'Please check your details and try again.', 'woo-instagram-follower' ),
			),
		);

		return isset( $map[ $code ] ) ? $map[ $code ] : array();
	}

	/**
	 * @return object
	 */
	private static function demo_user() {
		return (object) array(
			'ID'              => 0,
			'user_login'      => 'alexcarter',
			'user_email'      => 'alex.carter@example.com',
			'display_name'    => 'Alex Carter',
			'user_registered' => '2025-01-18 10:24:00',
		);
	}

	/**
	 * @param int $user_id User ID.
	 * @return array
	 */
	private static function orders_for_user( $user_id ) {
		if ( ! function_exists( 'wc_get_orders' ) || ! $user_id ) {
			return array();
		}

		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'limit'       => 50,
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);

		$items = array();
		foreach ( $orders as $order ) {
			$status   = $order->get_status();
			$product  = '';
			$qty      = '';
			$line_items = $order->get_items();
			if ( ! empty( $line_items ) ) {
				$first   = reset( $line_items );
				$product = $first ? $first->get_name() : '';
				$qty     = $first ? (string) $first->get_quantity() : '';
			}

			$wifl_qty = $order->get_meta( 'Package' );
			if ( $wifl_qty ) {
				$qty = (string) $wifl_qty;
			}

			$items[] = array(
				'number'       => $order->get_order_number(),
				'product'      => $product,
				'qty'          => $qty,
				'status'       => $status,
				'status_label' => wc_get_order_status_name( $status ),
				'status_group' => self::order_status_group( $status ),
				'date'         => wc_format_datetime( $order->get_date_created() ),
				'total'        => $order->get_formatted_order_total(),
				'is_demo'      => false,
			);
		}

		return $items;
	}

	/**
	 * Sample orders so the dashboard looks complete in preview / empty accounts.
	 *
	 * @return array
	 */
	private static function demo_orders() {
		$rows = array(
			array(
				'number'       => '10482',
				'product'      => 'Instagram Followers',
				'qty'          => '1,000',
				'status'       => 'processing',
				'status_label' => __( 'Processing', 'woo-instagram-follower' ),
				'status_group' => 'in-progress',
				'date'         => 'March 12, 2026',
				'total_raw'    => 8.00,
			),
			array(
				'number'       => '10471',
				'product'      => 'Instagram Likes',
				'qty'          => '500',
				'status'       => 'completed',
				'status_label' => __( 'Completed', 'woo-instagram-follower' ),
				'status_group' => 'completed',
				'date'         => 'March 8, 2026',
				'total_raw'    => 3.20,
			),
			array(
				'number'       => '10458',
				'product'      => 'Instagram Followers',
				'qty'          => '2,500',
				'status'       => 'on-hold',
				'status_label' => __( 'In progress', 'woo-instagram-follower' ),
				'status_group' => 'in-progress',
				'date'         => 'February 28, 2026',
				'total_raw'    => 18.40,
			),
			array(
				'number'       => '10431',
				'product'      => 'YouTube Views',
				'qty'          => '5,000',
				'status'       => 'completed',
				'status_label' => __( 'Completed', 'woo-instagram-follower' ),
				'status_group' => 'completed',
				'date'         => 'February 14, 2026',
				'total_raw'    => 12.00,
			),
			array(
				'number'       => '10412',
				'product'      => 'Instagram Followers',
				'qty'          => '250',
				'status'       => 'failed',
				'status_label' => __( 'Failed', 'woo-instagram-follower' ),
				'status_group' => 'failed',
				'date'         => 'January 30, 2026',
				'total_raw'    => 2.00,
			),
		);

		$out = array();
		foreach ( $rows as $row ) {
			$row['total']   = function_exists( 'wc_price' ) ? wc_price( $row['total_raw'] ) : '$' . number_format( (float) $row['total_raw'], 2 );
			$row['is_demo'] = true;
			unset( $row['total_raw'] );
			$out[] = $row;
		}

		return $out;
	}

	/**
	 * Sample subscriptions for the customer profile.
	 *
	 * @return array
	 */
	private static function demo_subscriptions() {
		$price = static function ( $amount ) {
			return function_exists( 'wc_price' ) ? wc_price( $amount ) : '$' . number_format( (float) $amount, 2 );
		};

		return array(
			array(
				'id'           => 'SUB-2041',
				'name'         => __( 'Instagram Growth Pro', 'woo-instagram-follower' ),
				'package'      => __( '1,000 followers / month', 'woo-instagram-follower' ),
				'status'       => 'active',
				'status_label' => __( 'Active', 'woo-instagram-follower' ),
				'price'        => $price( 19.99 ),
				'cycle'        => __( 'Monthly', 'woo-instagram-follower' ),
				'started'      => 'January 18, 2026',
				'expires'      => 'April 18, 2026',
				'renews'       => 'April 18, 2026',
				'last_payment' => 'March 18, 2026',
				'method'       => __( 'Visa ending 4242', 'woo-instagram-follower' ),
				'note'         => __( '14 days remaining until renewal.', 'woo-instagram-follower' ),
				'renew_url'    => '',
				'order_url'    => '',
				'order_id'     => 2041,
			),
			array(
				'id'           => 'SUB-1988',
				'name'         => __( 'Weekly Likes Boost', 'woo-instagram-follower' ),
				'package'      => __( '500 likes / week', 'woo-instagram-follower' ),
				'status'       => 'expired',
				'status_label' => __( 'Expired', 'woo-instagram-follower' ),
				'price'        => $price( 8.50 ),
				'cycle'        => __( 'Weekly', 'woo-instagram-follower' ),
				'started'      => 'February 2, 2026',
				'expires'      => 'March 9, 2026',
				'renews'       => __( 'Expired — renew to continue', 'woo-instagram-follower' ),
				'last_payment' => 'March 9, 2026',
				'method'       => __( 'Visa ending 4242', 'woo-instagram-follower' ),
				'note'         => __( 'This plan has expired. Renew to continue delivery.', 'woo-instagram-follower' ),
				'renew_url'    => '',
				'order_url'    => '',
				'order_id'     => 1988,
			),
			array(
				'id'           => 'SUB-1764',
				'name'         => __( 'YouTube Views Plus', 'woo-instagram-follower' ),
				'package'      => __( '5,000 views / month', 'woo-instagram-follower' ),
				'status'       => 'cancelled',
				'status_label' => __( 'Cancelled', 'woo-instagram-follower' ),
				'price'        => $price( 14.00 ),
				'cycle'        => __( 'Monthly', 'woo-instagram-follower' ),
				'started'      => 'November 12, 2025',
				'expires'      => 'March 12, 2026',
				'renews'       => __( 'Ended March 12, 2026', 'woo-instagram-follower' ),
				'last_payment' => 'February 12, 2026',
				'method'       => __( 'PayPal', 'woo-instagram-follower' ),
				'note'         => __( 'Cancelled at the end of the billing period. Access ended on March 12, 2026.', 'woo-instagram-follower' ),
				'renew_url'    => '',
				'order_url'    => '',
				'order_id'     => 1764,
			),
		);
	}

	/**
	 * @return array
	 */
	private static function demo_activity() {
		return array(
			array(
				'type'    => 'order',
				'title'   => __( 'Order placed', 'woo-instagram-follower' ),
				'detail'  => __( 'Instagram Followers · 1,000 — #10482', 'woo-instagram-follower' ),
				'time'    => __( '2 hours ago', 'woo-instagram-follower' ),
				'group'   => 'in-progress',
			),
			array(
				'type'    => 'payment',
				'title'   => __( 'Payment confirmed', 'woo-instagram-follower' ),
				'detail'  => __( '$8.00 charged · Visa ending 4242', 'woo-instagram-follower' ),
				'time'    => __( '2 hours ago', 'woo-instagram-follower' ),
				'group'   => 'completed',
			),
			array(
				'type'    => 'delivery',
				'title'   => __( 'Delivery started', 'woo-instagram-follower' ),
				'detail'  => __( '1,000 followers are being delivered', 'woo-instagram-follower' ),
				'time'    => __( 'Yesterday', 'woo-instagram-follower' ),
				'group'   => 'in-progress',
			),
			array(
				'type'    => 'points',
				'title'   => __( 'Points earned', 'woo-instagram-follower' ),
				'detail'  => __( '+80 PTS added to your rewards balance', 'woo-instagram-follower' ),
				'time'    => __( 'March 8, 2026', 'woo-instagram-follower' ),
				'group'   => 'completed',
			),
			array(
				'type'    => 'complete',
				'title'   => __( 'Order completed', 'woo-instagram-follower' ),
				'detail'  => __( 'Instagram Likes · 500 — #10471', 'woo-instagram-follower' ),
				'time'    => __( 'March 8, 2026', 'woo-instagram-follower' ),
				'group'   => 'completed',
			),
			array(
				'type'    => 'account',
				'title'   => __( 'Profile updated', 'woo-instagram-follower' ),
				'detail'  => __( 'Billing address and notification preferences saved', 'woo-instagram-follower' ),
				'time'    => __( 'February 20, 2026', 'woo-instagram-follower' ),
				'group'   => 'completed',
			),
		);
	}

	/**
	 * @param array $orders Orders.
	 * @return array
	 */
	private static function activity_from_orders( $orders ) {
		$activity = array();
		foreach ( array_slice( $orders, 0, 8 ) as $order ) {
			$product = ! empty( $order['product'] ) ? $order['product'] : __( 'Package', 'woo-instagram-follower' );
			$qty     = ! empty( $order['qty'] ) ? ' · ' . $order['qty'] : '';
			$activity[] = array(
				'type'   => 'completed' === $order['status_group'] ? 'complete' : ( 'failed' === $order['status_group'] ? 'failed' : 'order' ),
				'title'  => sprintf(
					/* translators: %s order status */
					__( 'Order %s', 'woo-instagram-follower' ),
					strtolower( $order['status_label'] )
				),
				'detail' => $product . $qty . ' — #' . $order['number'],
				'time'   => $order['date'],
				'group'  => $order['status_group'],
			);
		}

		return $activity;
	}

	/**
	 * @param array $orders Orders.
	 * @param int   $points Points.
	 * @return array
	 */
	private static function stats_from_orders( $orders, $points ) {
		$in_progress = 0;
		$completed   = 0;
		foreach ( $orders as $order ) {
			if ( 'in-progress' === $order['status_group'] ) {
				$in_progress++;
			}
			if ( 'completed' === $order['status_group'] ) {
				$completed++;
			}
		}

		return array(
			'total'       => count( $orders ),
			'in_progress' => $in_progress,
			'completed'   => $completed,
			'points'      => (int) $points,
		);
	}

	/**
	 * @param \WP_User|object $user    User.
	 * @param int             $points  Points.
	 * @param bool            $demo    Fill missing fields with sample values.
	 * @return array
	 */
	private static function account_details( $user, $points, $demo = false ) {
		$user_id     = ! empty( $user->ID ) ? (int) $user->ID : 0;
		$first_name  = $user_id ? get_user_meta( $user_id, 'first_name', true ) : '';
		$last_name   = $user_id ? get_user_meta( $user_id, 'last_name', true ) : '';
		$phone       = $user_id ? get_user_meta( $user_id, 'wifl_phone', true ) : '';
		$location    = $user_id ? get_user_meta( $user_id, 'wifl_location', true ) : '';
		$billing     = $user_id ? get_user_meta( $user_id, 'wifl_billing', true ) : '';
		$notify_mail = $user_id ? get_user_meta( $user_id, 'wifl_notify_email', true ) : 'yes';
		$notify_sms  = $user_id ? get_user_meta( $user_id, 'wifl_notify_sms', true ) : 'no';
		$plan        = __( 'Standard member', 'woo-instagram-follower' );

		if ( $user_id && class_exists( '\WC_Customer' ) ) {
			try {
				$customer = new \WC_Customer( $user_id );
				if ( '' === $phone ) {
					$phone = $customer->get_billing_phone();
				}
				if ( '' === $location ) {
					$parts    = array_filter( array( $customer->get_billing_city(), $customer->get_billing_country() ) );
					$location = implode( ', ', $parts );
				}
				if ( '' === $billing ) {
					$lines = array_filter(
						array(
							$customer->get_billing_address_1(),
							$customer->get_billing_address_2(),
							trim( $customer->get_billing_city() . ' ' . $customer->get_billing_postcode() ),
							$customer->get_billing_country(),
						)
					);
					$billing = implode( ', ', $lines );
				}
				if ( '' === $first_name ) {
					$first_name = $customer->get_first_name();
				}
				if ( '' === $last_name ) {
					$last_name = $customer->get_last_name();
				}
			} catch ( \Exception $e ) {
				// Keep meta values.
			}
		}

		if ( $demo ) {
			$first_name  = $first_name ? $first_name : 'Alex';
			$last_name   = $last_name ? $last_name : 'Carter';
			$phone       = $phone ? $phone : '+1 (415) 555-0198';
			$location    = $location ? $location : 'San Francisco, US';
			$billing     = $billing ? $billing : '120 Market Street, San Francisco, CA 94103';
			$notify_mail = 'yes';
			$notify_sms  = 'yes';
			$plan        = __( 'Pro member', 'woo-instagram-follower' );
		}

		$registered = ! empty( $user->user_registered ) ? mysql2date( get_option( 'date_format' ), $user->user_registered ) : '';
		$display    = ! empty( $user->display_name ) ? $user->display_name : $user->user_login;

		return array(
			'first_name'     => $first_name,
			'last_name'      => $last_name,
			'display_name'   => $display,
			'email'          => $user->user_email,
			'username'       => $user->user_login,
			'phone'          => $phone,
			'location'       => $location,
			'billing'        => $billing,
			'member_since'   => $registered,
			'plan'           => $plan,
			'points'         => (int) $points,
			'notify_email'   => ( 'no' === $notify_mail ) ? 'no' : 'yes',
			'notify_sms'     => ( 'yes' === $notify_sms ) ? 'yes' : 'no',
		);
	}

	/**
	 * @param \WP_User|object $user User.
	 * @return string
	 */
	public static function user_avatar_url( $user ) {
		if ( empty( $user->ID ) ) {
			return '';
		}

		$url = get_user_meta( (int) $user->ID, 'wifl_avatar_url', true );
		return is_string( $url ) ? $url : '';
	}

	/**
	 * @param string          $url         Default URL.
	 * @param mixed           $id_or_email ID or email.
	 * @return string
	 */
	public function filter_avatar_url( $url, $id_or_email ) {
		$user_id = 0;
		if ( is_numeric( $id_or_email ) ) {
			$user_id = (int) $id_or_email;
		} elseif ( $id_or_email instanceof \WP_User ) {
			$user_id = (int) $id_or_email->ID;
		} elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) {
			$user_id = (int) $id_or_email->user_id;
		} elseif ( is_string( $id_or_email ) && is_email( $id_or_email ) ) {
			$user = get_user_by( 'email', $id_or_email );
			$user_id = $user ? (int) $user->ID : 0;
		}

		if ( $user_id ) {
			$custom = get_user_meta( $user_id, 'wifl_avatar_url', true );
			if ( $custom ) {
				return $custom;
			}
		}

		return $url;
	}

	public function handle_profile_update() {
		if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			return;
		}

		if ( ! isset( $_POST['wifl_update_profile'] ) ) {
			return;
		}

		$redirect = wp_get_referer() ? wp_get_referer() : Settings::dashboard_url();
		$redirect = remove_query_arg( array( 'wifl_profile', 'wifl_view' ), $redirect );

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( Settings::login_url() );
			exit;
		}

		if ( ! isset( $_POST['wifl_profile_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_profile_nonce'] ) ), 'wifl_update_profile' ) ) {
			wp_safe_redirect( add_query_arg( array( 'wifl_view' => 'account', 'wifl_profile' => 'invalid' ), $redirect ) );
			exit;
		}

		$user_id = get_current_user_id();
		$first   = isset( $_POST['wifl_first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['wifl_first_name'] ) ) : '';
		$last    = isset( $_POST['wifl_last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['wifl_last_name'] ) ) : '';
		$display = isset( $_POST['wifl_display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['wifl_display_name'] ) ) : '';
		$email   = isset( $_POST['wifl_email'] ) ? sanitize_email( wp_unslash( $_POST['wifl_email'] ) ) : '';
		$phone   = isset( $_POST['wifl_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['wifl_phone'] ) ) : '';
		$city    = isset( $_POST['wifl_location'] ) ? sanitize_text_field( wp_unslash( $_POST['wifl_location'] ) ) : '';
		$billing = isset( $_POST['wifl_billing'] ) ? sanitize_textarea_field( wp_unslash( $_POST['wifl_billing'] ) ) : '';

		if ( '' === $display ) {
			$display = trim( $first . ' ' . $last );
		}

		$code = 'updated';

		if ( $email ) {
			$exists = email_exists( $email );
			if ( $exists && (int) $exists !== $user_id ) {
				$code = 'email';
			}
		} else {
			$code = 'invalid';
		}

		if ( 'updated' === $code ) {
			$result = wp_update_user(
				array(
					'ID'           => $user_id,
					'first_name'   => $first,
					'last_name'    => $last,
					'display_name' => $display ? $display : wp_get_current_user()->user_login,
					'user_email'   => $email,
				)
			);

			if ( is_wp_error( $result ) ) {
				$code = 'invalid';
			} else {
				update_user_meta( $user_id, 'wifl_phone', $phone );
				update_user_meta( $user_id, 'wifl_location', $city );
				update_user_meta( $user_id, 'wifl_billing', $billing );
				update_user_meta( $user_id, 'wifl_notify_email', empty( $_POST['wifl_notify_email'] ) ? 'no' : 'yes' );
				update_user_meta( $user_id, 'wifl_notify_sms', empty( $_POST['wifl_notify_sms'] ) ? 'no' : 'yes' );

				if ( class_exists( '\WC_Customer' ) ) {
					try {
						$customer = new \WC_Customer( $user_id );
						$customer->set_first_name( $first );
						$customer->set_last_name( $last );
						$customer->set_billing_first_name( $first );
						$customer->set_billing_last_name( $last );
						$customer->set_billing_phone( $phone );
						$customer->set_billing_city( $city );
						$customer->set_billing_address_1( $billing );
						$customer->save();
					} catch ( \Exception $e ) {
						// Profile meta already saved.
					}
				}

				if ( ! empty( $_POST['wifl_remove_avatar'] ) ) {
					self::delete_avatar( $user_id );
				} elseif ( ! empty( $_FILES['wifl_avatar']['name'] ) ) {
					if ( ! self::save_avatar( $user_id, $_FILES['wifl_avatar'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
						$code = 'avatar';
					}
				}
			}
		}

		wp_safe_redirect( add_query_arg( array( 'wifl_view' => 'account', 'wifl_profile' => $code ), $redirect ) );
		exit;
	}

	/**
	 * @param int   $user_id User ID.
	 * @param array $file    $_FILES item.
	 * @return bool
	 */
	private static function save_avatar( $user_id, $file ) {
		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return false;
		}

		if ( ! empty( $file['size'] ) && (int) $file['size'] > 2 * 1024 * 1024 ) {
			return false;
		}

		$check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
		$ok    = array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' );
		if ( empty( $check['type'] ) || ! in_array( $check['type'], $ok, true ) ) {
			return false;
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$uploaded = wp_handle_upload(
			$file,
			array(
				'test_form' => false,
				'mimes'     => array(
					'jpg|jpeg|jpe' => 'image/jpeg',
					'png'          => 'image/png',
					'gif'          => 'image/gif',
					'webp'         => 'image/webp',
				),
			)
		);

		if ( ! empty( $uploaded['error'] ) || empty( $uploaded['url'] ) ) {
			return false;
		}

		self::delete_avatar_file( $user_id );
		update_user_meta( $user_id, 'wifl_avatar_url', esc_url_raw( $uploaded['url'] ) );
		update_user_meta( $user_id, 'wifl_avatar_path', $uploaded['file'] );

		return true;
	}

	/**
	 * @param int $user_id User ID.
	 */
	private static function delete_avatar( $user_id ) {
		self::delete_avatar_file( $user_id );
		delete_user_meta( $user_id, 'wifl_avatar_url' );
		delete_user_meta( $user_id, 'wifl_avatar_path' );
	}

	/**
	 * @param int $user_id User ID.
	 */
	private static function delete_avatar_file( $user_id ) {
		$path = get_user_meta( $user_id, 'wifl_avatar_path', true );
		if ( $path && file_exists( $path ) ) {
			$uploads = wp_get_upload_dir();
			if ( ! empty( $uploads['basedir'] ) && 0 === strpos( wp_normalize_path( $path ), wp_normalize_path( $uploads['basedir'] ) ) ) {
				wp_delete_file( $path );
			}
		}
	}

	/**
	 * @param string $status Order status slug.
	 * @return string
	 */
	public static function order_status_group( $status ) {
		$status = str_replace( 'wc-', '', $status );

		if ( in_array( $status, array( 'pending', 'processing', 'on-hold' ), true ) ) {
			return 'in-progress';
		}
		if ( 'completed' === $status ) {
			return 'completed';
		}
		if ( in_array( $status, array( 'failed', 'cancelled', 'refunded' ), true ) ) {
			return 'failed';
		}

		return 'in-progress';
	}

	/**
	 * @param int $user_id User ID.
	 * @return int
	 */
	private static function user_points( $user_id ) {
		if ( ! $user_id ) {
			return 0;
		}

		$points = get_user_meta( $user_id, 'wifl_points', true );
		if ( '' === $points || false === $points ) {
			return (int) apply_filters( 'wifl_member_user_points', 0, $user_id );
		}

		return (int) $points;
	}

	/**
	 * @param \WP_User|object $user User.
	 * @return string
	 */
	private static function user_initials( $user ) {
		$source = $user->display_name ? $user->display_name : $user->user_login;
		$parts  = preg_split( '/[\s._-]+/', trim( $source ) );
		$parts  = array_values( array_filter( $parts ) );

		if ( count( $parts ) >= 2 ) {
			return strtoupper( substr( $parts[0], 0, 1 ) . substr( $parts[1], 0, 1 ) );
		}

		return strtoupper( substr( $source, 0, 2 ) );
	}

	/**
	 * @param \WP_User|object $user User.
	 * @param int             $max  Max characters.
	 * @return string
	 */
	private static function user_display_label( $user, $max = 18 ) {
		$label = $user->display_name ? $user->display_name : $user->user_login;
		if ( strlen( $label ) > $max ) {
			return substr( $label, 0, max( 1, $max - 3 ) ) . '...';
		}
		return $label;
	}

	/**
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function shortcode( $atts ) {
		unset( $atts );
		Member::enqueue_assets();
		return self::render();
	}
}
