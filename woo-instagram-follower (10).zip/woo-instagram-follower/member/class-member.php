<?php
/**
 * Member area — login / registration forms and assets.
 *
 * @package WIFL
 */

namespace WIFL\Member;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WIFL_PATH . 'member/class-settings.php';
require_once WIFL_PATH . 'member/class-subscriptions.php';
require_once WIFL_PATH . 'member/class-customer-subscriptions.php';
require_once WIFL_PATH . 'member/class-forms.php';
require_once WIFL_PATH . 'member/class-dashboard.php';
require_once WIFL_PATH . 'admin/class-member-admin.php';

class Member {

	/**
	 * @var Member|null
	 */
	private static $instance = null;

	/**
	 * @return Member
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		Forms::instance();
		Dashboard::instance();
		Customer_Subscriptions::instance();

		if ( is_admin() ) {
			Admin::instance();
		}

		add_shortcode( 'wifl_login', array( $this, 'shortcode_login' ) );
		add_shortcode( 'wifl_register', array( $this, 'shortcode_login' ) );
		add_action( 'template_redirect', array( $this, 'maybe_redirect_auth_pages' ), 1 );
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_elementor_category' ) );
		add_action( 'elementor/editor/after_enqueue_styles', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'elementor/editor/after_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'elementor/preview/enqueue_styles', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'elementor/preview/enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Elementor editor or live preview (not frontend for logged-in users).
	 *
	 * @return bool
	 */
	public static function is_elementor_preview() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return false;
		}

		$plugin = \Elementor\Plugin::$instance;

		if ( isset( $plugin->editor ) && $plugin->editor->is_edit_mode() ) {
			return true;
		}

		if ( isset( $plugin->preview ) && $plugin->preview->is_preview_mode() ) {
			return true;
		}

		return false;
	}

	/**
	 * @return bool
	 */
	public static function can_show_login_form() {
		return ! is_user_logged_in() || self::is_elementor_preview();
	}

	/**
	 * Redirect logged-in users away from login/register pages and guests away from dashboard.
	 */
	public function maybe_redirect_auth_pages() {
		if ( is_admin() || self::is_elementor_preview() ) {
			return;
		}

		if ( ! is_singular() ) {
			return;
		}

		$page_id = get_queried_object_id();
		if ( ! $page_id ) {
			return;
		}

		$on_dash_page  = $this->is_current_dashboard_page( $page_id );
		$on_auth_page  = $this->is_current_auth_form_page( $page_id );

		if ( $on_auth_page && is_user_logged_in() ) {
			wp_safe_redirect( Settings::dashboard_url() );
			exit;
		}

		if ( $on_dash_page && ! is_user_logged_in() ) {
			wp_safe_redirect( Settings::login_url() );
			exit;
		}
	}

	/**
	 * @param int $page_id Page ID.
	 * @return bool
	 */
	private function is_current_dashboard_page( $page_id ) {
		if ( Settings::page_has_dashboard_marker( $page_id ) ) {
			return true;
		}

		$settings = Settings::get();
		if ( empty( $settings['dashboard_page_url'] ) ) {
			return false;
		}

		$target_id = url_to_postid( $settings['dashboard_page_url'] );
		return $target_id && (int) $target_id === (int) $page_id && Settings::page_has_dashboard_marker( $page_id );
	}

	/**
	 * @param int $page_id Page ID.
	 * @return bool
	 */
	private function is_current_auth_form_page( $page_id ) {
		if ( Settings::page_has_dashboard_marker( $page_id ) ) {
			return false;
		}

		if ( Settings::page_has_auth_form_marker( $page_id ) ) {
			return true;
		}

		$settings = Settings::get();
		foreach ( array( 'login_page_url', 'register_page_url' ) as $key ) {
			if ( empty( $settings[ $key ] ) ) {
				continue;
			}
			$target_id = url_to_postid( $settings[ $key ] );
			if ( $target_id && (int) $target_id === (int) $page_id ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param \Elementor\Elements_Manager $elements_manager Manager.
	 */
	public function register_elementor_category( $elements_manager ) {
		$elements_manager->add_category(
			'wifl-member',
			array(
				'title' => esc_html__( 'CT Member', 'woo-instagram-follower' ),
				'icon'  => 'fa fa-user',
			)
		);
	}

	public static function register_assets() {
		wp_register_style(
			'wifl-member',
			WIFL_URL . 'assets/css/member.css',
			array(),
			WIFL_VERSION
		);

		wp_register_style(
			'wifl-icon-text',
			WIFL_URL . 'assets/css/icon-text.css',
			array(),
			WIFL_VERSION
		);

		wp_register_script(
			'wifl-member',
			WIFL_URL . 'assets/js/member.js',
			array(),
			WIFL_VERSION,
			true
		);
	}

	public static function enqueue_assets() {
		self::register_assets();
		wp_enqueue_style( 'wifl-member' );
		wp_enqueue_script( 'wifl-member' );
	}

	/**
	 * Message shown when a logged-in user hits a login/register page.
	 *
	 * @return string
	 */
	public static function logged_in_form_notice() {
		$dashboard_url = Settings::dashboard_url();
		ob_start();
		?>
		<div class="wifl-member-form-wrap">
			<div class="wifl-member-notice wifl-member-notice--info" style="max-width:560px;margin:24px auto;padding:18px 20px;">
				<?php esc_html_e( 'You are already signed in.', 'woo-instagram-follower' ); ?>
				<a href="<?php echo esc_url( $dashboard_url ); ?>" style="margin-left:8px;font-weight:700;">
					<?php esc_html_e( 'Go to dashboard', 'woo-instagram-follower' ); ?>
				</a>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function shortcode_login( $atts ) {
		$atts = shortcode_atts( Forms::default_settings(), $atts, 'wifl_login' );
		self::enqueue_assets();

		if ( ! self::can_show_login_form() ) {
			return self::logged_in_form_notice();
		}

		return Forms::instance()->render( $atts );
	}
}
