<?php
/**
 * Member profile dashboard template.
 *
 * @package WIFL
 *
 * @var array $profile Profile view data from Dashboard::build_profile_data().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user         = $profile['user'];
$settings     = $profile['settings'];
$orders       = $profile['orders'];
$activity      = ! empty( $profile['activity'] ) ? $profile['activity'] : array();
$subscriptions = ! empty( $profile['subscriptions'] ) ? $profile['subscriptions'] : array();
$stats         = ! empty( $profile['stats'] ) ? $profile['stats'] : array();
$account      = wp_parse_args(
	! empty( $profile['account'] ) ? $profile['account'] : array(),
	array(
		'email'        => '',
		'username'     => '',
		'first_name'   => '',
		'last_name'    => '',
		'display_name' => '',
		'phone'        => '',
		'location'     => '',
		'billing'      => '',
		'member_since' => '',
		'plan'         => '',
		'points'       => 0,
		'notify_email' => 'yes',
		'notify_sms'   => 'no',
	)
);
$points       = $profile['points'];
$initials     = $profile['initials'];
$avatar_url   = ! empty( $profile['avatar_url'] ) ? $profile['avatar_url'] : '';
$can_edit     = ! empty( $profile['can_edit'] );
$notice       = ! empty( $profile['profile_notice'] ) ? $profile['profile_notice'] : array();
$display_name = $profile['display_name'];
$shop_url     = $profile['shop_url'];
$logout_url   = $profile['logout_url'];
$status_text  = $profile['status_text'];
$logo_url     = $profile['logo_url'];
$brand_name   = $profile['brand_name'];
$is_preview   = ! empty( $profile['is_preview'] );
$is_demo      = ! empty( $profile['is_demo'] );
$active_view  = ! empty( $profile['active_view'] ) ? $profile['active_view'] : 'home';
$recent       = array_slice( $activity, 0, 3 );

$activity_icons = array(
	'order'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M230.14,58.87A8,8,0,0,0,224,56H62.68L56.6,32.57A8,8,0,0,0,48.73,26H24a8,8,0,0,0,0,16h18L67.56,172.29a24,24,0,0,0,5.33,11.27,28,28,0,1,0,44.4,8.44h45.42A27.75,27.75,0,0,0,160,196a28,28,0,1,0,28-28H91.17a8,8,0,0,1-7.87-6.57L80.13,152h116a24,24,0,0,0,23.61-19.71l12.16-66.86A8,8,0,0,0,230.14,58.87Z"/></svg>',
	'payment'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M224,48H32A16,16,0,0,0,16,64V192a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48Zm0,16V88H32V64Zm0,128H32V104H224v88Z"/></svg>',
	'delivery' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M247.42,117l-14-35A15.93,15.93,0,0,0,218.58,72H184V64a8,8,0,0,0-8-8H24A16,16,0,0,0,8,72V184a16,16,0,0,0,16,16H41a32,32,0,0,0,62,0h50a32,32,0,0,0,62,0h17a16,16,0,0,0,16-16V120A7.94,7.94,0,0,0,247.42,117ZM184,88h34.58l9.6,24H184ZM72,208a16,16,0,1,1,16-16A16,16,0,0,1,72,208Zm112,0a16,16,0,1,1,16-16A16,16,0,0,1,184,208Z"/></svg>',
	'points'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M239.2,97.39a16,16,0,0,0-13.88-11.16l-56.31-4.57L147.44,29.08a16,16,0,0,0-28.88,0L97,81.66l-56.31,4.57A16,16,0,0,0,31.08,114l43.32,37.8-13,55.47A16,16,0,0,0,85.16,224,16.19,16.19,0,0,0,91,222.61L128,202.23l37,20.38A16,16,0,0,0,183.64,207.3l-13-55.47L214,114A16,16,0,0,0,239.2,97.39Z"/></svg>',
	'complete' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z"/></svg>',
	'account'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"/></svg>',
	'failed'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"/></svg>',
);
?>
<div
	class="wifl-profile<?php echo $is_preview ? ' wifl-profile--preview' : ''; ?><?php echo $is_demo ? ' wifl-profile--demo' : ''; ?>"
	data-active-view="<?php echo esc_attr( $active_view ); ?>"
	style="--wifl-member-brand:<?php echo esc_attr( $settings['brand_color'] ); ?>;"
>
	<aside class="wifl-profile__sidebar">
		<div class="wifl-profile__brand">
			<?php if ( $logo_url ) : ?>
				<img class="wifl-profile__logo" src="<?php echo esc_url( $logo_url ); ?>" alt="<?php esc_attr_e( 'Customer profile', 'woo-instagram-follower' ); ?>" />
			<?php else : ?>
				<span class="wifl-profile__logo-mark" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 256 256"><path d="M240,128a15.74,15.74,0,0,1-7.6,13.49L143.14,199.41a16,16,0,0,1-30.28,0L23.6,141.49A15.74,15.74,0,0,1,16,128a16,16,0,0,1,8.38-14.06l33.65-18.64,15.5-27.93a16,16,0,0,1,27.94,0l15.5,27.93,33.65,18.64A16,16,0,0,1,240,128Z"></path></svg>
				</span>
			<?php endif; ?>
			<span class="wifl-profile__brand-name"><?php esc_html_e( 'Customer profile', 'woo-instagram-follower' ); ?></span>
		</div>

		<nav class="wifl-profile__nav" aria-label="<?php esc_attr_e( 'Member navigation', 'woo-instagram-follower' ); ?>">
			<button type="button" class="wifl-profile__nav-item is-active" data-view="home">
				<span class="wifl-profile__nav-icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M219.31,108.68l-80-80a16,16,0,0,0-22.62,0l-80,80A15.87,15.87,0,0,0,32,120v96a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V160h32v56a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V120A15.87,15.87,0,0,0,219.31,108.68ZM208,208H160V152a8,8,0,0,0-8-8H104a8,8,0,0,0-8,8v56H48V120l80-80,80,80Z"></path></svg>
				</span>
				<?php esc_html_e( 'Home', 'woo-instagram-follower' ); ?>
			</button>
			<button type="button" class="wifl-profile__nav-item" data-view="activity">
				<span class="wifl-profile__nav-icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16ZM160,48h40V200H160Zm-56,48H200v16H104Zm-48,48H200v16H56Zm0,32H200v16H56Z"></path></svg>
				</span>
				<?php esc_html_e( 'Activity', 'woo-instagram-follower' ); ?>
			</button>
			<button type="button" class="wifl-profile__nav-item" data-view="orders">
				<span class="wifl-profile__nav-icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Z"></path></svg>
				</span>
				<?php esc_html_e( 'Orders', 'woo-instagram-follower' ); ?>
			</button>
			<button type="button" class="wifl-profile__nav-item" data-view="subscription">
				<span class="wifl-profile__nav-icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm48-88a8,8,0,0,1-8,8H136v32a8,8,0,0,1-16,0V136H88a8,8,0,0,1,0-16h32V88a8,8,0,0,1,16,0v32h32A8,8,0,0,1,176,128Z"/></svg>
				</span>
				<?php esc_html_e( 'Subscription', 'woo-instagram-follower' ); ?>
			</button>
			<button type="button" class="wifl-profile__nav-item wifl-profile__nav-item--parent" data-view="account" aria-expanded="false">
				<span class="wifl-profile__nav-icon" aria-hidden="true">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 256 256"><path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"></path></svg>
				</span>
				<?php esc_html_e( 'Account', 'woo-instagram-follower' ); ?>
			</button>
		</nav>

		<div class="wifl-profile__sidebar-foot">
			<div class="wifl-profile__status">
				<span class="wifl-profile__status-dot" aria-hidden="true"></span>
				<?php echo esc_html( $status_text ); ?>
			</div>
			<div class="wifl-profile__user">
				<span class="wifl-profile__avatar">
					<?php if ( $avatar_url ) : ?>
						<img class="wifl-profile__avatar-img" src="<?php echo esc_url( $avatar_url ); ?>" alt="<?php echo esc_attr( $display_name ); ?>" />
					<?php else : ?>
						<?php echo esc_html( $initials ); ?>
					<?php endif; ?>
				</span>
				<div class="wifl-profile__user-meta">
					<strong class="wifl-profile__user-name"><?php echo esc_html( $display_name ); ?></strong>
					<span class="wifl-profile__user-points"><?php echo esc_html( sprintf( '%s PTS', number_format_i18n( (int) $points ) ) ); ?></span>
				</div>
				<?php if ( ! $is_preview ) : ?>
					<a class="wifl-profile__logout" href="<?php echo esc_url( $logout_url ); ?>" aria-label="<?php esc_attr_e( 'Sign out', 'woo-instagram-follower' ); ?>">
						<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 256 256"><path d="M112,216a8,8,0,0,1-8,8H48a16,16,0,0,1-16-16V48A16,16,0,0,1,48,32h56a8,8,0,0,1,0,16H56V208h48A8,8,0,0,1,112,216Zm109.66-93.66-40-40a8,8,0,0,0-11.32,11.32L204.69,120H104a8,8,0,0,0,0,16h100.69l-34.35,34.34a8,8,0,0,0,11.32,11.32l40-40A8,8,0,0,0,221.66,122.34Z"></path></svg>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</aside>

	<main class="wifl-profile__main">
		<section class="wifl-profile__panel is-active" data-panel="home">
			<header class="wifl-profile__header">
				<div>
					<h1 class="wifl-profile__title"><?php echo esc_html( sprintf( __( 'Welcome back, %s', 'woo-instagram-follower' ), $display_name ) ); ?></h1>
					<p class="wifl-profile__lede"><?php esc_html_e( 'Track deliveries, rewards, and account details from one place.', 'woo-instagram-follower' ); ?></p>
				</div>
				<?php if ( $shop_url ) : ?>
					<a class="wifl-profile__cta" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( '+ New order', 'woo-instagram-follower' ); ?></a>
				<?php endif; ?>
			</header>

			<div class="wifl-profile__stats">
				<article class="wifl-profile__stat">
					<span><?php esc_html_e( 'Total orders', 'woo-instagram-follower' ); ?></span>
					<strong><?php echo esc_html( isset( $stats['total'] ) ? (string) $stats['total'] : '0' ); ?></strong>
				</article>
				<article class="wifl-profile__stat">
					<span><?php esc_html_e( 'In progress', 'woo-instagram-follower' ); ?></span>
					<strong><?php echo esc_html( isset( $stats['in_progress'] ) ? (string) $stats['in_progress'] : '0' ); ?></strong>
				</article>
				<article class="wifl-profile__stat">
					<span><?php esc_html_e( 'Completed', 'woo-instagram-follower' ); ?></span>
					<strong><?php echo esc_html( isset( $stats['completed'] ) ? (string) $stats['completed'] : '0' ); ?></strong>
				</article>
				<article class="wifl-profile__stat wifl-profile__stat--accent">
					<span><?php esc_html_e( 'Reward points', 'woo-instagram-follower' ); ?></span>
					<strong><?php echo esc_html( number_format_i18n( (int) $points ) ); ?></strong>
				</article>
			</div>

			<div class="wifl-profile__card">
				<div class="wifl-profile__card-head">
					<h2><?php esc_html_e( 'Recent activity', 'woo-instagram-follower' ); ?></h2>
					<button type="button" class="wifl-profile__text-btn" data-view-jump="activity"><?php esc_html_e( 'View all', 'woo-instagram-follower' ); ?></button>
				</div>
				<?php if ( empty( $recent ) ) : ?>
					<p class="wifl-profile__muted"><?php esc_html_e( 'No recent activity yet.', 'woo-instagram-follower' ); ?></p>
				<?php else : ?>
					<ul class="wifl-profile__timeline">
						<?php foreach ( $recent as $event ) : ?>
							<?php
							$type = ! empty( $event['type'] ) ? $event['type'] : 'order';
							$icon = isset( $activity_icons[ $type ] ) ? $activity_icons[ $type ] : $activity_icons['order'];
							?>
							<li class="wifl-profile__timeline-item" data-type="<?php echo esc_attr( $type ); ?>">
								<span class="wifl-profile__timeline-icon" aria-hidden="true"><?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<div>
									<strong><?php echo esc_html( $event['title'] ); ?></strong>
									<p><?php echo esc_html( $event['detail'] ); ?></p>
								</div>
								<time><?php echo esc_html( $event['time'] ); ?></time>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		</section>

		<section class="wifl-profile__panel" data-panel="activity" hidden>
			<header class="wifl-profile__header">
				<div>
					<h1 class="wifl-profile__title"><?php esc_html_e( 'Activity', 'woo-instagram-follower' ); ?></h1>
					<p class="wifl-profile__lede"><?php esc_html_e( 'Order updates, payments, deliveries, and rewards.', 'woo-instagram-follower' ); ?></p>
				</div>
			</header>
			<div class="wifl-profile__card">
				<?php if ( empty( $activity ) ) : ?>
					<div class="wifl-profile__empty is-visible">
						<span class="wifl-profile__empty-icon" aria-hidden="true">
							<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256"><path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16ZM160,48h40V200H160Zm-56,48H200v16H104Zm-48,48H200v16H56Zm0,32H200v16H56Z"></path></svg>
						</span>
						<h2><?php esc_html_e( 'No activity yet', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'Your recent order updates will appear here.', 'woo-instagram-follower' ); ?></p>
					</div>
				<?php else : ?>
					<ul class="wifl-profile__timeline">
						<?php foreach ( $activity as $event ) : ?>
							<?php
							$type = ! empty( $event['type'] ) ? $event['type'] : 'order';
							$icon = isset( $activity_icons[ $type ] ) ? $activity_icons[ $type ] : $activity_icons['order'];
							?>
							<li class="wifl-profile__timeline-item" data-type="<?php echo esc_attr( $type ); ?>">
								<span class="wifl-profile__timeline-icon" aria-hidden="true"><?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<div>
									<strong><?php echo esc_html( $event['title'] ); ?></strong>
									<p><?php echo esc_html( $event['detail'] ); ?></p>
								</div>
								<time><?php echo esc_html( $event['time'] ); ?></time>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		</section>

		<section class="wifl-profile__panel" data-panel="orders" hidden>
			<header class="wifl-profile__header wifl-profile__header--orders">
				<div>
					<h1 class="wifl-profile__title"><?php esc_html_e( 'Orders', 'woo-instagram-follower' ); ?></h1>
				</div>
				<div class="wifl-profile__toolbar">
					<label class="wifl-profile__search">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 256 256" aria-hidden="true"><path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"></path></svg>
						<input class="wifl-profile__search-input" type="search" placeholder="<?php esc_attr_e( 'Search orders…', 'woo-instagram-follower' ); ?>" />
					</label>
				</div>
			</header>

			<div class="wifl-profile__tabs" role="tablist" aria-label="<?php esc_attr_e( 'Order filters', 'woo-instagram-follower' ); ?>">
				<button type="button" class="wifl-profile__tab is-active" role="tab" data-filter="all" aria-selected="true"><?php esc_html_e( 'All', 'woo-instagram-follower' ); ?></button>
				<button type="button" class="wifl-profile__tab" role="tab" data-filter="in-progress" aria-selected="false"><?php esc_html_e( 'In progress', 'woo-instagram-follower' ); ?></button>
				<button type="button" class="wifl-profile__tab" role="tab" data-filter="completed" aria-selected="false"><?php esc_html_e( 'Completed', 'woo-instagram-follower' ); ?></button>
				<button type="button" class="wifl-profile__tab" role="tab" data-filter="failed" aria-selected="false"><?php esc_html_e( 'Failed', 'woo-instagram-follower' ); ?></button>
			</div>

			<div class="wifl-profile__card wifl-profile__orders-wrap">
				<div class="wifl-profile__empty wifl-profile__orders-empty" hidden>
					<span class="wifl-profile__empty-icon" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256"><path d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Z"></path></svg>
					</span>
					<h2><?php esc_html_e( 'No orders match', 'woo-instagram-follower' ); ?></h2>
					<p><?php esc_html_e( 'Try a different search or status filter.', 'woo-instagram-follower' ); ?></p>
					<button type="button" class="wifl-profile__ghost-btn" data-clear-filters><?php esc_html_e( 'Clear filters', 'woo-instagram-follower' ); ?></button>
				</div>

				<?php if ( empty( $orders ) ) : ?>
					<div class="wifl-profile__empty wifl-profile__orders-empty is-visible">
						<span class="wifl-profile__empty-icon" aria-hidden="true">
							<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256"><path d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Z"></path></svg>
						</span>
						<h2><?php esc_html_e( 'No orders yet', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'When you place an order, it will show up here.', 'woo-instagram-follower' ); ?></p>
						<?php if ( $shop_url ) : ?>
							<a class="wifl-profile__ghost-btn" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( '+ Start a new order', 'woo-instagram-follower' ); ?></a>
						<?php endif; ?>
					</div>
				<?php else : ?>
					<ul class="wifl-profile__orders">
						<?php foreach ( $orders as $order_item ) : ?>
							<?php
							$search = strtolower(
								$order_item['number'] . ' ' .
								$order_item['status_label'] . ' ' .
								( isset( $order_item['product'] ) ? $order_item['product'] : '' ) . ' ' .
								( isset( $order_item['qty'] ) ? $order_item['qty'] : '' )
							);
							?>
							<li
								class="wifl-profile__order"
								data-status-group="<?php echo esc_attr( $order_item['status_group'] ); ?>"
								data-search="<?php echo esc_attr( $search ); ?>"
							>
								<div class="wifl-profile__order-icon" aria-hidden="true">
									<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 256 256"><path d="M224,48H32a8,8,0,0,0-8,8V200a8,8,0,0,0,8,8H224a8,8,0,0,0,8-8V56A8,8,0,0,0,224,48Zm-8,144H40V64H216Z"/></svg>
								</div>
								<div class="wifl-profile__order-main">
									<strong><?php echo esc_html( ! empty( $order_item['product'] ) ? $order_item['product'] : sprintf( '#%s', $order_item['number'] ) ); ?></strong>
									<span class="wifl-profile__order-sub">
										<?php
										$bits = array( '#' . $order_item['number'] );
										if ( ! empty( $order_item['qty'] ) ) {
											$bits[] = $order_item['qty'];
										}
										echo esc_html( implode( ' · ', $bits ) );
										?>
									</span>
								</div>
								<span class="wifl-profile__order-status wifl-profile__order-status--<?php echo esc_attr( $order_item['status_group'] ); ?>">
									<?php echo esc_html( $order_item['status_label'] ); ?>
								</span>
								<div class="wifl-profile__order-meta">
									<time><?php echo esc_html( $order_item['date'] ); ?></time>
									<span class="wifl-profile__order-total"><?php echo wp_kses_post( $order_item['total'] ); ?></span>
								</div>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		</section>

		<section class="wifl-profile__panel" data-panel="subscription" hidden>
			<header class="wifl-profile__header">
				<div>
					<h1 class="wifl-profile__title"><?php esc_html_e( 'Subscription', 'woo-instagram-follower' ); ?></h1>
					<p class="wifl-profile__lede"><?php esc_html_e( 'Your plan details, expiry date, and renew options.', 'woo-instagram-follower' ); ?></p>
				</div>
			</header>

			<?php if ( empty( $subscriptions ) ) : ?>
				<div class="wifl-profile__card">
					<div class="wifl-profile__empty is-visible">
						<h2><?php esc_html_e( 'No subscriptions', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'When you purchase a subscription plan, it will appear here with billing and expiry details.', 'woo-instagram-follower' ); ?></p>
						<?php if ( ! empty( $shop_url ) ) : ?>
							<p><a class="wifl-profile__btn" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Browse plans', 'woo-instagram-follower' ); ?></a></p>
						<?php endif; ?>
					</div>
				</div>
			<?php else : ?>
				<div class="wifl-profile__subs">
					<?php foreach ( $subscriptions as $sub ) : ?>
						<article class="wifl-profile__sub" data-status="<?php echo esc_attr( $sub['status'] ); ?>">
							<div class="wifl-profile__sub-head">
								<div>
									<h2 class="wifl-profile__sub-name"><?php echo esc_html( $sub['name'] ); ?></h2>
									<p class="wifl-profile__sub-package"><?php echo esc_html( $sub['package'] ); ?></p>
								</div>
								<span class="wifl-profile__sub-status wifl-profile__sub-status--<?php echo esc_attr( $sub['status'] ); ?>">
									<?php echo esc_html( $sub['status_label'] ); ?>
								</span>
							</div>
							<dl class="wifl-profile__sub-meta">
								<div><dt><?php esc_html_e( 'Plan ID', 'woo-instagram-follower' ); ?></dt><dd><?php echo esc_html( $sub['id'] ); ?></dd></div>
								<div><dt><?php esc_html_e( 'Price', 'woo-instagram-follower' ); ?></dt><dd><?php echo wp_kses_post( $sub['price'] ); ?></dd></div>
								<div><dt><?php esc_html_e( 'Billing', 'woo-instagram-follower' ); ?></dt><dd><?php echo esc_html( $sub['cycle'] ); ?></dd></div>
								<div><dt><?php esc_html_e( 'Started', 'woo-instagram-follower' ); ?></dt><dd><?php echo esc_html( $sub['started'] ); ?></dd></div>
								<div><dt><?php esc_html_e( 'Expiry date', 'woo-instagram-follower' ); ?></dt><dd><?php echo esc_html( ! empty( $sub['expires'] ) ? $sub['expires'] : '—' ); ?></dd></div>
								<div><dt><?php esc_html_e( 'Next renewal', 'woo-instagram-follower' ); ?></dt><dd><?php echo esc_html( $sub['renews'] ); ?></dd></div>
								<div><dt><?php esc_html_e( 'Last payment', 'woo-instagram-follower' ); ?></dt><dd><?php echo esc_html( $sub['last_payment'] ); ?></dd></div>
								<div><dt><?php esc_html_e( 'Payment method', 'woo-instagram-follower' ); ?></dt><dd><?php echo esc_html( $sub['method'] ); ?></dd></div>
								<?php if ( ! empty( $sub['order_id'] ) ) : ?>
									<div>
										<dt><?php esc_html_e( 'Order', 'woo-instagram-follower' ); ?></dt>
										<dd>
											<?php if ( ! empty( $sub['order_url'] ) ) : ?>
												<a href="<?php echo esc_url( $sub['order_url'] ); ?>">#<?php echo esc_html( (string) $sub['order_id'] ); ?></a>
											<?php else : ?>
												#<?php echo esc_html( (string) $sub['order_id'] ); ?>
											<?php endif; ?>
										</dd>
									</div>
								<?php endif; ?>
							</dl>
							<?php if ( ! empty( $sub['note'] ) ) : ?>
								<p class="wifl-profile__sub-note"><?php echo esc_html( $sub['note'] ); ?></p>
							<?php endif; ?>
							<?php if ( ! empty( $sub['renew_url'] ) ) : ?>
								<div class="wifl-profile__sub-actions">
									<a class="wifl-profile__btn wifl-profile__btn--renew" href="<?php echo esc_url( $sub['renew_url'] ); ?>">
										<?php echo esc_html( 'expired' === $sub['status'] ? __( 'Renew now', 'woo-instagram-follower' ) : __( 'Renew / Extend', 'woo-instagram-follower' ) ); ?>
									</a>
								</div>
							<?php endif; ?>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</section>

		<section class="wifl-profile__panel" data-panel="account" hidden>
			<header class="wifl-profile__header">
				<div>
					<h1 class="wifl-profile__title"><?php esc_html_e( 'Account', 'woo-instagram-follower' ); ?></h1>
					<p class="wifl-profile__lede"><?php esc_html_e( 'Update your photo, contact details, and billing information.', 'woo-instagram-follower' ); ?></p>
				</div>
			</header>

			<?php if ( ! empty( $notice['message'] ) ) : ?>
				<div class="wifl-member-notice wifl-member-notice--<?php echo esc_attr( $notice['type'] ); ?>">
					<?php echo esc_html( $notice['message'] ); ?>
				</div>
			<?php endif; ?>

			<form class="wifl-profile__account-form" method="post" enctype="multipart/form-data" <?php echo $can_edit ? '' : 'onsubmit="return false;"'; ?>>
				<?php if ( $can_edit ) : ?>
					<?php wp_nonce_field( 'wifl_update_profile', 'wifl_profile_nonce' ); ?>
					<input type="hidden" name="wifl_update_profile" value="1" />
				<?php endif; ?>

				<div class="wifl-profile__account-hero">
					<label class="wifl-profile__avatar-upload">
						<span class="wifl-profile__avatar wifl-profile__avatar--lg" data-avatar-preview>
							<?php if ( $avatar_url ) : ?>
								<img class="wifl-profile__avatar-img" src="<?php echo esc_url( $avatar_url ); ?>" alt="<?php echo esc_attr( $display_name ); ?>" />
							<?php else : ?>
								<span class="wifl-profile__avatar-initials"><?php echo esc_html( $initials ); ?></span>
							<?php endif; ?>
						</span>
						<?php if ( $can_edit ) : ?>
							<span class="wifl-profile__avatar-edit"><?php esc_html_e( 'Change photo', 'woo-instagram-follower' ); ?></span>
							<input class="wifl-profile__avatar-input" type="file" name="wifl_avatar" accept="image/jpeg,image/png,image/webp,image/gif" />
						<?php endif; ?>
					</label>
					<div>
						<strong class="wifl-profile__account-name"><?php echo esc_html( $display_name ); ?></strong>
						<p><?php echo esc_html( $account['email'] ); ?></p>
						<span class="wifl-profile__plan"><?php echo esc_html( $account['plan'] ); ?></span>
						<?php if ( $can_edit && $avatar_url ) : ?>
							<label class="wifl-profile__remove-photo">
								<input type="checkbox" name="wifl_remove_avatar" value="1" />
								<?php esc_html_e( 'Remove photo', 'woo-instagram-follower' ); ?>
							</label>
						<?php endif; ?>
					</div>
				</div>

				<div class="wifl-profile__account-grid">
					<div class="wifl-profile__card">
						<h2><?php esc_html_e( 'Profile', 'woo-instagram-follower' ); ?></h2>
						<div class="wifl-profile__fields">
							<label class="wifl-profile__field">
								<span><?php esc_html_e( 'Display name', 'woo-instagram-follower' ); ?></span>
								<input type="text" name="wifl_display_name" value="<?php echo esc_attr( $account['display_name'] ); ?>" <?php disabled( ! $can_edit ); ?> />
							</label>
							<div class="wifl-profile__field-row">
								<label class="wifl-profile__field">
									<span><?php esc_html_e( 'First name', 'woo-instagram-follower' ); ?></span>
									<input type="text" name="wifl_first_name" value="<?php echo esc_attr( $account['first_name'] ); ?>" <?php disabled( ! $can_edit ); ?> />
								</label>
								<label class="wifl-profile__field">
									<span><?php esc_html_e( 'Last name', 'woo-instagram-follower' ); ?></span>
									<input type="text" name="wifl_last_name" value="<?php echo esc_attr( $account['last_name'] ); ?>" <?php disabled( ! $can_edit ); ?> />
								</label>
							</div>
							<label class="wifl-profile__field">
								<span><?php esc_html_e( 'Email', 'woo-instagram-follower' ); ?></span>
								<input type="email" name="wifl_email" value="<?php echo esc_attr( $account['email'] ); ?>" <?php disabled( ! $can_edit ); ?> required />
							</label>
							<label class="wifl-profile__field">
								<span><?php esc_html_e( 'Phone', 'woo-instagram-follower' ); ?></span>
								<input type="text" name="wifl_phone" value="<?php echo esc_attr( $account['phone'] ); ?>" placeholder="<?php esc_attr_e( 'Add a phone number', 'woo-instagram-follower' ); ?>" <?php disabled( ! $can_edit ); ?> />
							</label>
							<label class="wifl-profile__field">
								<span><?php esc_html_e( 'Location', 'woo-instagram-follower' ); ?></span>
								<input type="text" name="wifl_location" value="<?php echo esc_attr( $account['location'] ); ?>" placeholder="<?php esc_attr_e( 'City, country', 'woo-instagram-follower' ); ?>" <?php disabled( ! $can_edit ); ?> />
							</label>
							<p class="wifl-profile__readonly"><span><?php esc_html_e( 'Username', 'woo-instagram-follower' ); ?></span><strong><?php echo esc_html( $account['username'] ); ?></strong></p>
							<p class="wifl-profile__readonly"><span><?php esc_html_e( 'Member since', 'woo-instagram-follower' ); ?></span><strong><?php echo esc_html( $account['member_since'] ); ?></strong></p>
						</div>
					</div>
					<div class="wifl-profile__card">
						<h2><?php esc_html_e( 'Billing & alerts', 'woo-instagram-follower' ); ?></h2>
						<div class="wifl-profile__fields">
							<label class="wifl-profile__field">
								<span><?php esc_html_e( 'Billing address', 'woo-instagram-follower' ); ?></span>
								<textarea name="wifl_billing" rows="3" placeholder="<?php esc_attr_e( 'Street, city, postcode', 'woo-instagram-follower' ); ?>" <?php disabled( ! $can_edit ); ?>><?php echo esc_textarea( $account['billing'] ); ?></textarea>
							</label>
							<label class="wifl-profile__check">
								<input type="checkbox" name="wifl_notify_email" value="1" <?php checked( $account['notify_email'], 'yes' ); ?> <?php disabled( ! $can_edit ); ?> />
								<span><?php esc_html_e( 'Email alerts for order updates', 'woo-instagram-follower' ); ?></span>
							</label>
							<label class="wifl-profile__check">
								<input type="checkbox" name="wifl_notify_sms" value="1" <?php checked( $account['notify_sms'], 'yes' ); ?> <?php disabled( ! $can_edit ); ?> />
								<span><?php esc_html_e( 'SMS alerts', 'woo-instagram-follower' ); ?></span>
							</label>
							<p class="wifl-profile__readonly"><span><?php esc_html_e( 'Plan', 'woo-instagram-follower' ); ?></span><strong><?php echo esc_html( $account['plan'] ); ?></strong></p>
							<p class="wifl-profile__readonly"><span><?php esc_html_e( 'Points', 'woo-instagram-follower' ); ?></span><strong><?php echo esc_html( number_format_i18n( (int) $account['points'] ) ); ?></strong></p>
						</div>
					</div>
				</div>

				<?php if ( $can_edit ) : ?>
					<div class="wifl-profile__account-actions">
						<button type="submit" class="wifl-profile__cta"><?php esc_html_e( 'Save changes', 'woo-instagram-follower' ); ?></button>
					</div>
				<?php endif; ?>
			</form>
		</section>
	</main>
</div>
