<?php
/**
 * SMMGen API settings, connection test, and HTTP client.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Smm_Api {

	const OPTION = 'wifl_smm_api';
	const PAGE   = 'wifl-smm-api';

	/**
	 * @var Smm_Api|null
	 */
	private static $instance = null;

	/**
	 * @return Smm_Api
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ), 11 );
		add_action( 'admin_init', array( $this, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled' => 'yes',
			'api_url' => 'https://my.smmgen.com/api/v2',
			'api_key' => '',
		);
	}

	/**
	 * @return array
	 */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * @return bool
	 */
	public static function is_enabled() {
		$s = self::get();
		return 'yes' === $s['enabled'] && '' !== $s['api_url'] && '' !== $s['api_key'];
	}

	public function menu() {
		add_submenu_page(
			Member\Admin::PAGE,
			esc_html__( 'API', 'woo-instagram-follower' ),
			esc_html__( 'API', 'woo-instagram-follower' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' )
		);
	}

	public function assets( $hook ) {
		if ( ! $this->is_api_page( $hook ) ) {
			return;
		}

		wp_enqueue_style(
			'wifl-member-admin',
			WIFL_URL . 'assets/css/member-admin.css',
			array(),
			WIFL_VERSION
		);
	}

	/**
	 * @param string $hook Hook.
	 * @return bool
	 */
	private function is_api_page( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( self::PAGE === $page ) {
			return true;
		}

		return Member\Admin::PAGE . '_page_' . self::PAGE === $hook;
	}

	public function save() {
		if ( ! isset( $_POST['wifl_smm_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_smm_nonce'] ) ), 'wifl_smm_save' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$raw = isset( $_POST['wifl_smm'] ) && is_array( $_POST['wifl_smm'] ) ? wp_unslash( $_POST['wifl_smm'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$settings = self::sanitize( $raw );
		update_option( self::OPTION, $settings, false );

		if ( isset( $_POST['wifl_smm_test'] ) ) {
			$result = self::test_connection( $settings );
			if ( $result['ok'] ) {
				add_settings_error( 'wifl_smm', 'tested', $result['message'], 'updated' );
			} else {
				add_settings_error( 'wifl_smm', 'test_fail', $result['message'], 'error' );
			}
			return;
		}

		if ( isset( $_POST['wifl_smm_save'] ) ) {
			add_settings_error( 'wifl_smm', 'saved', esc_html__( 'API settings saved.', 'woo-instagram-follower' ), 'updated' );
		}
	}

	/**
	 * @param array $raw Raw POST.
	 * @return array
	 */
	public static function sanitize( $raw ) {
		$existing = self::get();
		$url      = isset( $raw['api_url'] ) ? esc_url_raw( trim( (string) $raw['api_url'] ) ) : '';
		$key      = isset( $raw['api_key'] ) ? trim( (string) $raw['api_key'] ) : '';

		if ( '' === $url ) {
			$url = self::defaults()['api_url'];
		}

		// Never echo the real key into the form. Empty submit = keep saved key.
		if ( '' === $key || self::is_placeholder_key( $key ) ) {
			$key = isset( $existing['api_key'] ) ? (string) $existing['api_key'] : '';
		} else {
			$key = sanitize_text_field( $key );
		}

		return array(
			'enabled' => ! empty( $raw['enabled'] ) ? 'yes' : 'no',
			'api_url' => untrailingslashit( $url ),
			'api_key' => $key,
		);
	}

	/**
	 * True when the posted value is a mask / blank placeholder, not a real key.
	 *
	 * @param string $key Posted key.
	 * @return bool
	 */
	public static function is_placeholder_key( $key ) {
		$key = (string) $key;
		if ( '' === $key ) {
			return true;
		}
		// Bullet / asterisk masks (••••, ****, etc.).
		if ( preg_match( '/^[\x{2022}\x{25CF}\x{00B7}\*\u2022\u25CF]+$/u', $key ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Display-only hint that a key exists (never put the full key in HTML).
	 *
	 * @param string $key Stored key.
	 * @return string
	 */
	public static function key_status_label( $key ) {
		$key = (string) $key;
		if ( '' === $key ) {
			return __( 'No key saved yet. Paste your API key to connect.', 'woo-instagram-follower' );
		}
		return __( 'Key saved on the server. Leave blank to keep it — the real key is never shown in this page.', 'woo-instagram-follower' );
	}

	/**
	 * @param array $settings Settings.
	 * @return array{ok:bool,message:string,data:array}
	 */
	public static function test_connection( $settings = array() ) {
		if ( empty( $settings ) ) {
			$settings = self::get();
		}

		$response = self::request( 'balance', array(), $settings );
		if ( is_wp_error( $response ) ) {
			return array(
				'ok'      => false,
				'message' => $response->get_error_message(),
				'data'    => array(),
			);
		}

		if ( ! empty( $response['error'] ) ) {
			return array(
				'ok'      => false,
				'message' => (string) $response['error'],
				'data'    => $response,
			);
		}

		$balance  = isset( $response['balance'] ) ? $response['balance'] : '';
		$currency = isset( $response['currency'] ) ? $response['currency'] : '';
		$message  = sprintf(
			/* translators: 1: balance, 2: currency */
			__( 'Connected. Balance: %1$s %2$s', 'woo-instagram-follower' ),
			$balance,
			$currency
		);

		return array(
			'ok'      => true,
			'message' => $message,
			'data'    => $response,
		);
	}

	/**
	 * @param string $action   add|status|cancel|services|balance.
	 * @param array  $params   Extra params.
	 * @param array  $settings Optional settings override.
	 * @return array|\WP_Error
	 */
	public static function request( $action, $params = array(), $settings = array() ) {
		if ( empty( $settings ) ) {
			$settings = self::get();
		}

		$url = isset( $settings['api_url'] ) ? $settings['api_url'] : '';
		$key = isset( $settings['api_key'] ) ? $settings['api_key'] : '';

		if ( '' === $url || '' === $key ) {
			return new \WP_Error( 'wifl_smm_config', __( 'API URL and key are required.', 'woo-instagram-follower' ) );
		}

		$body = array_merge(
			array(
				'key'    => $key,
				'action' => sanitize_key( $action ),
			),
			$params
		);

		$http = wp_remote_post(
			$url,
			array(
				'timeout' => 20,
				'headers' => array(
					'Accept' => 'application/json',
				),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $http ) ) {
			return $http;
		}

		$code = (int) wp_remote_retrieve_response_code( $http );
		$raw  = wp_remote_retrieve_body( $http );
		$data = json_decode( $raw, true );

		if ( $code < 200 || $code >= 300 ) {
			return new \WP_Error(
				'wifl_smm_http',
				sprintf(
					/* translators: %d: HTTP status */
					__( 'API request failed (HTTP %d).', 'woo-instagram-follower' ),
					$code
				)
			);
		}

		if ( ! is_array( $data ) ) {
			return new \WP_Error( 'wifl_smm_json', __( 'API returned an invalid response.', 'woo-instagram-follower' ) );
		}

		return $data;
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$s = self::get();
		settings_errors( 'wifl_smm' );
		?>
		<div class="wrap wifl-member-admin">
			<h1 class="screen-reader-text"><?php esc_html_e( 'API', 'woo-instagram-follower' ); ?></h1>
			<div class="wifl-admin-hero">
				<div class="wifl-admin-hero__copy">
					<p class="wifl-admin-hero__kicker"><?php echo esc_html( Member\Settings::get()['membership_name'] ); ?></p>
					<p class="wifl-admin-hero__heading"><?php esc_html_e( 'API', 'woo-instagram-follower' ); ?></p>
					<p class="wifl-admin-hero__intro"><?php esc_html_e( 'Connect SMMGen so paid WooCommerce orders can be sent to the panel automatically.', 'woo-instagram-follower' ); ?></p>
				</div>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ); ?>" class="wifl-admin-form">
				<?php wp_nonce_field( 'wifl_smm_save', 'wifl_smm_nonce' ); ?>

				<section class="wifl-admin-panel">
					<header class="wifl-admin-panel__head">
						<div>
							<h2><?php esc_html_e( 'SMMGen connection', 'woo-instagram-follower' ); ?></h2>
							<p><?php esc_html_e( 'Use your panel API URL and key. The key stays on the server and is never shown on the site.', 'woo-instagram-follower' ); ?></p>
						</div>
					</header>
					<div class="wifl-admin-grid">
						<label class="wifl-admin-check">
							<input type="checkbox" name="wifl_smm[enabled]" value="yes" <?php checked( $s['enabled'], 'yes' ); ?> />
							<span><?php esc_html_e( 'Enable SMM API fulfillment', 'woo-instagram-follower' ); ?></span>
						</label>
						<label class="wifl-admin-wide">
							<span><?php esc_html_e( 'API URL', 'woo-instagram-follower' ); ?></span>
							<input type="url" name="wifl_smm[api_url]" value="<?php echo esc_attr( $s['api_url'] ); ?>" placeholder="https://my.smmgen.com/api/v2" />
						</label>
						<label class="wifl-admin-wide">
							<span><?php esc_html_e( 'API Key', 'woo-instagram-follower' ); ?></span>
							<input
								type="password"
								name="wifl_smm[api_key]"
								value=""
								autocomplete="new-password"
								placeholder="<?php echo esc_attr( ! empty( $s['api_key'] ) ? '••••••••••••••••' : '' ); ?>"
								data-lpignore="true"
								data-1p-ignore="true"
							/>
							<small class="wifl-admin-hint"><?php echo esc_html( self::key_status_label( isset( $s['api_key'] ) ? $s['api_key'] : '' ) ); ?></small>
						</label>
					</div>
				</section>

				<div class="wifl-admin-actions">
					<?php submit_button( esc_html__( 'Save settings', 'woo-instagram-follower' ), 'primary wifl-admin-btn', 'wifl_smm_save', false ); ?>
					<?php submit_button( esc_html__( 'Test connection', 'woo-instagram-follower' ), 'secondary', 'wifl_smm_test', false ); ?>
				</div>
			</form>
		</div>
		<?php
	}
}
