<?php
/**
 * Admin New Order page — place SMM orders via API (no SMMGen website login).
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Smm_Order {

	const PAGE          = 'wifl-smm-order';
	const TRANSIENT_SVC = 'wifl_smm_services_v1';
	const CACHE_TTL     = 15 * MINUTE_IN_SECONDS;

	/**
	 * @var Smm_Order|null
	 */
	private static $instance = null;

	/**
	 * @return Smm_Order
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ), 12 );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'wp_ajax_wifl_smm_services', array( $this, 'ajax_services' ) );
		add_action( 'wp_ajax_wifl_smm_place_order', array( $this, 'ajax_place_order' ) );
		add_action( 'wp_ajax_wifl_smm_balance', array( $this, 'ajax_balance' ) );
		add_action( 'wp_ajax_wifl_smm_refresh_services', array( $this, 'ajax_refresh_services' ) );
	}

	public function menu() {
		add_submenu_page(
			Member\Admin::PAGE,
			esc_html__( 'SMM New Order', 'woo-instagram-follower' ),
			esc_html__( 'SMM New Order', 'woo-instagram-follower' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' )
		);
	}

	/**
	 * @param string $hook Hook.
	 */
	public function assets( $hook ) {
		if ( ! $this->is_page( $hook ) ) {
			return;
		}

		wp_enqueue_style(
			'wifl-member-admin',
			WIFL_URL . 'assets/css/member-admin.css',
			array(),
			WIFL_VERSION
		);
		wp_enqueue_style(
			'wifl-smm-order',
			WIFL_URL . 'assets/css/smm-order.css',
			array( 'wifl-member-admin' ),
			WIFL_VERSION
		);
		wp_enqueue_script(
			'wifl-smm-order',
			WIFL_URL . 'assets/js/smm-order.js',
			array(),
			WIFL_VERSION,
			true
		);

		$connected = $this->is_connected();
		$balance   = array();
		if ( $connected ) {
			$balance = $this->fetch_balance();
		}

		wp_localize_script(
			'wifl-smm-order',
			'wiflSmmOrder',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'wifl_smm_order' ),
				'connected' => $connected,
				'apiUrl'    => admin_url( 'admin.php?page=' . Smm_Api::PAGE ),
				'balance'   => $balance,
				'i18n'      => array(
					'loading'      => esc_html__( 'Loading services…', 'woo-instagram-follower' ),
					'selectCat'    => esc_html__( 'Select a category', 'woo-instagram-follower' ),
					'selectSvc'    => esc_html__( 'Select a service', 'woo-instagram-follower' ),
					'all'          => esc_html__( 'Everything', 'woo-instagram-follower' ),
					'minMax'       => esc_html__( 'Min: %1$s — Max: %2$s', 'woo-instagram-follower' ),
					'required'     => esc_html__( 'Category, service, link, and quantity are required.', 'woo-instagram-follower' ),
					'qtyRange'     => esc_html__( 'Quantity must be between %1$s and %2$s.', 'woo-instagram-follower' ),
					'submitting'   => esc_html__( 'Submitting…', 'woo-instagram-follower' ),
					'submit'       => esc_html__( 'New order', 'woo-instagram-follower' ),
					'success'      => esc_html__( 'Order placed. Provider ID: %s', 'woo-instagram-follower' ),
					'error'        => esc_html__( 'Could not place the order.', 'woo-instagram-follower' ),
					'noDesc'       => esc_html__( 'Select a service to see details.', 'woo-instagram-follower' ),
					'perThousand'  => esc_html__( '%s per 1000', 'woo-instagram-follower' ),
					'charge'       => esc_html__( 'Charge', 'woo-instagram-follower' ),
					'refreshOk'    => esc_html__( 'Services refreshed.', 'woo-instagram-follower' ),
					'notConnected' => esc_html__( 'Connect the SMM API first.', 'woo-instagram-follower' ),
				),
			)
		);
	}

	/**
	 * @param string $hook Hook.
	 * @return bool
	 */
	private function is_page( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( self::PAGE === $page ) {
			return true;
		}
		return Member\Admin::PAGE . '_page_' . self::PAGE === $hook;
	}

	/**
	 * @return bool
	 */
	private function is_connected() {
		$s = Smm_Api::get();
		return '' !== $s['api_url'] && '' !== $s['api_key'];
	}

	/**
	 * @return array{balance?:string,currency?:string,ok:bool,message?:string}
	 */
	private function fetch_balance() {
		$response = Smm_Api::request( 'balance' );
		if ( is_wp_error( $response ) ) {
			return array(
				'ok'      => false,
				'message' => $response->get_error_message(),
			);
		}
		if ( ! empty( $response['error'] ) ) {
			return array(
				'ok'      => false,
				'message' => (string) $response['error'],
			);
		}
		return array(
			'ok'       => true,
			'balance'  => isset( $response['balance'] ) ? (string) $response['balance'] : '',
			'currency' => isset( $response['currency'] ) ? (string) $response['currency'] : '',
		);
	}

	/**
	 * @param bool $force Force refresh.
	 * @return array|\WP_Error
	 */
	public static function get_services( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( self::TRANSIENT_SVC );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$response = Smm_Api::request( 'services' );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( ! empty( $response['error'] ) ) {
			return new \WP_Error( 'wifl_smm_svc', (string) $response['error'] );
		}
		if ( ! is_array( $response ) ) {
			return new \WP_Error( 'wifl_smm_svc', __( 'Services list is empty or invalid.', 'woo-instagram-follower' ) );
		}

		$out = array();
		foreach ( $response as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$id = isset( $row['service'] ) ? absint( $row['service'] ) : 0;
			if ( $id < 1 ) {
				continue;
			}
			$out[] = array(
				'id'       => $id,
				'name'     => isset( $row['name'] ) ? (string) $row['name'] : '',
				'type'     => isset( $row['type'] ) ? (string) $row['type'] : '',
				'category' => isset( $row['category'] ) ? (string) $row['category'] : __( 'Other', 'woo-instagram-follower' ),
				'rate'     => isset( $row['rate'] ) ? (string) $row['rate'] : '0',
				'min'      => isset( $row['min'] ) ? (string) $row['min'] : '1',
				'max'      => isset( $row['max'] ) ? (string) $row['max'] : '0',
				'refill'   => ! empty( $row['refill'] ),
				'cancel'   => ! empty( $row['cancel'] ),
				'desc'     => isset( $row['desc'] ) ? (string) $row['desc'] : ( isset( $row['description'] ) ? (string) $row['description'] : '' ),
			);
		}

		set_transient( self::TRANSIENT_SVC, $out, self::CACHE_TTL );
		return $out;
	}

	/**
	 * @param string $category Category.
	 * @return string
	 */
	public static function platform_from_category( $category ) {
		$c   = strtolower( (string) $category );
		$map = array(
			'instagram' => 'instagram',
			'facebook'  => 'facebook',
			'youtube'   => 'youtube',
			'twitter'   => 'twitter',
			'x ('       => 'twitter',
			'spotify'   => 'spotify',
			'tiktok'    => 'tiktok',
			'telegram'  => 'telegram',
			'linkedin'  => 'linkedin',
			'discord'   => 'discord',
			'traffic'   => 'traffic',
			'website'   => 'traffic',
		);
		foreach ( $map as $needle => $key ) {
			if ( false !== strpos( $c, $needle ) ) {
				return $key;
			}
		}
		return 'others';
	}

	public function ajax_services() {
		check_ajax_referer( 'wifl_smm_order', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'woo-instagram-follower' ) ), 403 );
		}
		if ( ! $this->is_connected() ) {
			wp_send_json_error( array( 'message' => __( 'Connect the SMM API first.', 'woo-instagram-follower' ) ), 400 );
		}

		$services = self::get_services( false );
		if ( is_wp_error( $services ) ) {
			wp_send_json_error( array( 'message' => $services->get_error_message() ), 500 );
		}

		wp_send_json_success(
			array(
				'services'   => $services,
				'categories' => $this->unique_categories( $services ),
				'platforms'  => $this->platform_tabs( $services ),
			)
		);
	}

	public function ajax_refresh_services() {
		check_ajax_referer( 'wifl_smm_order', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'woo-instagram-follower' ) ), 403 );
		}
		delete_transient( self::TRANSIENT_SVC );
		$services = self::get_services( true );
		if ( is_wp_error( $services ) ) {
			wp_send_json_error( array( 'message' => $services->get_error_message() ), 500 );
		}
		wp_send_json_success(
			array(
				'services'   => $services,
				'categories' => $this->unique_categories( $services ),
				'platforms'  => $this->platform_tabs( $services ),
			)
		);
	}

	public function ajax_balance() {
		check_ajax_referer( 'wifl_smm_order', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'woo-instagram-follower' ) ), 403 );
		}
		$data = $this->fetch_balance();
		if ( empty( $data['ok'] ) ) {
			wp_send_json_error( $data, 500 );
		}
		wp_send_json_success( $data );
	}

	public function ajax_place_order() {
		check_ajax_referer( 'wifl_smm_order', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'woo-instagram-follower' ) ), 403 );
		}
		if ( ! $this->is_connected() ) {
			wp_send_json_error( array( 'message' => __( 'Connect the SMM API first.', 'woo-instagram-follower' ) ), 400 );
		}

		$service  = isset( $_POST['service'] ) ? absint( wp_unslash( $_POST['service'] ) ) : 0;
		$link     = isset( $_POST['link'] ) ? esc_url_raw( trim( (string) wp_unslash( $_POST['link'] ) ) ) : '';
		$quantity = isset( $_POST['quantity'] ) ? preg_replace( '/[^0-9]/', '', (string) wp_unslash( $_POST['quantity'] ) ) : '';
		$note     = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '';

		if ( $service < 1 || '' === $link || '' === $quantity ) {
			wp_send_json_error( array( 'message' => __( 'Category, service, link, and quantity are required.', 'woo-instagram-follower' ) ), 400 );
		}

		$qty = (int) $quantity;
		if ( $qty < 1 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid quantity.', 'woo-instagram-follower' ) ), 400 );
		}

		$services = self::get_services( false );
		if ( ! is_wp_error( $services ) ) {
			foreach ( $services as $row ) {
				if ( (int) $row['id'] !== $service ) {
					continue;
				}
				$min = (int) preg_replace( '/[^0-9]/', '', (string) $row['min'] );
				$max = (int) preg_replace( '/[^0-9]/', '', (string) $row['max'] );
				if ( ( $min > 0 && $qty < $min ) || ( $max > 0 && $qty > $max ) ) {
					wp_send_json_error(
						array(
							'message' => sprintf(
								/* translators: 1: min 2: max */
								__( 'Quantity must be between %1$s and %2$s.', 'woo-instagram-follower' ),
								number_format_i18n( $min ),
								number_format_i18n( $max )
							),
						),
						400
					);
				}
				break;
			}
		}

		$response = Smm_Api::request(
			'add',
			array(
				'service'  => $service,
				'link'     => $link,
				'quantity' => $qty,
			)
		);

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => $response->get_error_message() ), 500 );
		}
		if ( ! empty( $response['error'] ) ) {
			wp_send_json_error( array( 'message' => (string) $response['error'] ), 400 );
		}

		$order_id = isset( $response['order'] ) ? (string) $response['order'] : '';
		if ( '' === $order_id ) {
			wp_send_json_error( array( 'message' => __( 'API did not return an order ID.', 'woo-instagram-follower' ) ), 500 );
		}

		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->info(
				sprintf(
					'Manual SMM order #%s service=%d qty=%d link=%s note=%s by user #%d',
					$order_id,
					$service,
					$qty,
					$link,
					$note,
					get_current_user_id()
				),
				array( 'source' => 'wifl-smm' )
			);
		}

		$balance = $this->fetch_balance();

		wp_send_json_success(
			array(
				'order'   => $order_id,
				'balance' => $balance,
				'message' => sprintf(
					/* translators: %s provider order id */
					__( 'Order placed. Provider ID: %s', 'woo-instagram-follower' ),
					$order_id
				),
			)
		);
	}

	/**
	 * @param array $services Services.
	 * @return string[]
	 */
	private function unique_categories( $services ) {
		$cats = array();
		foreach ( $services as $row ) {
			$c = isset( $row['category'] ) ? (string) $row['category'] : '';
			if ( $c ) {
				$cats[ $c ] = true;
			}
		}
		$keys = array_keys( $cats );
		natcasesort( $keys );
		return array_values( $keys );
	}

	/**
	 * @param array $services Services.
	 * @return array<int,array{key:string,label:string}>
	 */
	private function platform_tabs( $services ) {
		$labels = array(
			'instagram' => 'Instagram',
			'facebook'  => 'Facebook',
			'youtube'   => 'Youtube',
			'twitter'   => 'Twitter',
			'spotify'   => 'Spotify',
			'tiktok'    => 'Tiktok',
			'telegram'  => 'Telegram',
			'linkedin'  => 'Linkedin',
			'discord'   => 'Discord',
			'traffic'   => 'Website Traffic',
			'others'    => 'Others',
		);
		$found = array();
		foreach ( $services as $row ) {
			$key           = self::platform_from_category( isset( $row['category'] ) ? $row['category'] : '' );
			$found[ $key ] = true;
		}
		$tabs = array(
			array(
				'key'   => 'all',
				'label' => __( 'Everything', 'woo-instagram-follower' ),
			),
		);
		foreach ( $labels as $key => $label ) {
			if ( empty( $found[ $key ] ) && 'others' !== $key ) {
				continue;
			}
			if ( 'others' === $key && empty( $found['others'] ) ) {
				continue;
			}
			$tabs[] = array(
				'key'   => $key,
				'label' => $label,
			);
		}
		return $tabs;
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$connected = $this->is_connected();
		$name      = Member\Settings::get()['membership_name'];
		?>
		<div class="wrap wifl-member-admin wifl-smm-order">
			<h1 class="screen-reader-text"><?php esc_html_e( 'SMM New Order', 'woo-instagram-follower' ); ?></h1>
			<div class="wifl-admin-hero">
				<div class="wifl-admin-hero__copy">
					<p class="wifl-admin-hero__kicker"><?php echo esc_html( $name ); ?></p>
					<p class="wifl-admin-hero__heading"><?php esc_html_e( 'SMM New Order', 'woo-instagram-follower' ); ?></p>
					<p class="wifl-admin-hero__intro"><?php esc_html_e( 'Place orders with your connected API key — no SMMGen website login needed.', 'woo-instagram-follower' ); ?></p>
				</div>
				<div class="wifl-admin-hero__action">
					<span class="wifl-smm-balance" data-balance>
						<?php if ( $connected ) : ?>
							<?php esc_html_e( 'Balance…', 'woo-instagram-follower' ); ?>
						<?php else : ?>
							<?php esc_html_e( 'Not connected', 'woo-instagram-follower' ); ?>
						<?php endif; ?>
					</span>
				</div>
			</div>

			<?php if ( ! $connected ) : ?>
				<div class="notice notice-warning wifl-smm-notice">
					<p>
						<?php esc_html_e( 'SMM API is not connected. Add your API URL and key first.', 'woo-instagram-follower' ); ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Smm_Api::PAGE ) ); ?>"><?php esc_html_e( 'Open API settings', 'woo-instagram-follower' ); ?></a>
					</p>
				</div>
			<?php else : ?>
				<div class="wifl-smm-toolbar">
					<nav class="wifl-smm-platforms" data-platforms aria-label="<?php esc_attr_e( 'Platform filter', 'woo-instagram-follower' ); ?>"></nav>
					<button type="button" class="button" data-refresh-services><?php esc_html_e( 'Refresh services', 'woo-instagram-follower' ); ?></button>
				</div>

				<div class="wifl-smm-layout">
					<section class="wifl-admin-panel wifl-smm-form-panel">
						<header class="wifl-admin-panel__head">
							<div>
								<h2><?php esc_html_e( 'New order', 'woo-instagram-follower' ); ?></h2>
								<p><?php esc_html_e( 'Services load from your API. Choose category, service, customer link, and quantity.', 'woo-instagram-follower' ); ?></p>
							</div>
						</header>

						<form class="wifl-smm-form" data-smm-form novalidate>
							<label class="wifl-smm-field">
								<span><?php esc_html_e( 'Category', 'woo-instagram-follower' ); ?></span>
								<select name="category" data-category required>
									<option value=""><?php esc_html_e( 'Select a category', 'woo-instagram-follower' ); ?></option>
								</select>
							</label>

							<label class="wifl-smm-field">
								<span><?php esc_html_e( 'Service', 'woo-instagram-follower' ); ?></span>
								<select name="service" data-service required disabled>
									<option value=""><?php esc_html_e( 'Select a service', 'woo-instagram-follower' ); ?></option>
								</select>
							</label>

							<label class="wifl-smm-field">
								<span><?php esc_html_e( 'Link', 'woo-instagram-follower' ); ?></span>
								<input type="url" name="link" data-link placeholder="https://" required autocomplete="off" />
							</label>

							<label class="wifl-smm-field">
								<span><?php esc_html_e( 'Quantity', 'woo-instagram-follower' ); ?></span>
								<input type="number" name="quantity" data-quantity min="1" step="1" required />
								<small class="wifl-smm-hint" data-minmax></small>
							</label>

							<label class="wifl-smm-field">
								<span><?php esc_html_e( 'Average time', 'woo-instagram-follower' ); ?></span>
								<input type="text" data-avg-time value="—" readonly />
							</label>

							<label class="wifl-smm-field">
								<span><?php esc_html_e( 'Charge', 'woo-instagram-follower' ); ?></span>
								<input type="text" data-charge value="—" readonly />
							</label>

							<label class="wifl-smm-field">
								<span><?php esc_html_e( 'Internal note (optional)', 'woo-instagram-follower' ); ?></span>
								<input type="text" name="note" data-note placeholder="<?php esc_attr_e( 'Customer name / Woo order #', 'woo-instagram-follower' ); ?>" maxlength="120" />
							</label>

							<p class="wifl-smm-msg" data-msg hidden></p>

							<div class="wifl-smm-actions">
								<button type="submit" class="button button-primary wifl-admin-btn" data-submit>
									<?php esc_html_e( 'New order', 'woo-instagram-follower' ); ?>
								</button>
							</div>
						</form>
					</section>

					<aside class="wifl-admin-panel wifl-smm-desc-panel" data-desc-panel>
						<header class="wifl-admin-panel__head">
							<div>
								<h2 data-desc-title><?php esc_html_e( 'Service details', 'woo-instagram-follower' ); ?></h2>
								<p data-desc-rate></p>
							</div>
						</header>
						<div class="wifl-smm-desc-body" data-desc-body>
							<p class="wifl-smm-desc-empty"><?php esc_html_e( 'Select a service to see details.', 'woo-instagram-follower' ); ?></p>
						</div>
					</aside>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
