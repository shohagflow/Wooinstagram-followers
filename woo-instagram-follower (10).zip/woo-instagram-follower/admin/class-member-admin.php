<?php
/**
 * Membership admin dashboard.
 *
 * @package WIFL
 */

namespace WIFL\Member;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {

	/**
	 * @var Admin|null
	 */
	private static $instance = null;

	const PAGE              = 'wifl-membership';
	const PAGE_USERS        = 'wifl-membership-users';
	const PAGE_SUBSCRIPTIONS = 'wifl-membership-subscriptions';
	const PAGE_SETTINGS     = 'wifl-membership-settings';

	/**
	 * @return Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'save_settings' ) );
		add_action( 'admin_init', array( $this, 'save_subscriptions' ) );
		add_action( 'admin_init', array( $this, 'maybe_delete_user' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	public function menu() {
		$name = Settings::get()['membership_name'];

		add_menu_page(
			$name,
			$name,
			'manage_options',
			self::PAGE,
			array( $this, 'render_dashboard_page' ),
			'dashicons-groups',
			58
		);

		add_submenu_page(
			self::PAGE,
			esc_html__( 'Dashboard', 'woo-instagram-follower' ),
			esc_html__( 'Dashboard', 'woo-instagram-follower' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_dashboard_page' )
		);

		add_submenu_page(
			self::PAGE,
			esc_html__( 'Users', 'woo-instagram-follower' ),
			esc_html__( 'Users', 'woo-instagram-follower' ),
			'manage_options',
			self::PAGE_USERS,
			array( $this, 'render_users_page' )
		);

		add_submenu_page(
			self::PAGE,
			esc_html__( 'Subscriptions', 'woo-instagram-follower' ),
			esc_html__( 'Subscriptions', 'woo-instagram-follower' ),
			'manage_options',
			self::PAGE_SUBSCRIPTIONS,
			array( $this, 'render_subscriptions_page' )
		);

		add_submenu_page(
			self::PAGE,
			esc_html__( 'Settings', 'woo-instagram-follower' ),
			esc_html__( 'Settings', 'woo-instagram-follower' ),
			'manage_options',
			self::PAGE_SETTINGS,
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * @param string $hook Hook.
	 */
	public function assets( $hook ) {
		if ( ! $this->is_member_page( $hook ) ) {
			return;
		}

		$page = $this->current_page();

		wp_enqueue_style(
			'wifl-member-admin',
			WIFL_URL . 'assets/css/member-admin.css',
			array(),
			WIFL_VERSION
		);

		if ( self::PAGE_SETTINGS === $page ) {
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'wp-color-picker' );
		}

		if ( self::PAGE_SUBSCRIPTIONS === $page ) {
			wp_enqueue_script(
				'wifl-member-admin',
				WIFL_URL . 'assets/js/member-admin.js',
				array( 'jquery' ),
				WIFL_VERSION,
				true
			);
		}
	}

	/**
	 * @return string
	 */
	private function current_page() {
		return isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * @param string $hook Admin hook suffix.
	 * @return bool
	 */
	private function is_member_page( $hook ) {
		$page = $this->current_page();
		if ( in_array( $page, array( self::PAGE, self::PAGE_USERS, self::PAGE_SUBSCRIPTIONS, self::PAGE_SETTINGS ), true ) ) {
			return true;
		}

		return in_array(
			$hook,
			array(
				'toplevel_page_' . self::PAGE,
				self::PAGE . '_page_' . self::PAGE_USERS,
				self::PAGE . '_page_' . self::PAGE_SUBSCRIPTIONS,
				self::PAGE . '_page_' . self::PAGE_SETTINGS,
			),
			true
		);
	}

	public function save_settings() {
		if ( ! isset( $_POST['wifl_member_save'] ) ) {
			return;
		}
		if ( ! isset( $_POST['wifl_member_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_member_nonce'] ) ), 'wifl_member_save' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$raw = isset( $_POST['wifl_member'] ) && is_array( $_POST['wifl_member'] ) ? wp_unslash( $_POST['wifl_member'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		update_option( Settings::OPTION, Settings::sanitize( $raw ), false );
		add_settings_error( 'wifl_member', 'saved', esc_html__( 'Membership settings saved.', 'woo-instagram-follower' ), 'updated' );
	}

	public function save_subscriptions() {
		if ( ! isset( $_POST['wifl_subs_save'] ) ) {
			return;
		}
		if ( ! isset( $_POST['wifl_subs_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_subs_nonce'] ) ), 'wifl_subs_save' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$raw   = isset( $_POST['wifl_subs'] ) && is_array( $_POST['wifl_subs'] ) ? wp_unslash( $_POST['wifl_subs'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$plans = Subscriptions::sanitize_plans( $raw );
		update_option( Subscriptions::OPTION, $plans, false );
		add_settings_error( 'wifl_subs', 'saved', esc_html__( 'Subscriptions saved.', 'woo-instagram-follower' ), 'updated' );
	}

	/**
	 * @param string $title  Title.
	 * @param string $intro  Intro.
	 * @param string $action Optional HTML action.
	 */
	private function render_hero( $title, $intro, $action = '' ) {
		$kicker = Settings::get()['membership_name'];
		?>
		<h1 class="screen-reader-text"><?php echo esc_html( $title ); ?></h1>
		<div class="wifl-admin-hero">
			<div class="wifl-admin-hero__copy">
				<p class="wifl-admin-hero__kicker"><?php echo esc_html( $kicker ); ?></p>
				<p class="wifl-admin-hero__heading"><?php echo esc_html( $title ); ?></p>
				<p class="wifl-admin-hero__intro"><?php echo esc_html( $intro ); ?></p>
			</div>
			<?php if ( $action ) : ?>
				<div class="wifl-admin-hero__action">
					<?php
					echo wp_kses(
						$action,
						array(
							'button' => array(
								'type'               => true,
								'class'              => true,
								'data-wifl-add-sub'  => true,
							),
							'a'      => array(
								'href'  => true,
								'class' => true,
							),
						)
					);
					?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function render_subscriptions_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$plans = Subscriptions::get_plans();
		$stats = Subscriptions::stats();
		settings_errors( 'wifl_subs' );
		?>
		<div class="wrap wifl-member-admin wifl-subs-admin">
			<?php
			$this->render_hero(
				__( 'Subscriptions', 'woo-instagram-follower' ),
				__( 'Create and manage plans shown on the CT subscription widget — title, price, features, and status.', 'woo-instagram-follower' ),
				'<button type="button" class="button button-primary wifl-admin-btn" data-wifl-add-sub>' . esc_html__( 'Add plan', 'woo-instagram-follower' ) . '</button>'
			);
			?>

			<div class="wifl-admin-stats">
				<div class="wifl-admin-stat">
					<strong><?php echo esc_html( (string) $stats['total'] ); ?></strong>
					<span><?php esc_html_e( 'Total plans', 'woo-instagram-follower' ); ?></span>
				</div>
				<div class="wifl-admin-stat">
					<strong><?php echo esc_html( (string) $stats['active'] ); ?></strong>
					<span><?php esc_html_e( 'Active', 'woo-instagram-follower' ); ?></span>
				</div>
				<div class="wifl-admin-stat">
					<strong><?php echo esc_html( (string) $stats['featured'] ); ?></strong>
					<span><?php esc_html_e( 'Featured', 'woo-instagram-follower' ); ?></span>
				</div>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SUBSCRIPTIONS ) ); ?>" class="wifl-subs-admin__form">
				<?php wp_nonce_field( 'wifl_subs_save', 'wifl_subs_nonce' ); ?>
				<div class="wifl-subs-admin__list" id="wifl-subs-list">
					<?php
					if ( empty( $plans ) ) {
						$this->render_subscription_card( 0, Subscriptions::blank_plan() );
					} else {
						foreach ( $plans as $index => $plan ) {
							$this->render_subscription_card( $index, $plan );
						}
					}
					?>
				</div>
				<div class="wifl-admin-actions">
					<?php submit_button( esc_html__( 'Save subscriptions', 'woo-instagram-follower' ), 'primary wifl-admin-btn', 'wifl_subs_save', false ); ?>
				</div>
			</form>
			<script type="text/html" id="tmpl-wifl-sub-card">
				<?php $this->render_subscription_card( '__I__', Subscriptions::blank_plan() ); ?>
			</script>
			<script type="text/html" id="tmpl-wifl-sub-feature">
				<?php $this->render_feature_row( '__PREFIX__', '__F__', '' ); ?>
			</script>
		</div>
		<?php
	}

	/**
	 * @param int|string $index Index.
	 * @param array      $plan  Plan.
	 */
	private function render_subscription_card( $index, $plan ) {
		$name     = 'wifl_subs[' . $index . ']';
		$featured = ! empty( $plan['featured'] ) && 'yes' === $plan['featured'];
		$status   = ! empty( $plan['status'] ) ? $plan['status'] : 'active';
		$features = $this->plan_feature_list( $plan );
		?>
		<article class="wifl-sub-editor<?php echo $featured ? ' is-featured' : ''; ?>">
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>[id]" value="<?php echo esc_attr( $plan['id'] ); ?>" />
			<header class="wifl-sub-editor__head">
				<div>
					<strong class="wifl-sub-editor__title"><?php echo esc_html( $plan['name'] ? $plan['name'] : __( 'New plan', 'woo-instagram-follower' ) ); ?></strong>
					<span class="wifl-sub-editor__meta"><?php echo esc_html( trim( $plan['qty'] . ' ' . $plan['qty_label'] ) ); ?></span>
				</div>
				<div class="wifl-sub-editor__head-actions">
					<span class="wifl-sub-editor__pill wifl-sub-editor__pill--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( 'active' === $status ? __( 'Active', 'woo-instagram-follower' ) : __( 'Draft', 'woo-instagram-follower' ) ); ?></span>
					<button type="button" class="button-link-delete wifl-sub-editor__remove" data-wifl-remove-sub><?php esc_html_e( 'Remove', 'woo-instagram-follower' ); ?></button>
				</div>
			</header>

			<div class="wifl-sub-editor__grid">
				<label>
					<span><?php esc_html_e( 'Plan name', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[name]" value="<?php echo esc_attr( $plan['name'] ); ?>" placeholder="<?php esc_attr_e( 'Instagram Growth Pro', 'woo-instagram-follower' ); ?>" />
				</label>
				<label>
					<span><?php esc_html_e( 'Label', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[kicker]" value="<?php echo esc_attr( $plan['kicker'] ); ?>" placeholder="INSTAGRAM • HIGH QUALITY" />
				</label>
				<label>
					<span><?php esc_html_e( 'Badge', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[badge]" value="<?php echo esc_attr( $plan['badge'] ); ?>" placeholder="<?php esc_attr_e( 'GREAT VALUE', 'woo-instagram-follower' ); ?>" />
				</label>
				<label>
					<span><?php esc_html_e( 'Status', 'woo-instagram-follower' ); ?></span>
					<select name="<?php echo esc_attr( $name ); ?>[status]">
						<option value="active" <?php selected( $status, 'active' ); ?>><?php esc_html_e( 'Active', 'woo-instagram-follower' ); ?></option>
						<option value="draft" <?php selected( $status, 'draft' ); ?>><?php esc_html_e( 'Draft', 'woo-instagram-follower' ); ?></option>
					</select>
				</label>
				<label>
					<span><?php esc_html_e( 'Quantity', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[qty]" value="<?php echo esc_attr( $plan['qty'] ); ?>" placeholder="1,000" />
				</label>
				<label>
					<span><?php esc_html_e( 'Quantity label', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[qty_label]" value="<?php echo esc_attr( $plan['qty_label'] ); ?>" placeholder="<?php esc_attr_e( 'likes per post', 'woo-instagram-follower' ); ?>" />
				</label>
				<label>
					<span><?php esc_html_e( 'Price', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[price]" value="<?php echo esc_attr( $plan['price'] ); ?>" placeholder="99.99" />
				</label>
				<label>
					<span><?php esc_html_e( 'Period', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[period]" value="<?php echo esc_attr( $plan['period'] ); ?>" placeholder="/mo" />
				</label>
				<label>
					<span><?php esc_html_e( 'Unit price', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[unit_price]" value="<?php echo esc_attr( $plan['unit_price'] ); ?>" placeholder="$0.0008 per like*" />
				</label>
				<label>
					<span><?php esc_html_e( 'Button text', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[button_text]" value="<?php echo esc_attr( $plan['button_text'] ); ?>" />
				</label>
				<label class="wifl-sub-editor__wide">
					<span><?php esc_html_e( 'Button link', 'woo-instagram-follower' ); ?></span>
					<input type="url" name="<?php echo esc_attr( $name ); ?>[button_url]" value="<?php echo esc_attr( $plan['button_url'] ); ?>" placeholder="https://" />
				</label>
				<label class="wifl-sub-editor__wide">
					<span><?php esc_html_e( 'Footer', 'woo-instagram-follower' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[footer]" value="<?php echo esc_attr( $plan['footer'] ); ?>" />
				</label>
				<div class="wifl-sub-editor__wide wifl-sub-features">
					<span><?php esc_html_e( 'Features', 'woo-instagram-follower' ); ?></span>
					<div class="wifl-sub-features__list">
						<?php foreach ( $features as $f_index => $feature ) : ?>
							<?php $this->render_feature_row( $name, $f_index, $feature ); ?>
						<?php endforeach; ?>
					</div>
					<button type="button" class="button wifl-sub-features__add" data-wifl-add-feature><?php esc_html_e( 'Add feature', 'woo-instagram-follower' ); ?></button>
				</div>
				<label class="wifl-sub-editor__check">
					<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[featured]" value="yes" <?php checked( $featured ); ?> />
					<span><?php esc_html_e( 'Featured plan (highlighted card)', 'woo-instagram-follower' ); ?></span>
				</label>
			</div>
		</article>
		<?php
	}

	/**
	 * @param array $plan Plan.
	 * @return string[]
	 */
	private function plan_feature_list( $plan ) {
		$raw = isset( $plan['features'] ) ? $plan['features'] : '';
		if ( is_array( $raw ) ) {
			$items = array_map( 'strval', $raw );
		} else {
			$items = preg_split( '/\r\n|\r|\n/', (string) $raw );
		}

		$items = array_values( array_filter( array_map( 'trim', $items ) ) );
		return $items ? $items : array( '' );
	}

	/**
	 * @param string     $prefix  Field name prefix, e.g. wifl_subs[0].
	 * @param int|string $f_index Feature index.
	 * @param string     $feature Feature text.
	 */
	private function render_feature_row( $prefix, $f_index, $feature ) {
		?>
		<div class="wifl-sub-feature">
			<input type="text" name="<?php echo esc_attr( $prefix ); ?>[features][<?php echo esc_attr( (string) $f_index ); ?>]" value="<?php echo esc_attr( $feature ); ?>" placeholder="<?php esc_attr_e( 'Real likes from real users', 'woo-instagram-follower' ); ?>" />
			<button type="button" class="button-link-delete wifl-sub-feature__remove" data-wifl-remove-feature aria-label="<?php esc_attr_e( 'Remove feature', 'woo-instagram-follower' ); ?>">&times;</button>
		</div>
		<?php
	}

	public function render_dashboard_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = Settings::get();
		settings_errors( 'wifl_member' );
		?>
		<div class="wrap wifl-member-admin">
			<?php
			$this->render_hero(
				$settings['membership_name'],
				__( 'Overview of members, registration, and subscription plans.', 'woo-instagram-follower' )
			);
			$this->render_dashboard_content( $settings );
			?>
		</div>
		<?php
	}

	public function render_users_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap wifl-member-admin">
			<?php
			$this->render_hero(
				__( 'Users', 'woo-instagram-follower' ),
				__( 'Search members, review roles, and delete accounts when needed.', 'woo-instagram-follower' )
			);
			$this->render_users_content();
			?>
		</div>
		<?php
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = Settings::get();
		settings_errors( 'wifl_member' );
		?>
		<div class="wrap wifl-member-admin">
			<?php
			$this->render_hero(
				__( 'Settings', 'woo-instagram-follower' ),
				__( 'Brand, pages, redirects, and the labels used on login and registration.', 'woo-instagram-follower' )
			);
			$this->render_settings_content( $settings );
			?>
		</div>
		<?php
	}

	/**
	 * @param array $settings Settings.
	 */
	private function render_dashboard_content( $settings ) {
		$user_count = count_users();
		$total      = isset( $user_count['total_users'] ) ? (int) $user_count['total_users'] : 0;
		$roles      = isset( $user_count['avail_roles'] ) && is_array( $user_count['avail_roles'] ) ? $user_count['avail_roles'] : array();
		$customers  = isset( $roles['customer'] ) ? (int) $roles['customer'] : 0;
		$subs       = Subscriptions::stats();
		$open       = 'yes' === $settings['enable_registration'];
		?>
		<div class="wifl-admin-stats wifl-admin-stats--4">
			<div class="wifl-admin-stat">
				<strong><?php echo esc_html( number_format_i18n( $total ) ); ?></strong>
				<span><?php esc_html_e( 'Total users', 'woo-instagram-follower' ); ?></span>
			</div>
			<div class="wifl-admin-stat">
				<strong><?php echo esc_html( number_format_i18n( $customers ) ); ?></strong>
				<span><?php esc_html_e( 'Customers', 'woo-instagram-follower' ); ?></span>
			</div>
			<div class="wifl-admin-stat">
				<strong><?php echo $open ? esc_html__( 'Open', 'woo-instagram-follower' ) : esc_html__( 'Closed', 'woo-instagram-follower' ); ?></strong>
				<span><?php esc_html_e( 'Registration', 'woo-instagram-follower' ); ?></span>
			</div>
			<div class="wifl-admin-stat">
				<strong><?php echo esc_html( number_format_i18n( $subs['active'] ) ); ?></strong>
				<span><?php esc_html_e( 'Active plans', 'woo-instagram-follower' ); ?></span>
			</div>
		</div>

		<div class="wifl-admin-links">
			<a class="wifl-admin-link" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_USERS ) ); ?>">
				<strong><?php esc_html_e( 'Users', 'woo-instagram-follower' ); ?></strong>
				<span><?php esc_html_e( 'Search and manage member accounts.', 'woo-instagram-follower' ); ?></span>
			</a>
			<a class="wifl-admin-link" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SUBSCRIPTIONS ) ); ?>">
				<strong><?php esc_html_e( 'Subscriptions', 'woo-instagram-follower' ); ?></strong>
				<span><?php esc_html_e( 'Create pricing plans for the widget.', 'woo-instagram-follower' ); ?></span>
			</a>
			<a class="wifl-admin-link" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SETTINGS ) ); ?>">
				<strong><?php esc_html_e( 'Settings', 'woo-instagram-follower' ); ?></strong>
				<span><?php esc_html_e( 'Brand, pages, and form labels.', 'woo-instagram-follower' ); ?></span>
			</a>
			<a class="wifl-admin-link" href="<?php echo esc_url( admin_url( 'admin.php?page=wifl-smm-api' ) ); ?>">
				<strong><?php esc_html_e( 'API', 'woo-instagram-follower' ); ?></strong>
				<span><?php esc_html_e( 'Connect SMMGen and test the panel key.', 'woo-instagram-follower' ); ?></span>
			</a>
			<a class="wifl-admin-link" href="<?php echo esc_url( admin_url( 'admin.php?page=wifl-smm-order' ) ); ?>">
				<strong><?php esc_html_e( 'SMM New Order', 'woo-instagram-follower' ); ?></strong>
				<span><?php esc_html_e( 'Place SMM orders from admin using your API key (no panel login).', 'woo-instagram-follower' ); ?></span>
			</a>
		</div>

		<?php $this->render_shortcodes_section(); ?>
		<?php
	}

	/**
	 * Form shortcodes reference table.
	 */
	private function render_shortcodes_section() {
		?>
		<section class="wifl-admin-panel">
			<header class="wifl-admin-panel__head">
				<div>
					<h2><?php esc_html_e( 'Frontend widgets', 'woo-instagram-follower' ); ?></h2>
					<p><?php esc_html_e( 'Add these from the CT Member category in Elementor, or use the dashboard shortcode.', 'woo-instagram-follower' ); ?></p>
				</div>
			</header>
			<div class="wifl-admin-widgets">
				<article class="wifl-admin-widget">
					<span><?php esc_html_e( 'Login & registration', 'woo-instagram-follower' ); ?></span>
					<strong>CT member login</strong>
				</article>
				<article class="wifl-admin-widget">
					<span><?php esc_html_e( 'Member dashboard', 'woo-instagram-follower' ); ?></span>
					<code>[wifl_dashboard]</code>
				</article>
				<article class="wifl-admin-widget">
					<span><?php esc_html_e( 'Subscription plans', 'woo-instagram-follower' ); ?></span>
					<strong>CT subscription</strong>
				</article>
			</div>
		</section>
		<?php
	}

	private function render_users_content() {
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$notice = isset( $_GET['wifl_user_notice'] ) ? sanitize_key( wp_unslash( $_GET['wifl_user_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$args = array(
			'number'  => 20,
			'offset'  => ( $paged - 1 ) * 20,
			'orderby' => 'registered',
			'order'   => 'DESC',
			'fields'  => array( 'ID', 'user_login', 'user_email', 'display_name', 'user_registered' ),
		);

		if ( $search ) {
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
		}

		$query = new \WP_User_Query( $args );
		$users = $query->get_results();
		$total = (int) $query->get_total();
		$pages = max( 1, (int) ceil( $total / 20 ) );
		?>
		<?php if ( 'deleted' === $notice ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'User deleted.', 'woo-instagram-follower' ); ?></p></div>
		<?php elseif ( 'denied' === $notice ) : ?>
			<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'You cannot delete that user.', 'woo-instagram-follower' ); ?></p></div>
		<?php elseif ( 'failed' === $notice ) : ?>
			<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'Could not delete the user.', 'woo-instagram-follower' ); ?></p></div>
		<?php endif; ?>
		<section class="wifl-admin-panel">
			<header class="wifl-admin-panel__head">
				<div>
					<h2><?php esc_html_e( 'Members', 'woo-instagram-follower' ); ?></h2>
					<p><?php echo esc_html( sprintf( /* translators: %s: user count */ _n( '%s user', '%s users', $total, 'woo-instagram-follower' ), number_format_i18n( $total ) ) ); ?></p>
				</div>
				<form method="get" class="wifl-admin-search">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_USERS ); ?>" />
					<label class="screen-reader-text" for="wifl-user-search"><?php esc_html_e( 'Search users', 'woo-instagram-follower' ); ?></label>
					<input type="search" id="wifl-user-search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search name or email', 'woo-instagram-follower' ); ?>" />
					<button type="submit" class="button button-primary wifl-admin-btn"><?php esc_html_e( 'Search', 'woo-instagram-follower' ); ?></button>
				</form>
			</header>

			<div class="wifl-admin-table-wrap">
				<table class="wifl-admin-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Name', 'woo-instagram-follower' ); ?></th>
							<th><?php esc_html_e( 'Email', 'woo-instagram-follower' ); ?></th>
							<th><?php esc_html_e( 'Role', 'woo-instagram-follower' ); ?></th>
							<th><?php esc_html_e( 'Registered', 'woo-instagram-follower' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'woo-instagram-follower' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $users ) ) : ?>
							<tr><td colspan="5" class="wifl-admin-empty"><?php esc_html_e( 'No users found.', 'woo-instagram-follower' ); ?></td></tr>
						<?php else : ?>
							<?php foreach ( $users as $user ) : ?>
								<?php
								$wp_user = get_userdata( $user->ID );
								$roles   = $wp_user ? $wp_user->roles : array();
								$name    = $user->display_name ? $user->display_name : $user->user_login;
								$can_del = $this->can_delete_user( (int) $user->ID );
								$del_url = wp_nonce_url(
									add_query_arg(
										array(
											'page'         => self::PAGE_USERS,
											'wifl_delete_user' => (int) $user->ID,
											's'            => $search,
											'paged'        => $paged,
										),
										admin_url( 'admin.php' )
									),
									'wifl_delete_user_' . (int) $user->ID
								);
								?>
								<tr>
									<td>
										<div class="wifl-admin-user">
											<?php echo get_avatar( $user->ID, 36 ); ?>
											<div>
												<strong><?php echo esc_html( $name ); ?></strong>
												<span><?php echo esc_html( $user->user_login ); ?></span>
											</div>
										</div>
									</td>
									<td><?php echo esc_html( $user->user_email ); ?></td>
									<td>
										<?php foreach ( $roles as $role ) : ?>
											<span class="wifl-admin-pill"><?php echo esc_html( $role ); ?></span>
										<?php endforeach; ?>
									</td>
									<td><?php echo esc_html( mysql2date( get_option( 'date_format' ), $user->user_registered ) ); ?></td>
									<td>
										<?php if ( $can_del ) : ?>
											<a class="wifl-admin-link-btn wifl-admin-link-btn--danger" href="<?php echo esc_url( $del_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this user permanently?', 'woo-instagram-follower' ) ); ?>');"><?php esc_html_e( 'Delete', 'woo-instagram-follower' ); ?></a>
										<?php else : ?>
											<span class="wifl-admin-muted">—</span>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>

			<?php if ( $pages > 1 ) : ?>
				<div class="wifl-admin-pager">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( array( 'paged' => '%#%', 'page' => self::PAGE_USERS ), admin_url( 'admin.php' ) ),
								'format'    => '',
								'current'   => $paged,
								'total'     => $pages,
								'prev_text' => '&laquo;',
								'next_text' => '&raquo;',
							)
						)
					);
					?>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private function can_delete_user( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id < 1 || ! current_user_can( 'delete_users' ) ) {
			return false;
		}
		if ( (int) get_current_user_id() === $user_id ) {
			return false;
		}
		if ( ! current_user_can( 'delete_user', $user_id ) ) {
			return false;
		}
		$target = get_userdata( $user_id );
		if ( ! $target ) {
			return false;
		}
		// Do not allow deleting super admins / admins unless current user is also an admin with capability.
		if ( in_array( 'administrator', (array) $target->roles, true ) && ! current_user_can( 'manage_options' ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Handle delete action from the membership Users table.
	 */
	public function maybe_delete_user() {
		if ( ! isset( $_GET['wifl_delete_user'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		if ( ! isset( $_GET['page'] ) || self::PAGE_USERS !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$user_id = absint( $_GET['wifl_delete_user'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		check_admin_referer( 'wifl_delete_user_' . $user_id );

		$redirect = array(
			'page' => self::PAGE_USERS,
		);
		if ( ! empty( $_GET['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$redirect['s'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		if ( ! empty( $_GET['paged'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$redirect['paged'] = max( 1, absint( $_GET['paged'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! $this->can_delete_user( $user_id ) ) {
			$redirect['wifl_user_notice'] = 'denied';
			wp_safe_redirect( add_query_arg( $redirect, admin_url( 'admin.php' ) ) );
			exit;
		}

		require_once ABSPATH . 'wp-admin/includes/user.php';
		$deleted = wp_delete_user( $user_id );
		$redirect['wifl_user_notice'] = $deleted ? 'deleted' : 'failed';
		wp_safe_redirect( add_query_arg( $redirect, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * @param array $s Settings.
	 */
	private function render_settings_content( $s ) {
		$this->render_shortcodes_section();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SETTINGS ) ); ?>" class="wifl-admin-form">
			<?php wp_nonce_field( 'wifl_member_save', 'wifl_member_nonce' ); ?>

			<section class="wifl-admin-panel">
				<header class="wifl-admin-panel__head">
					<div>
						<h2><?php esc_html_e( 'General', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'Brand name, logo, color, and whether new people can register.', 'woo-instagram-follower' ); ?></p>
					</div>
				</header>
				<div class="wifl-admin-grid">
					<label>
						<span><?php esc_html_e( 'Membership name', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-member-name" name="wifl_member[membership_name]" value="<?php echo esc_attr( $s['membership_name'] ); ?>" />
					</label>
					<label>
						<span><?php esc_html_e( 'Brand color', 'woo-instagram-follower' ); ?></span>
						<input type="text" class="wifl-member-color" id="wifl-member-brand" name="wifl_member[brand_color]" value="<?php echo esc_attr( $s['brand_color'] ); ?>" />
					</label>
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Logo URL', 'woo-instagram-follower' ); ?></span>
						<input type="url" id="wifl-member-logo" name="wifl_member[logo_url]" value="<?php echo esc_attr( $s['logo_url'] ); ?>" placeholder="https://" />
					</label>
					<label class="wifl-admin-check">
						<input type="checkbox" name="wifl_member[enable_registration]" value="yes" <?php checked( $s['enable_registration'], 'yes' ); ?> />
						<span><?php esc_html_e( 'Allow new user registration', 'woo-instagram-follower' ); ?></span>
					</label>
				</div>
			</section>

			<section class="wifl-admin-panel">
				<header class="wifl-admin-panel__head">
					<div>
						<h2><?php esc_html_e( 'Pages & redirects', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'Where login, register, and the member dashboard live.', 'woo-instagram-follower' ); ?></p>
					</div>
				</header>
				<div class="wifl-admin-grid">
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Login page URL', 'woo-instagram-follower' ); ?></span>
						<input type="url" id="wifl-login-page" name="wifl_member[login_page_url]" value="<?php echo esc_attr( $s['login_page_url'] ); ?>" />
						<em><?php esc_html_e( 'Page with the login form or CT member login widget (default panel: Login).', 'woo-instagram-follower' ); ?></em>
					</label>
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Register page URL', 'woo-instagram-follower' ); ?></span>
						<input type="url" id="wifl-register-page" name="wifl_member[register_page_url]" value="<?php echo esc_attr( $s['register_page_url'] ?? '' ); ?>" />
						<em><?php esc_html_e( 'Page with the registration form or CT member login widget (default panel: Registration).', 'woo-instagram-follower' ); ?></em>
					</label>
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Member dashboard URL', 'woo-instagram-follower' ); ?></span>
						<input type="url" id="wifl-dashboard-page" name="wifl_member[dashboard_page_url]" value="<?php echo esc_attr( $s['dashboard_page_url'] ?? '' ); ?>" />
						<em><?php esc_html_e( 'Page with [wifl_dashboard] or CT member dashboard widget only — not the login/register page.', 'woo-instagram-follower' ); ?></em>
					</label>
					<label>
						<span><?php esc_html_e( 'After login redirect', 'woo-instagram-follower' ); ?></span>
						<input type="url" id="wifl-login-redirect" name="wifl_member[login_redirect]" value="<?php echo esc_attr( $s['login_redirect'] ); ?>" />
						<em><?php esc_html_e( 'Optional. Leave empty to use the member dashboard URL.', 'woo-instagram-follower' ); ?></em>
					</label>
					<label>
						<span><?php esc_html_e( 'After register redirect', 'woo-instagram-follower' ); ?></span>
						<input type="url" id="wifl-register-redirect" name="wifl_member[register_redirect]" value="<?php echo esc_attr( $s['register_redirect'] ); ?>" />
						<em><?php esc_html_e( 'Optional. Leave empty to use the member dashboard URL.', 'woo-instagram-follower' ); ?></em>
					</label>
				</div>
			</section>

			<section class="wifl-admin-panel">
				<header class="wifl-admin-panel__head">
					<div>
						<h2><?php esc_html_e( 'Login form labels', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'Copy shown on the login panel.', 'woo-instagram-follower' ); ?></p>
					</div>
				</header>
				<div class="wifl-admin-grid">
					<label>
						<span><?php esc_html_e( 'Title', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-login-title" name="wifl_member[login_title]" value="<?php echo esc_attr( $s['login_title'] ); ?>" />
					</label>
					<label>
						<span><?php esc_html_e( 'Button text', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-login-button" name="wifl_member[login_button]" value="<?php echo esc_attr( $s['login_button'] ); ?>" />
					</label>
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Subtitle', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-login-subtitle" name="wifl_member[login_subtitle]" value="<?php echo esc_attr( $s['login_subtitle'] ); ?>" />
					</label>
				</div>
			</section>

			<section class="wifl-admin-panel">
				<header class="wifl-admin-panel__head">
					<div>
						<h2><?php esc_html_e( 'Registration form labels', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'Copy shown on the registration panel.', 'woo-instagram-follower' ); ?></p>
					</div>
				</header>
				<div class="wifl-admin-grid">
					<label>
						<span><?php esc_html_e( 'Title', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-register-title" name="wifl_member[register_title]" value="<?php echo esc_attr( $s['register_title'] ); ?>" />
					</label>
					<label>
						<span><?php esc_html_e( 'Button text', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-register-button" name="wifl_member[register_button]" value="<?php echo esc_attr( $s['register_button'] ); ?>" />
					</label>
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Subtitle', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-register-subtitle" name="wifl_member[register_subtitle]" value="<?php echo esc_attr( $s['register_subtitle'] ); ?>" />
					</label>
				</div>
			</section>

			<section class="wifl-admin-panel">
				<header class="wifl-admin-panel__head">
					<div>
						<h2><?php esc_html_e( 'Promo panel', 'woo-instagram-follower' ); ?></h2>
						<p><?php esc_html_e( 'Quote and social proof on the split login layout.', 'woo-instagram-follower' ); ?></p>
					</div>
				</header>
				<div class="wifl-admin-grid">
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Quote', 'woo-instagram-follower' ); ?></span>
						<textarea rows="3" id="wifl-promo-quote" name="wifl_member[promo_quote]"><?php echo esc_textarea( $s['promo_quote'] ); ?></textarea>
					</label>
					<label>
						<span><?php esc_html_e( 'Author', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-promo-author" name="wifl_member[promo_author]" value="<?php echo esc_attr( $s['promo_author'] ); ?>" />
					</label>
					<label>
						<span><?php esc_html_e( 'Status line', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-promo-status" name="wifl_member[promo_status]" value="<?php echo esc_attr( $s['promo_status'] ); ?>" />
					</label>
					<label class="wifl-admin-wide">
						<span><?php esc_html_e( 'Social proof', 'woo-instagram-follower' ); ?></span>
						<input type="text" id="wifl-promo-social" name="wifl_member[promo_social_proof]" value="<?php echo esc_attr( $s['promo_social_proof'] ); ?>" />
					</label>
				</div>
			</section>

			<div class="wifl-admin-actions">
				<?php submit_button( esc_html__( 'Save settings', 'woo-instagram-follower' ), 'primary wifl-admin-btn', 'wifl_member_save', false ); ?>
			</div>
		</form>
		<script>
		jQuery(function($){ $('.wifl-member-color').wpColorPicker(); });
		</script>
		<?php
	}
}
