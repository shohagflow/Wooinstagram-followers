<?php
/**
 * Products submenu: customize the floating View cart button.
 *
 * @package WIFL
 */

namespace WIFL;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Float_Settings {

	const OPTION = 'wifl_float_settings';

	/**
	 * @var Float_Settings|null
	 */
	private static $instance = null;

	/**
	 * @return Float_Settings
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'     => 'yes',
			'button_text' => 'View cart',
			'dock_bg'     => '#111111',
			'text_color'  => '#ffffff',
			'badge_bg'    => '#e11d48',
			'view_bg'     => '#2a2a2a',
			'accent'      => '#ff5c3a',
			'radius'      => '999',
			'font_size'   => '15',
			'offset_right'=> '22',
			'offset_bottom'=> '22',
			'show_hover'  => 'yes',
		);
	}

	/**
	 * @return array
	 */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	public function menu() {
		add_submenu_page(
			'edit.php?post_type=product',
			esc_html__( 'Floating cart button', 'woo-instagram-follower' ),
			esc_html__( 'Floating cart button', 'woo-instagram-follower' ),
			'manage_woocommerce',
			'wifl-floating-cart',
			array( $this, 'render_page' )
		);
	}

	public function assets( $hook ) {
		if ( 'product_page_wifl-floating-cart' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_style(
			'wifl-member-admin',
			WIFL_URL . 'assets/css/member-admin.css',
			array(),
			WIFL_VERSION
		);
		wp_enqueue_style(
			'wifl-admin',
			WIFL_URL . 'assets/css/admin.css',
			array( 'wifl-member-admin' ),
			WIFL_VERSION
		);
		wp_enqueue_script(
			'wifl-float-admin',
			WIFL_URL . 'assets/js/float-admin.js',
			array( 'jquery', 'wp-color-picker' ),
			WIFL_VERSION,
			true
		);
	}

	public function save() {
		if ( ! isset( $_POST['wifl_float_save'] ) ) {
			return;
		}
		if ( ! isset( $_POST['wifl_float_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wifl_float_nonce'] ) ), 'wifl_float_save' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$raw = isset( $_POST['wifl_float'] ) && is_array( $_POST['wifl_float'] ) ? wp_unslash( $_POST['wifl_float'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		$settings = array(
			'enabled'       => ! empty( $raw['enabled'] ) ? 'yes' : 'no',
			'button_text'   => isset( $raw['button_text'] ) ? sanitize_text_field( $raw['button_text'] ) : 'View cart',
			'dock_bg'       => $this->hex( isset( $raw['dock_bg'] ) ? $raw['dock_bg'] : '#111111' ),
			'text_color'    => $this->hex( isset( $raw['text_color'] ) ? $raw['text_color'] : '#ffffff' ),
			'badge_bg'      => $this->hex( isset( $raw['badge_bg'] ) ? $raw['badge_bg'] : '#e11d48' ),
			'view_bg'       => $this->hex( isset( $raw['view_bg'] ) ? $raw['view_bg'] : '#2a2a2a' ),
			'accent'        => $this->hex( isset( $raw['accent'] ) ? $raw['accent'] : '#ff5c3a' ),
			'radius'        => $this->num( isset( $raw['radius'] ) ? $raw['radius'] : 999, 0, 999 ),
			'font_size'     => $this->num( isset( $raw['font_size'] ) ? $raw['font_size'] : 15, 10, 24 ),
			'offset_right'  => $this->num( isset( $raw['offset_right'] ) ? $raw['offset_right'] : 22, 0, 120 ),
			'offset_bottom' => $this->num( isset( $raw['offset_bottom'] ) ? $raw['offset_bottom'] : 22, 0, 120 ),
			'show_hover'    => ! empty( $raw['show_hover'] ) ? 'yes' : 'no',
		);

		if ( '' === $settings['button_text'] ) {
			$settings['button_text'] = 'View cart';
		}

		update_option( self::OPTION, $settings, false );
		add_settings_error( 'wifl_float', 'saved', esc_html__( 'Floating cart settings saved.', 'woo-instagram-follower' ), 'updated' );
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$s = self::get();
		settings_errors( 'wifl_float' );
		?>
		<div class="wrap wifl-member-admin wifl-float-admin">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Floating cart button', 'woo-instagram-follower' ); ?></h1>
			<div class="wifl-admin-hero">
				<div class="wifl-admin-hero__copy">
					<p class="wifl-admin-hero__kicker"><?php esc_html_e( 'WooCommerce', 'woo-instagram-follower' ); ?></p>
					<p class="wifl-admin-hero__heading"><?php esc_html_e( 'Floating cart button', 'woo-instagram-follower' ); ?></p>
					<p class="wifl-admin-hero__intro"><?php esc_html_e( 'Customize the bottom-right View cart button that appears after a product is added to the cart.', 'woo-instagram-follower' ); ?></p>
				</div>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'edit.php?post_type=product&page=wifl-floating-cart' ) ); ?>" class="wifl-admin-form">
				<?php wp_nonce_field( 'wifl_float_save', 'wifl_float_nonce' ); ?>
				<div class="wifl-float-admin__layout">
					<section class="wifl-admin-panel">
						<header class="wifl-admin-panel__head">
							<div>
								<h2><?php esc_html_e( 'Appearance', 'woo-instagram-follower' ); ?></h2>
								<p><?php esc_html_e( 'Colors, size, and position of the docked cart button.', 'woo-instagram-follower' ); ?></p>
							</div>
						</header>
						<div class="wifl-admin-grid">
							<label class="wifl-admin-check">
								<input type="checkbox" name="wifl_float[enabled]" value="yes" <?php checked( $s['enabled'], 'yes' ); ?> />
								<span><?php esc_html_e( 'Show the floating View cart button on the site', 'woo-instagram-follower' ); ?></span>
							</label>
							<label>
								<span><?php esc_html_e( 'Button text', 'woo-instagram-follower' ); ?></span>
								<input type="text" id="wifl-float-text" name="wifl_float[button_text]" value="<?php echo esc_attr( $s['button_text'] ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Font size (px)', 'woo-instagram-follower' ); ?></span>
								<input type="number" min="10" max="24" id="wifl-float-size" name="wifl_float[font_size]" value="<?php echo esc_attr( $s['font_size'] ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Button background', 'woo-instagram-follower' ); ?></span>
								<input type="text" class="wifl-color" id="wifl-float-dock-bg" name="wifl_float[dock_bg]" value="<?php echo esc_attr( $s['dock_bg'] ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Text color', 'woo-instagram-follower' ); ?></span>
								<input type="text" class="wifl-color" id="wifl-float-text-color" name="wifl_float[text_color]" value="<?php echo esc_attr( $s['text_color'] ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Count badge color', 'woo-instagram-follower' ); ?></span>
								<input type="text" class="wifl-color" id="wifl-float-badge" name="wifl_float[badge_bg]" value="<?php echo esc_attr( $s['badge_bg'] ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Hover “View cart” background', 'woo-instagram-follower' ); ?></span>
								<input type="text" class="wifl-color" id="wifl-float-view-bg" name="wifl_float[view_bg]" value="<?php echo esc_attr( $s['view_bg'] ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Checkout button color', 'woo-instagram-follower' ); ?></span>
								<input type="text" class="wifl-color" id="wifl-float-accent" name="wifl_float[accent]" value="<?php echo esc_attr( $s['accent'] ); ?>" />
							</label>
							<label>
								<span><?php esc_html_e( 'Border radius (px)', 'woo-instagram-follower' ); ?></span>
								<input type="number" min="0" max="999" id="wifl-float-radius" name="wifl_float[radius]" value="<?php echo esc_attr( $s['radius'] ); ?>" />
							</label>
							<label class="wifl-admin-wide">
								<span><?php esc_html_e( 'Position', 'woo-instagram-follower' ); ?></span>
								<div class="wifl-float-pos">
									<label>
										<span><?php esc_html_e( 'Right (px)', 'woo-instagram-follower' ); ?></span>
										<input type="number" min="0" max="120" name="wifl_float[offset_right]" value="<?php echo esc_attr( $s['offset_right'] ); ?>" />
									</label>
									<label>
										<span><?php esc_html_e( 'Bottom (px)', 'woo-instagram-follower' ); ?></span>
										<input type="number" min="0" max="120" name="wifl_float[offset_bottom]" value="<?php echo esc_attr( $s['offset_bottom'] ); ?>" />
									</label>
								</div>
							</label>
							<label class="wifl-admin-check">
								<input type="checkbox" name="wifl_float[show_hover]" value="yes" <?php checked( $s['show_hover'], 'yes' ); ?> />
								<span><?php esc_html_e( 'Expand with Instagram icon on hover', 'woo-instagram-follower' ); ?></span>
							</label>
						</div>
					</section>

					<section class="wifl-admin-panel wifl-float-preview">
						<header class="wifl-admin-panel__head">
							<div>
								<h2><?php esc_html_e( 'Preview', 'woo-instagram-follower' ); ?></h2>
								<p><?php esc_html_e( 'Live look of the docked button.', 'woo-instagram-follower' ); ?></p>
							</div>
						</header>
						<div class="wifl-float-preview__stage">
							<button type="button" class="wifl-float-preview__btn" id="wifl-float-preview-btn">
								<span class="wifl-float-preview__badge" id="wifl-float-preview-badge">1</span>
								<span id="wifl-float-preview-label"><?php echo esc_html( $s['button_text'] ); ?></span>
							</button>
						</div>
					</section>
				</div>
				<div class="wifl-admin-actions">
					<?php submit_button( esc_html__( 'Save changes', 'woo-instagram-follower' ), 'primary wifl-admin-btn', 'wifl_float_save', false ); ?>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * @param string $value Color.
	 * @return string
	 */
	private function hex( $value ) {
		$color = sanitize_hex_color( $value );
		return $color ? $color : '#111111';
	}

	/**
	 * @param mixed $value Value.
	 * @param int   $min   Min.
	 * @param int   $max   Max.
	 * @return string
	 */
	private function num( $value, $min, $max ) {
		$n = absint( $value );
		if ( $n < $min ) {
			$n = $min;
		}
		if ( $n > $max ) {
			$n = $max;
		}
		return (string) $n;
	}
}
