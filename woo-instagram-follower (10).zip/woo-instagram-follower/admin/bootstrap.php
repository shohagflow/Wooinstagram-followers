<?php
/**
 * Admin pages loader.
 *
 * @package WIFL
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WIFL_PATH . 'admin/class-member-admin.php';
require_once WIFL_PATH . 'admin/class-float-settings.php';
require_once WIFL_PATH . 'admin/class-smm-api.php';
require_once WIFL_PATH . 'admin/class-smm-order.php';
