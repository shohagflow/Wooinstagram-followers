<?php
/**
 * Plugin Name: Woo Instagram Follower
 * Description: Sell social services (followers, likes, and similar) as WooCommerce quantity packages. On each product you can enable service types with features, then set package quantity, price, and optional original price. The Elementor CT- follower widget (or [ct_follower] shortcode) lets customers pick a package and add it to cart at that price, with savings shown when original price is higher. Also includes a custom cart page for Instagram, TikTok, and YouTube packages, a floating cart, CT cart menu, member login/register, member dashboard, and CT icon-text widgets. Checkout uses the default WooCommerce checkout page.
 * Version: 1.25.3
 * Author: CT
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Text Domain: woo-instagram-follower
 *
 * @package WIFL
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WIFL_VERSION', '1.25.3' );
define( 'WIFL_FILE', __FILE__ );
define( 'WIFL_PATH', plugin_dir_path( __FILE__ ) );
define( 'WIFL_URL', plugin_dir_url( __FILE__ ) );

require_once WIFL_PATH . 'includes/class-helpers.php';
require_once WIFL_PATH . 'includes/class-product-meta.php';
require_once WIFL_PATH . 'includes/class-product-subscription-meta.php';
require_once WIFL_PATH . 'includes/class-cart.php';
require_once WIFL_PATH . 'includes/class-ajax.php';
require_once WIFL_PATH . 'includes/class-frontend.php';
require_once WIFL_PATH . 'includes/class-float-cart.php';
require_once WIFL_PATH . 'admin/bootstrap.php';
require_once WIFL_PATH . 'includes/class-cart-page.php';
require_once WIFL_PATH . 'includes/class-checkout-page.php';
require_once WIFL_PATH . 'includes/class-smm-fulfillment.php';
require_once WIFL_PATH . 'includes/class-plugin.php';

\WIFL\Plugin::instance();
